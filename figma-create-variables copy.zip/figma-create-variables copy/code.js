"use strict";
figma.showUI(__html__, { width: 1200, height: 800 }); // Simple UI with a button
figma.ui.onmessage = async (msg) => {
    if (msg.type === 'ready') {
        try {
            console.log('Fetching collections...');
            const collections = await figma.variables.getLocalVariableCollectionsAsync();
            console.log('Fetched collections:', collections);
            if (collections.length === 0) {
                figma.ui.postMessage({ type: 'no-collections' });
                return;
            }
            const serializedCollections = collections.map((collection) => ({
                id: collection.id,
                name: collection.name,
                modes: collection.modes.map((mode) => ({ id: mode.modeId, name: mode.name })),
            }));
            console.log('Sending collections to UI:', serializedCollections);
            figma.ui.postMessage({ type: 'collections', data: serializedCollections });
        }
        catch (error) {
            console.error('Error loading collections:', error);
            figma.notify('Failed to load collections.');
        }
    }
    if (msg.type === 'fetch-modes') {
        // Fetch modes for the selected collection
        try {
            const collectionId = msg.collectionId;
            const collections = await figma.variables.getLocalVariableCollectionsAsync();
            const collection = collections.find((c) => c.id === collectionId);
            if (!collection) {
                figma.notify('The selected collection could not be found.');
                return;
            }
            // Deep copy the modes to ensure proper serialization
            const serializedModes = JSON.parse(JSON.stringify(collection.modes));
            // Send modes to the UI
            figma.ui.postMessage({ type: 'modes', data: serializedModes });
        }
        catch (error) {
            console.error('Error fetching modes:', error);
            figma.notify('An error occurred while fetching modes.');
        }
    }
    if (msg.type === 'fetch-text-layers') {
        // Validate selection
        const selection = figma.currentPage.selection;
        if (selection.length === 0) {
            figma.notify('Please select a Component Set or Section.');
            return;
        }
        const selectedNode = selection[0];
        console.log('Selected Node:', selectedNode); // Log the selected node
        if (selectedNode.type !== 'COMPONENT_SET' && selectedNode.type !== 'SECTION') {
            figma.notify('Invalid selection. Please select a Component Set or Section.');
            return;
        }
        try {
            // Extract components and text layers
            const textLayers = [];
            if (selectedNode.type === 'COMPONENT_SET') {
                console.log('Processing Component Set:', selectedNode.name); // Log Component Set name
                textLayers.push(...await extractTextLayersFromComponentSet(selectedNode, msg.selectedCollectionId, msg.restrictToCollection // Pass the flag here
                ));
            }
            else if (selectedNode.type === 'SECTION') {
                console.log('Processing Section:', selectedNode.name); // Log Section name
                for (const child of selectedNode.children) {
                    if (child.type === 'COMPONENT_SET') {
                        console.log('Processing Child Component Set:', child.name); // Log each Component Set name
                        textLayers.push(...await extractTextLayersFromComponentSet(child, msg.selectedCollectionId, msg.restrictToCollection // Pass the flag here
                        ));
                    }
                }
            }
            console.log('Extracted Text Layers:', textLayers); // Log the extracted text layers
            // Fetch variables in the selected collection
            const allVariables = await figma.variables.getLocalVariablesAsync();
            const variablesInSelectedCollection = allVariables.filter((variable) => variable.variableCollectionId === msg.selectedCollectionId);
            // Log variable names in the selected collection
            const variableNames = variablesInSelectedCollection.map((variable) => variable.name);
            console.log('Variables in Selected Collection:', variableNames);
            // Deep copy the text layers to ensure proper serialization
            const serializedTextLayers = JSON.parse(JSON.stringify(textLayers));
            console.log('Serialized Text Layers Sent to UI:', serializedTextLayers); // Log serialized data
            // Send text layers, variable names, and selection details to the UI
            figma.ui.postMessage({
                type: 'text-layers',
                data: {
                    textLayers: serializedTextLayers,
                    existingVariableNames: variableNames, // Include variable names
                    initialSelectionId: selectedNode.id, // Include the selection ID
                    selectionType: selectedNode.type, // Include the selection type
                },
            });
        }
        catch (error) {
            console.error('Error extracting text layers:', error);
            figma.notify('An error occurred while extracting text layers.');
        }
    }
    if (msg.type === 'create-and-bind-variables') {
        console.log(msg);
        try {
            const { variablesToCreate, variablesToBind, selectedCollectionId, componentSetId } = msg;
            // Fetch the collection node
            const collections = await figma.variables.getLocalVariableCollectionsAsync();
            const selectedCollection = collections.find((collection) => collection.id === selectedCollectionId);
            if (!selectedCollection) {
                figma.notify('The selected collection could not be found.');
                return;
            }
            // Step 1: Create Variables and Set Their Values
            const createdVariables = {}; // Map fullVariableName to created Variable
            for (const variableData of variablesToCreate) {
                const { name, prefix, fullVariableName, textLayerIds } = variableData;
                // Create the variable in the selected collection
                const newVariable = figma.variables.createVariable(name, selectedCollection, 'STRING');
                console.log(`Created Variable: ${fullVariableName}`);
                // Set the value of the variable for all modes
                for (const textLayerId of textLayerIds) {
                    const textLayer = await figma.getNodeByIdAsync(textLayerId);
                    if (textLayer && textLayer.type === 'TEXT') {
                        for (const mode of selectedCollection.modes) {
                            newVariable.setValueForMode(mode.modeId, textLayer.characters); // Set the value for each mode
                            console.log(`Set value for Variable "${fullVariableName}" to "${textLayer.characters}" for Mode "${mode.name}"`);
                        }
                        break; // Use the first text layer's value for the variable
                    }
                }
                // Store the created variable for later binding
                createdVariables[fullVariableName] = newVariable;
            }
            // Step 2: Bind Variables to Text Layers
            for (const variableData of variablesToBind) {
                const { variableName, textLayerIds } = variableData;
                // Find the variable by name
                const variable = createdVariables[variableName] ||
                    (await figma.variables.getLocalVariablesAsync()).find((v) => v.name === variableName);
                if (!variable) {
                    console.error(`Variable "${variableName}" not found.`);
                    continue;
                }
                // Bind the variable to each text layer
                for (const textLayerId of textLayerIds) {
                    const textLayer = await figma.getNodeByIdAsync(textLayerId);
                    if (textLayer && textLayer.type === 'TEXT') {
                        textLayer.setBoundVariable('characters', variable);
                        console.log(`Bound Variable "${variable.name}" to Text Layer "${textLayer.name}"`);
                    }
                    else {
                        console.error(`Text Layer with ID "${textLayerId}" not found or is not a TEXT node.`);
                    }
                }
            }
            // Step 3: Bind Newly Created Variables to Their Corresponding Text Layers
            for (const variableData of variablesToCreate) {
                const { fullVariableName, textLayerIds } = variableData;
                const variable = createdVariables[fullVariableName];
                if (!variable) {
                    console.error(`Created Variable "${fullVariableName}" not found.`);
                    continue;
                }
                for (const textLayerId of textLayerIds) {
                    const textLayer = await figma.getNodeByIdAsync(textLayerId);
                    if (textLayer && textLayer.type === 'TEXT') {
                        textLayer.setBoundVariable('characters', variable);
                        console.log(`Bound Newly Created Variable "${variable.name}" to Text Layer "${textLayer.name}"`);
                    }
                    else {
                        console.error(`Text Layer with ID "${textLayerId}" not found or is not a TEXT node.`);
                    }
                }
            }
            // Step 4: Extract Updated Text Layers for the Current ComponentSet
            const componentSet = await figma.getNodeByIdAsync(componentSetId);
            if (!componentSet || componentSet.type !== 'COMPONENT_SET') {
                console.error(`Component Set with ID "${componentSetId}" not found or is not a valid Component Set.`);
                figma.ui.postMessage({ type: 'fetch-error' });
                return;
            }
            const updatedTextLayers = await extractTextLayersFromComponentSet(componentSet, selectedCollectionId, true // Restrict to the selected collection
            );
            console.log('Updated Text Layers:', updatedTextLayers);
            // Step 5: Send Updated Text Layers to the UI
            figma.ui.postMessage({
                type: 'layer-data-update',
                data: {
                    updatedTextLayers,
                },
            });
            figma.notify('Variables created, values set, and bound successfully!');
        }
        catch (error) {
            console.error('Error creating and binding variables:', error);
            figma.notify('An error occurred while creating and binding variables.');
        }
    }
    if (msg.type === 'remove-bindings') {
        try {
            const { initialSelectionId } = msg;
            // Use the initial selection ID if provided, otherwise use the current selection
            const selectedNode = initialSelectionId
                ? await figma.getNodeByIdAsync(initialSelectionId) // Use getNodeByIdAsync
                : figma.currentPage.selection[0];
            if (!selectedNode) {
                console.error('No valid node selected.');
                figma.ui.postMessage({ type: 'fetch-error' });
                return;
            }
            if (selectedNode.type !== 'COMPONENT_SET' && selectedNode.type !== 'SECTION') {
                console.error('Invalid node type. Must be COMPONENT_SET or SECTION.');
                figma.ui.postMessage({ type: 'fetch-error' });
                return;
            }
            // Collect all text layers in the selected node
            const textLayerIds = new Set();
            if (selectedNode.type === 'COMPONENT_SET') {
                for (const child of selectedNode.children) {
                    findAllTextLayersRecursively(child, textLayerIds);
                }
            }
            else if (selectedNode.type === 'SECTION') {
                for (const child of selectedNode.children) {
                    if (child.type === 'COMPONENT_SET') {
                        for (const componentChild of child.children) {
                            findAllTextLayersRecursively(componentChild, textLayerIds);
                        }
                    }
                }
            }
            console.log('Text Layers to Process:', Array.from(textLayerIds));
            // Remove bindings from all collected text layers
            for (const textLayerId of textLayerIds) {
                const node = await figma.getNodeByIdAsync(textLayerId);
                if (node && node.type === 'TEXT') {
                    console.log(`Removing binding from Text Layer: ${node.name} (ID: ${node.id})`);
                    node.setBoundVariable('characters', null); // Remove variable binding
                    console.log(`Binding removed from Text Layer: ${node.name}`);
                }
                else {
                    console.error(`Text Layer with ID "${textLayerId}" not found or is not a TEXT node.`);
                }
            }
            // Notify the UI that bindings have been removed
            figma.ui.postMessage({ type: 'bindings-removed' });
        }
        catch (error) {
            console.error('Error removing bindings:', error);
            figma.ui.postMessage({ type: 'fetch-error' });
        }
    }
};
// Helper function to extract text layers from a Component Set
async function extractTextLayersFromComponentSet(componentSet, selectedCollectionId, restrictToCollection) {
    const allVariables = await figma.variables.getLocalVariablesAsync();
    const allCollections = await figma.variables.getLocalVariableCollectionsAsync();
    // Map mode IDs to mode names for easy lookup
    const modeIdToNameMap = {};
    allCollections.forEach((collection) => {
        collection.modes.forEach((mode) => {
            modeIdToNameMap[mode.modeId] = mode.name;
        });
    });
    // Map collection IDs to collection names
    const collectionIdToNameMap = {};
    allCollections.forEach((collection) => {
        collectionIdToNameMap[collection.id] = collection.name;
    });
    const groupedTextLayers = {};
    for (const component of componentSet.children) {
        if (component.type === 'COMPONENT') {
            for (const child of component.children) {
                findTextLayersRecursively(child, groupedTextLayers, component.name, allVariables, modeIdToNameMap, collectionIdToNameMap, selectedCollectionId, restrictToCollection, componentSet.id, // Pass the ComponentSet ID
                componentSet.name // Pass the ComponentSet name
                );
            }
        }
    }
    const groupedData = Object.entries(groupedTextLayers).map(([value, data]) => ({
        value,
        components: Array.from(data.components),
        textLayerIds: Array.from(data.textLayerIds),
        name: data.name,
        matchingVariables: data.matchingVariables,
        componentSetId: data.componentSetId,
        componentSetName: data.componentSetName,
    }));
    return groupedData;
}
// Helper function to recursively find TEXT layers
function findTextLayersRecursively(node, groupedTextLayers, componentName, allVariables, modeIdToNameMap, collectionIdToNameMap, selectedCollectionId, restrictToCollection, componentSetId, componentSetName) {
    var _a;
    if (node.type === 'TEXT') {
        // Check if the text layer is already bound to a variable
        const boundVariable = (_a = node.boundVariables) === null || _a === void 0 ? void 0 : _a.characters;
        if (boundVariable) {
            console.log(`Skipping bound text layer: ${node.name}`);
            return; // Skip this text layer if it is already bound
        }
        if (!groupedTextLayers[node.characters]) {
            const matchingVariables = findMatchingVariables(node.characters, allVariables, modeIdToNameMap, collectionIdToNameMap, selectedCollectionId, restrictToCollection);
            groupedTextLayers[node.characters] = {
                components: new Set(),
                textLayerIds: new Set(),
                name: node.name,
                matchingVariables,
                componentSetId, // Add ComponentSet ID
                componentSetName, // Add ComponentSet name
            };
        }
        groupedTextLayers[node.characters].components.add(componentName);
        groupedTextLayers[node.characters].textLayerIds.add(node.id);
    }
    else if ('children' in node) {
        for (const child of node.children) {
            findTextLayersRecursively(child, groupedTextLayers, componentName, allVariables, modeIdToNameMap, collectionIdToNameMap, selectedCollectionId, restrictToCollection, componentSetId, componentSetName);
        }
    }
}
// Helper function to recursively find all TEXT layers (including bound ones)
function findAllTextLayersRecursively(node, textLayerIds) {
    if (node.type === 'TEXT') {
        textLayerIds.add(node.id); // Add the text layer ID to the set
    }
    else if ('children' in node) {
        for (const child of node.children) {
            findAllTextLayersRecursively(child, textLayerIds); // Recursively process child nodes
        }
    }
}
// Helper function to find matching variables
function findMatchingVariables(value, allVariables, modeIdToNameMap, collectionIdToNameMap, // Add this parameter
selectedCollectionId, restrictToCollection) {
    const matchingVariables = [];
    allVariables.forEach((variable) => {
        // Skip variables if restricted to the selected collection and the variable is not in the selected collection
        if (restrictToCollection && variable.variableCollectionId !== selectedCollectionId) {
            return;
        }
        const matchingModes = [];
        // Check each mode for matching values
        for (const [modeId, modeValue] of Object.entries(variable.valuesByMode)) {
            if (modeValue === value) {
                matchingModes.push(modeIdToNameMap[modeId]); // Map mode ID to mode name
            }
        }
        if (matchingModes.length > 0) {
            const collectionName = restrictToCollection
                ? '' // No collection name when restricted to the selected collection
                : `${collectionIdToNameMap[variable.variableCollectionId]}/`; // Use the collection name from the map
            // Format as "Collection Name/Variable Name: Mode1, Mode2, Mode3"
            matchingVariables.push(`${collectionName}${variable.name}: ${matchingModes.join(', ')}`);
        }
    });
    return matchingVariables;
}

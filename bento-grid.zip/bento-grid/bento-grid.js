const tl = gsap.timeline({ repeat: -1, repeatDelay: 2 });

// Frame 1
tl.to("#frame1", { opacity: 1, duration: 0.2 })
  .to("#copy1", { opacity: 1, y: 0, duration: 0.4 })
  .from(["#bmo-logo", "#xero-logo"], { y: -20, opacity: 0, duration: 0.4 })
  .to("#bmo-logo", { scale: 1.05, repeat: 1, yoyo: true, duration: 0.35, ease: "power1.inOut"}, "<")
  .to(".data-dot", { 
      opacity: 1,
      duration: 0.1,
      stagger: { each: 0.2, from: "start" },
      x: 280,
      ease: "power1.inOut"
  }, "+=0.2")
  .to("#xero-logo", { scale: 1.1, yoyo: true, repeat: 1, duration: 0.2, ease: "power1.inOut" }, "-=0.2")
  .to(".data-dot", { opacity: 0, duration: 0.2 })
  .to(".timeline-widget", { opacity: 1, duration: 0.3 }, "-=0.5")
  .to(".exception-bubble", { scale: 1, stagger: 0.2, duration: 0.2 })
  .to(".exception-bubble", { scale: 0, stagger: 0.2, duration: 0.2 }, "+=0.2");

// Transition 1 -> 2
tl.to(["#frame1", "#copy1"], { opacity: 0, duration: 0.3, delay: 0.5 });

// Frame 2
tl.to("#frame2", { opacity: 1, duration: 0.2 })
  .to("#copy2", { opacity: 1, y: 0, duration: 0.4 }, "+=0.1")
  .to(".paid-stamp", { opacity: 1, scale: 1, rotation: -10, duration: 0.4, ease: "power2.out" }, "+=0.5");

// Transition 2 -> 3
tl.to(["#frame2", "#copy2"], { opacity: 0, duration: 0.3, delay: 1 });

// Frame 3
tl.to("#frame3", { opacity: 1, duration: 0.2 })
  .to("#copy3", { opacity: 1, y: 0, duration: 0.4 }, "+=0.1")
  .from(".new-vendor", { x: -30, opacity: 0, duration: 0.4 }, "+=0.5")
  .to(".checkmark", { scale: 1, duration: 0.3, ease: "back.out(1.7)" });

// Transition 3 -> 4
tl.to(["#frame3", "#copy3"], { opacity: 0, duration: 0.3, delay: 1 });

// Frame 4
tl.to("#frame4", { opacity: 1, duration: 0.2 })
  .to("#copy4", { opacity: 1, y: 0, duration: 0.4 }, "+=0.1")
  .to(".bar", {
      scaleY: 1,
      duration: 0.8,
      stagger: 0.15,
      ease: "power2.inOut"
  }, "+=0.5"); 
# Animation System Architecture

## Overview

This document outlines the architecture for a flexible, reusable animation system supporting three animation types: **Accounts**, **API**, and **ERP** (with 3 looping scenes). The system is built with Angular and GSAP, emphasizing modularity, performance, and maintainability.

## Core Principles

1. **No Runtime Injection**: Templates are compiled with Angular at build time
2. **Direct GSAP Usage**: No unnecessary service wrappers since GSAP is globally available via CDN
3. **Component-Based**: Each animation is self-contained with its own HTML, SCSS, and TypeScript
4. **Factory Pattern**: Centralized animation instantiation with consistent interface
5. **Performance First**: Proper lifecycle management and resource cleanup

## Architecture Components

### 1. Base Animation Class

```typescript
// base-animation.ts
declare const gsap: any; // Global from CDN

export abstract class BaseAnimation {
  protected timeline?: any;
  protected container?: HTMLElement;
  protected isPlaying = false;
  
  abstract init(container: HTMLElement): void;
  abstract createTimeline(): void;
  abstract setupElements(): void;
  
  play(): void { 
    this.timeline?.play();
    this.isPlaying = true;
  }
  
  pause(): void { 
    this.timeline?.pause();
    this.isPlaying = false;
  }
  
  destroy(): void {
    this.timeline?.kill();
    gsap.killTweensOf(this.container);
  }
  
  reset(): void {
    this.timeline?.restart();
    this.timeline?.pause();
  }
}
```

### 2. Animation Factory Service

```typescript
@Injectable({ providedIn: 'root' })
export class AnimationFactory {
  create(type: 'accounts' | 'api' | 'erp'): BaseAnimation {
    switch(type) {
      case 'accounts':
        return new AccountsAnimation();
      case 'api':
        return new ApiAnimation();
      case 'erp':
        return new ErpAnimation();
      default:
        throw new Error(`Unknown animation type: ${type}`);
    }
  }
}
```

### 3. File Structure

```
src/app/
├── core/
│   └── animations/
│       ├── animation-factory.service.ts
│       ├── gsap.service.ts (existing)
│       ├── gsap.types.ts (existing)
│       └── feature-animations/
│           ├── base/
│           │   ├── base-animation.ts
│           │   └── animation.types.ts
│           ├── accounts/
│           │   ├── accounts.animation.ts
│           │   ├── accounts.animation.html
│           │   └── accounts.animation.scss
│           ├── api/
│           │   ├── api.animation.ts
│           │   ├── api.animation.html
│           │   └── api.animation.scss
│           └── erp/
│               ├── erp.animation.ts
│               ├── erp.animation.html
│               ├── erp.animation.scss
│               └── scenes/
│                   ├── scene1-data-flow.ts
│                   ├── scene2-integrations.ts
│                   └── scene3-dashboard.ts
```

## Animation Implementations

### Accounts Animation

**Source**: Extracted from `modern-accounts-animation-gsap.html`

**Components**:
- Multi-step form with progress bar
- Typewriter effect for input fields
- Success state with confetti system
- Play/pause controls
- Accessibility features (ARIA, screen reader support)

**Key Features**:
- Glass morphism design
- Form validation animations
- Confetti pool system for performance
- Looping timeline with reset

### API Animation (Future)

**Planned Components**:
- Code editor interface
- API request/response visualization
- Loading states
- Data flow animations

### ERP Animation (Future)

**Planned Components**:
- Scene manager for 3 distinct scenes
- Scene 1: Data flow visualization
- Scene 2: Integration connections
- Scene 3: Dashboard metrics
- Smooth transitions between scenes

## Integration with AnimationPlaceholder Component

### Template Structure

```html
<!-- animation-placeholder.component.html -->
<div class="animation-placeholder" 
     [attr.data-animation-type]="animationType"
     #animationContainer>
  
  <div class="animation-placeholder__stage" #animationStage>
    <div class="animation-placeholder__content" [ngSwitch]="animationType">
      
      <!-- Accounts Animation -->
      <div *ngSwitchCase="'accounts'" class="animation-placeholder__accounts">
        <!-- Accounts HTML template here -->
      </div>
      
      <!-- API Animation -->
      <div *ngSwitchCase="'api'" class="animation-placeholder__api">
        <!-- API HTML template here -->
      </div>
      
      <!-- ERP Animation -->
      <div *ngSwitchCase="'erp'" class="animation-placeholder__erp">
        <!-- ERP HTML template here -->
      </div>
      
    </div>
  </div>
</div>
```

### Component Integration

```typescript
export class AnimationPlaceholderComponent implements AfterViewInit, OnDestroy {
  @Input() animationType!: 'erp' | 'api' | 'accounts';
  @ViewChild('animationStage', { read: ElementRef }) stage!: ElementRef;
  
  private animation?: BaseAnimation;
  
  constructor(private animationFactory: AnimationFactory) {}
  
  ngAfterViewInit(): void {
    const container = this.stage.nativeElement.querySelector(
      `.animation-placeholder__${this.animationType}`
    );
    
    if (container) {
      this.animation = this.animationFactory.create(this.animationType);
      this.animation.init(container);
      this.animation.play();
    }
  }
  
  ngOnDestroy(): void {
    this.animation?.destroy();
  }
}
```

## Styling Strategy

### SCSS Organization

```scss
// animation-placeholder.component.scss
.animation-placeholder {
  // Base styles
  
  &__accounts {
    @import 'core/animations/feature-animations/accounts/accounts.animation';
  }
  
  &__api {
    @import 'core/animations/feature-animations/api/api.animation';
  }
  
  &__erp {
    @import 'core/animations/feature-animations/erp/erp.animation';
  }
}
```

### DSM Token Mapping

Convert hardcoded values to DSM tokens:
- `var(--bmo-color-brand-default)` → `var(--color-primary-default)`
- `var(--bmo-spacing-3xl)` → `var(--spacing-3xl)`
- `var(--bmo-border-radius-2xl)` → `var(--border-radius-2xl)`

## Performance Considerations

### Optimization Strategies

1. **GPU Acceleration**: Use `transform` and `opacity` for animations
2. **Will-Change**: Applied to animated elements
3. **Contain**: CSS containment for performance isolation
4. **Object Pooling**: Reuse DOM elements (e.g., confetti system)
5. **Timeline Management**: Proper cleanup and destruction

### GSAP Best Practices

```javascript
// Performance defaults
gsap.defaults({
  force3D: true,
  lazy: false,
  autoSleep: 60,
  nullTargetWarn: false
});
```

## Accessibility Features

### Required Support

1. **Reduced Motion**: Check `prefers-reduced-motion` media query
2. **ARIA Labels**: Proper labeling for screen readers
3. **Keyboard Navigation**: Support for play/pause and timeline control
4. **Focus Management**: Proper focus indicators and management
5. **Screen Reader Announcements**: Live regions for state changes

### Implementation Example

```typescript
checkReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

announceToScreenReader(message: string): void {
  const statusEl = this.container.querySelector('[role="status"]');
  if (statusEl) {
    statusEl.textContent = message;
    setTimeout(() => { statusEl.textContent = ''; }, 100);
  }
}
```

## Testing Strategy

### Browser MCP Validation

1. Navigate to implemented section
2. Verify visual rendering
3. Test all interactions
4. Validate accessibility features
5. Check responsive behavior
6. Test GSAP animations at different speeds
7. Verify memory cleanup on destroy

### Performance Metrics

- LCP < 2.5s
- FID < 100ms
- CLS < 0.1
- 60fps animation target

## Migration Path

### Phase 1: Documentation & Planning ✅
- Create architecture documentation
- Define implementation strategy

### Phase 2: Core Architecture
- Implement BaseAnimation class
- Create AnimationFactory service
- Set up type definitions

### Phase 3: Accounts Animation
- Extract HTML from `modern-accounts-animation-gsap.html`
- Convert CSS to SCSS with DSM tokens
- Port GSAP logic to TypeScript
- Implement confetti system

### Phase 4: Integration & Testing
- Update AnimationPlaceholder component
- Add animation templates
- Test with Browser MCP
- Validate performance

## Benefits of This Architecture

1. **Modularity**: Each animation is self-contained
2. **Reusability**: Base class provides common functionality
3. **Maintainability**: Clear separation of concerns
4. **Performance**: Proper lifecycle management
5. **Scalability**: Easy to add new animation types
6. **Type Safety**: Full TypeScript support
7. **Angular Native**: Leverages Angular's compilation and optimization

## Future Enhancements

1. **Animation Library**: Build a library of reusable animation components
2. **Configuration System**: External configuration for animation parameters
3. **A/B Testing**: Support for animation variants
4. **Analytics Integration**: Track animation engagement
5. **Performance Monitoring**: Real-time performance metrics
6. **Animation Editor**: Visual editor for creating animations

## References

- [GSAP Documentation](https://greensock.com/docs/)
- [Angular Animation Guide](https://angular.io/guide/animations)
- [Web Animations API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Animations_API)
- [BMO Design System](internal-documentation)
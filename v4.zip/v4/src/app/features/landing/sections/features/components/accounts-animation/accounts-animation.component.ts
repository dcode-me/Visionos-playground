import { Component, OnInit, OnDestroy, AfterViewInit, ElementRef, ViewChild, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

declare const gsap: any;

@Component({
  selector: 'app-accounts-animation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './accounts-animation.component.html',
  styleUrls: ['./accounts-animation.component.scss']
})
export class AccountsAnimationComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('animationContainer', { static: false }) container!: ElementRef;
  
  private elements: any = {};
  private mainTimeline?: any;
  private confettiPool?: ConfettiPool;
  private prefersReducedMotion = false;
  private isPlaying = true;
  
  private readonly TEXT_CONFIG = {
    form: {
      title: 'Quick Account Setup',
      subtitle: 'Complete in under 2 minutes',
      progress: {
        step1: 'Company Info',
        step2: 'Account Type',
        step3: 'Complete'
      },
      fields: {
        companyName: {
          label: 'Company Name',
          placeholder: 'Enter your company name'
        },
        industry: {
          label: 'Industry',
          placeholder: 'Select your industry',
          options: {
            tech: 'Technology',
            retail: 'Retail',
            finance: 'Finance'
          }
        },
        accountType: {
          label: 'Account Type',
          placeholder: 'Choose your account type',
          options: {
            business: 'Business Premium',
            corporate: 'Corporate',
            enterprise: 'Enterprise'
          }
        },
        currency: {
          label: 'Primary Currency',
          placeholder: 'Select primary currency',
          options: {
            cad: 'CAD - Canadian Dollar',
            usd: 'USD - US Dollar',
            eur: 'EUR - Euro'
          }
        }
      },
      success: {
        title: 'Account Created!',
        accountNumber: 'ACC-2024-****32',
        accountDescription: 'Business Premium Account • CAD',
        disclaimer: '*For illustration purposes only'
      }
    },
    animation: {
      values: {
        companyName: 'Tech Innovations Inc.',
        industry: 'tech',
        industryDisplay: 'Technology',
        accountType: 'business',
        currency: 'cad'
      }
    },
    aria: {
      step1Label: 'Step 1: Company Information',
      step2Label: 'Step 2: Account Configuration',
      pauseAnimation: 'Pause animation',
      playAnimation: 'Play animation',
      pressed: {
        true: 'true',
        false: 'false'
      }
    },
    screenReader: {
      step1Announce: 'Step 1: Company Information. Please wait while we fill in the form.',
      industrySelected: 'Industry selected: Technology',
      step2Announce: 'Step 2: Account Type. Configuring your account.',
      successAnnounce: 'Account successfully created! Your account number is ACC-2024-****32',
      animationRestarted: 'Animation restarted'
    },
    console: {
      timelineRepeating: 'Timeline repeating...',
      timelineComplete: 'Timeline complete - duration:',
      mainTimelineCreated: 'Main timeline created. Duration:',
      repeat: 'Repeat:',
      shouldRepeat: 'should repeat',
      timelineProgress: 'Timeline progress:'
    }
  };

  private readonly ANIMATION_CONFIG = {
    TYPEWRITER_FPS: 30,
    CONFETTI_POOL_SIZE: 50,
    STEP_TRANSITION_DURATION: 0.4,
    PROGRESS_DURATION: 0.5
  };

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.isPlaying = !this.prefersReducedMotion;
    }
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initAnimation();
    }
  }

  ngOnDestroy(): void {
    this.cleanup();
  }

  private initAnimation(): void {
    if (!this.container || typeof gsap === 'undefined') return;
    
    // GSAP configuration settings
    gsap.config({
      autoSleep: 60,
      nullTargetWarn: false
    });
    
    // Animation defaults only
    gsap.defaults({
      ease: 'power2.out'
    });
    
    this.setupElements();
    this.initializeConfetti();
    this.createTimeline();
    this.initializeControls();
    
    if (!this.prefersReducedMotion) {
      this.startAnimation();
    } else {
      this.showStaticForm();
    }
  }

  private setupElements(): void {
    const el = this.container.nativeElement;
    
    this.elements = {
      // Form container elements
      formWrapper: el.querySelector('.accounts-feature__form-wrapper'),
      progressBar: el.querySelector('#progressBar'),
      step1: el.querySelector('#step1'),
      step2: el.querySelector('#step2'),
      success: el.querySelector('#success'),
      successIcon: el.querySelector('.accounts-feature__success-icon'),
      accountCard: el.querySelector('.accounts-feature__account-card'),
      form: el.querySelector('#form'),
      confettiContainer: el.querySelector('#confettiContainer'),
      
      // Progress labels
      label1: el.querySelector('#label1'),
      label2: el.querySelector('#label2'),
      label3: el.querySelector('#label3'),
      
      // Form inputs
      companyInput: el.querySelector('#companyInput') as HTMLInputElement,
      industrySelect: el.querySelector('#industrySelect') as HTMLSelectElement,
      accountSelect: el.querySelector('#accountSelect') as HTMLSelectElement,
      currencySelect: el.querySelector('#currencySelect') as HTMLSelectElement,
      
      // Play/Pause controls
      playPauseBtn: el.querySelector('#playPauseBtn'),
      pauseIcon: el.querySelector('#pauseIcon'),
      playIcon: el.querySelector('#playIcon'),
      
      formStatus: el.querySelector('#form-status')
    };
  }

  // Optimized typewriter effect - matching HTML implementation
  private typewriterEffect(element: HTMLInputElement, text: string): () => void {
    return function(this: any) {
      const progress = this.progress();
      const chars = Math.floor(progress * text.length);
      element.value = text.substring(0, chars);
    };
  }

  private createTimeline(): void {
    if (typeof gsap === 'undefined') return;
    
    // Create main timeline with optimized settings - matching HTML exactly
    this.mainTimeline = gsap.timeline({
      repeat: -1,
      paused: true,
      repeatDelay: 0.5, // Changed from 2 to 0.5 to match HTML
      onRepeat: () => {}
    });

    // Build the animation sequence with labels for better control
    this.mainTimeline
      .addLabel('start')
      // Step 1 - Optimized with GPU acceleration
      .set(this.elements.step1, { display: 'block', opacity: 0, x: 30 })
      .to(this.elements.step1, {
        opacity: 1,
        x: 0,
        duration: this.ANIMATION_CONFIG.STEP_TRANSITION_DURATION,
        ease: "power2.out"
      })
      .to(this.elements.progressBar, {
        width: '33%',
        duration: this.ANIMATION_CONFIG.PROGRESS_DURATION,
        ease: "power2.inOut"
      }, "-=0.3")
      .add(() => {
        this.elements.label1.classList.add('active');
        this.announceToScreenReader(this.TEXT_CONFIG.screenReader.step1Announce);
      })
      .addLabel('step1_active')
      
      // Typewriter effect for company name - using optimized helper function
      .to({}, {
        duration: 0.8,
        ease: "none",
        onUpdate: this.typewriterEffect(this.elements.companyInput, this.TEXT_CONFIG.animation.values.companyName),
        onComplete: () => {
          if (this.elements.companyInput) {
            this.elements.companyInput.value = this.TEXT_CONFIG.animation.values.companyName; // Ensure full text
            this.elements.companyInput.classList.add('filled');
          }
        }
      }, "+=0.5")
      .add(() => { 
        this.elements.industrySelect.value = this.TEXT_CONFIG.animation.values.industry;
        this.announceToScreenReader(this.TEXT_CONFIG.screenReader.industrySelected);
      }, "+=0.3")
      .add(() => this.elements.industrySelect.classList.add('filled'))
      
      // Transition to Step 2 - Optimized with batch operations
      .addLabel('step1_complete')
      .to(this.elements.step1, {
        opacity: 0,
        x: -30,
        duration: this.ANIMATION_CONFIG.STEP_TRANSITION_DURATION,
        ease: "power2.in",
        onComplete: () => gsap.set(this.elements.step1, { display: 'none', clearProps: 'all' })
      }, "+=1")
      .set(this.elements.step2, { display: 'block', opacity: 0, x: 30 }, "-=0.1")
      .to(this.elements.step2, {
        opacity: 1,
        x: 0,
        duration: this.ANIMATION_CONFIG.STEP_TRANSITION_DURATION,
        ease: "power2.out"
      })
      .to(this.elements.progressBar, {
        width: '66%',
        duration: this.ANIMATION_CONFIG.PROGRESS_DURATION,
        ease: "power2.inOut"
      }, "-=0.3")
      .add(() => {
        this.elements.label2.classList.add('active');
        this.announceToScreenReader(this.TEXT_CONFIG.screenReader.step2Announce);
      })
      
      // Fill step 2 fields with green highlight
      .add(() => { 
        this.elements.accountSelect.value = this.TEXT_CONFIG.animation.values.accountType; 
      }, "+=0.6")
      .add(() => this.elements.accountSelect.classList.add('filled'))
      .add(() => { 
        this.elements.currencySelect.value = this.TEXT_CONFIG.animation.values.currency; 
      }, "+=0.3")
      .add(() => this.elements.currencySelect.classList.add('filled'))
      
      // Transition to Success
      .to(this.elements.step2, {
        opacity: 0,
        x: -30,
        duration: 0.4,
        ease: "power2.in"
      }, "+=1")
      .set(this.elements.step2, { display: 'none' })
      .set(this.elements.form, { display: 'none' })
      .to(this.elements.progressBar, {
        width: '100%',
        duration: 0.5,
        ease: "power2.inOut"
      })
      .add(() => {
        this.elements.label3.classList.add('active');
        this.announceToScreenReader(this.TEXT_CONFIG.screenReader.successAnnounce);
      })
      .to(this.elements.success, {
        opacity: 1,
        scale: 1,
        duration: 0.5,
        ease: "power2.out"
      })
      .fromTo(this.elements.successIcon, {
        scale: 0.7,  // Reduced from 0.85 for smaller initial scale
        opacity: 0
      }, {
        scale: 1,
        opacity: 1,
        duration: 0.45,
        ease: "power2.out"
      }, "-=0.2")
      .to(this.elements.accountCard, {
        opacity: 1,
        y: 0,
        duration: 0.5,
        ease: "power2.out"
      }, "-=0.2")
      
      // Create confetti
      .add(() => this.createConfetti())
      
      // Hold success state
      .to({}, { duration: 2 })
      
      // Clean up confetti before reset
      .add(() => {
        if (this.confettiPool) {
          this.confettiPool.reset();
        }
      })
      
      // Reset for loop
      .addLabel('success_complete')
      .to(this.elements.success, {
        opacity: 0,
        scale: 0.8,
        duration: 0.4
      })
      .call(() => {
        // Reset all form values and classes - matching HTML exactly
        this.elements.label1.classList.remove('active');
        this.elements.label2.classList.remove('active');
        this.elements.label3.classList.remove('active');
        this.elements.companyInput.classList.remove('filled');
        this.elements.industrySelect.classList.remove('filled');
        this.elements.accountSelect.classList.remove('filled');
        this.elements.currencySelect.classList.remove('filled');
        this.elements.companyInput.value = '';
        this.elements.industrySelect.selectedIndex = 0;
        this.elements.accountSelect.selectedIndex = 0;
        this.elements.currencySelect.selectedIndex = 0;
        // Clear confetti
        if (this.confettiPool) {
          this.confettiPool.reset();
        }
        // Reset success elements completely
        this.elements.success.style.opacity = '0';
        this.elements.success.style.transform = '';
        this.elements.accountCard.style.opacity = '0';
        this.elements.accountCard.style.transform = '';
        this.elements.successIcon.style.transform = '';
      })
      .set(this.elements.step1, { display: 'none', opacity: 0, x: 30 })
      .set(this.elements.step2, { display: 'none', opacity: 0, x: 30 })
      .set(this.elements.form, { display: 'flex' })
      .set(this.elements.progressBar, { width: '0%' })
      // Add a small pause before repeating
      .to({}, { duration: 0.5 });

    // Timeline complete callback
    this.mainTimeline.eventCallback('onComplete', () => {});
  }

  // Start form animation with entrance effect - matching HTML
  private startAnimation(): void {
    if (!this.elements.formWrapper || typeof gsap === 'undefined') return;
    
    // Form wrapper entrance animation - matching HTML exactly
    gsap.fromTo(this.elements.formWrapper, {
      opacity: 0,
      y: 18,
      scale: 0.982
    }, {
      opacity: 1,
      y: 0,
      scale: 1,
      duration: 1.1,
      ease: "power3.out",
      onComplete: () => {
        // Start main timeline after entrance
        gsap.delayedCall(0.6, () => {
          if (this.mainTimeline) {
            this.mainTimeline.play();
          }
        });
      }
    });
  }

  private initializeControls(): void {
    if (!this.elements.playPauseBtn) return;
    
    // Add event listeners
    this.elements.playPauseBtn.addEventListener('click', () => this.togglePlayPause());
    
    // Add keyboard support for play/pause
    this.elements.playPauseBtn.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        this.togglePlayPause();
      }
    });
    
    // Add keyboard navigation for timeline control
    if (isPlatformBrowser(this.platformId)) {
      document.addEventListener('keydown', (e: KeyboardEvent) => {
        if (e.ctrlKey || e.metaKey) {
          switch(e.key) {
            case 'ArrowLeft':
              e.preventDefault();
              if (this.mainTimeline) {
                this.mainTimeline.progress(Math.max(0, this.mainTimeline.progress() - 0.1));
              }
              break;
            case 'ArrowRight':
              e.preventDefault();
              if (this.mainTimeline) {
                this.mainTimeline.progress(Math.min(1, this.mainTimeline.progress() + 0.1));
              }
              break;
            case 'r':
              e.preventDefault();
              if (this.mainTimeline) {
                this.mainTimeline.restart();
                this.announceToScreenReader(this.TEXT_CONFIG.screenReader.animationRestarted);
              }
              break;
          }
        }
      });
    }
  }

  private togglePlayPause(): void {
    if (!this.mainTimeline || typeof gsap === 'undefined') return;
    
    if (this.isPlaying) {
      this.mainTimeline.pause();
      gsap.globalTimeline.pause();
    } else {
      this.mainTimeline.play();
      gsap.globalTimeline.resume();
    }
    
    this.isPlaying = !this.isPlaying;
    this.elements.playPauseBtn.classList.toggle('playing', this.isPlaying);
    this.elements.pauseIcon.classList.toggle('hidden', !this.isPlaying);
    this.elements.playIcon.classList.toggle('hidden', this.isPlaying);
    this.elements.playPauseBtn.setAttribute('aria-label', 
      this.isPlaying ? this.TEXT_CONFIG.aria.pauseAnimation : this.TEXT_CONFIG.aria.playAnimation);
    this.elements.playPauseBtn.setAttribute('aria-pressed', 
      this.isPlaying ? this.TEXT_CONFIG.aria.pressed.true : this.TEXT_CONFIG.aria.pressed.false);
    
    // Pause/resume CSS-only animations as well
    document.body.classList.toggle('is-paused', !this.isPlaying);
  }

  private showStaticForm(): void {
    // Show form without animation for reduced motion preference
    if (typeof gsap !== 'undefined') {
      gsap.set(this.elements.formWrapper, { 
        opacity: 1, 
        scale: 1, 
        y: 0 
      });
      gsap.set([this.elements.label1, this.elements.label2, this.elements.label3], { opacity: 1 });
    }
  }

  private initializeConfetti(): void {
    if (this.elements.confettiContainer) {
      this.confettiPool = new ConfettiPool(
        this.ANIMATION_CONFIG.CONFETTI_POOL_SIZE,
        this.elements.confettiContainer
      );
    }
  }

  private createConfetti(): void {
    if (this.confettiPool) {
      this.confettiPool.burst(30);
    }
  }

  private announceToScreenReader(message: string): void {
    if (this.elements.formStatus) {
      this.elements.formStatus.textContent = message;
      setTimeout(() => {
        if (this.elements.formStatus) {
          this.elements.formStatus.textContent = '';
        }
      }, 100);
    }
  }

  private cleanup(): void {
    if (this.mainTimeline) {
      this.mainTimeline.kill();
    }
    this.confettiPool?.reset();
    if (typeof gsap !== 'undefined' && this.container) {
      gsap.killTweensOf(this.container.nativeElement.querySelectorAll('*'));
    }
  }
}

// Optimized Confetti Pool System - matching HTML implementation
class ConfettiPool {
  private pool: HTMLElement[] = [];
  private active: HTMLElement[] = [];
  // Use actual colors instead of CSS variables that don't exist
  private colors = ['#0075be', '#005587', '#10b981', '#c7e4fc', '#f59e0b'];
  private timeline: any = null;
  private container: HTMLElement;

  constructor(poolSize: number, container: HTMLElement) {
    this.container = container;
    if (container) {
      this.initialize(poolSize);
    }
  }

  private initialize(size: number): void {
    if (!this.container) return;
    
    for (let i = 0; i < size; i++) {
      const confetti = document.createElement('div');
      confetti.className = 'accounts-feature__confetti';
      confetti.style.position = 'absolute';
      confetti.style.display = 'none';
      this.container.appendChild(confetti);
      this.pool.push(confetti);
    }
  }

  private getConfetti(): HTMLElement | null {
    if (this.pool.length > 0) {
      const confetti = this.pool.pop()!;
      this.active.push(confetti);
      return confetti;
    }
    return null;
  }

  private returnConfetti(confetti: HTMLElement): void {
    confetti.style.display = 'none';
    if (typeof gsap !== 'undefined') {
      gsap.set(confetti, { clearProps: 'all' });
    }
    const index = this.active.indexOf(confetti);
    if (index > -1) {
      this.active.splice(index, 1);
      this.pool.push(confetti);
    }
  }

  burst(count: number = 30): void {
    // Check GSAP first
    if (typeof gsap === 'undefined') {
      return;
    }
    
    if (typeof window !== 'undefined') {
      const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (prefersReducedMotion) {
        return;
      }
    }
    
    // Clean up any leftover confetti first
    this.reset();
    
    // Kill existing timeline if any
    if (this.timeline) {
      this.timeline.kill();
    }

    // Create a single timeline for all confetti
    this.timeline = gsap.timeline();
    
    const particles: HTMLElement[] = [];
    for (let i = 0; i < Math.min(count, this.pool.length); i++) {
      const confetti = this.getConfetti();
      if (!confetti) break;
      
      // Set initial styles - ONLY explicit sizing
      confetti.style.display = 'block';
      confetti.style.position = 'absolute';
      confetti.style.width = '10px';
      confetti.style.height = '10px';
      confetti.style.left = Math.random() * 100 + '%';
      // Removed top: 50% to test if width/height alone fixes it
      confetti.style.background = this.colors[Math.floor(Math.random() * this.colors.length)];
      confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
      
      particles.push(confetti);
    }


    // Batch animate all confetti with a single timeline - matching HTML
    if (particles.length > 0) {
      this.timeline.fromTo(particles, {
        y: -100, // Back to original HTML value
        rotation: 0,
        opacity: 1,
        scale: 1
      }, {
        y: 500, // Back to original HTML value
        rotation: () => Math.random() * 720 - 360,
        opacity: 0,
        scale: () => 0.5 + Math.random() * 0.5,
        duration: 2,
        stagger: {
          each: 0.02,
          from: 'random'
        },
        ease: 'power1.out',
        onComplete: () => {
          // Ensure all particles are properly returned
          particles.forEach(p => {
            p.style.display = 'none';
            p.style.opacity = '0';
            this.returnConfetti(p);
          });
        }
      });
    }
  }

  reset(): void {
    if (this.timeline) {
      this.timeline.kill();
    }
    // Clear all active confetti
    this.active.forEach(confetti => {
      confetti.style.display = 'none';
      confetti.style.transform = '';
      confetti.style.opacity = '0';
      if (typeof gsap !== 'undefined') {
        gsap.set(confetti, { clearProps: 'all' });
      }
      this.pool.push(confetti);
    });
    this.active = [];
    // Also clear any orphaned confetti in the container
    const allConfetti = this.container.querySelectorAll('.accounts-feature__confetti');
    allConfetti.forEach((confetti: any) => {
      confetti.style.display = 'none';
      confetti.style.opacity = '0';
    });
  }
}
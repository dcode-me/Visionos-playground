import { Component, OnInit, AfterViewInit, OnDestroy, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

declare const gsap: any;

@Component({
  selector: 'app-erp-animation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './erp-animation.component.html',
  styleUrls: ['./erp-animation.component.scss']
})
export class ErpAnimationComponent implements OnInit, AfterViewInit, OnDestroy {
  
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      // ERP animation implementation with 3 scenes
      this.initPlaceholderAnimation();
    }
  }

  ngOnDestroy(): void {
  }

  private initPlaceholderAnimation(): void {
    if (typeof gsap !== 'undefined') {
    }
  }
}
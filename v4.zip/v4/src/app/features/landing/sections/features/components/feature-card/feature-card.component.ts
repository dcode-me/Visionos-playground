import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountsAnimationComponent } from '../accounts-animation/accounts-animation.component';
import { ApiAnimationComponent } from '../api-animation/api-animation.component';
import { ErpAnimationComponent } from '../erp-animation/erp-animation.component';
import { PartnerCarouselComponent } from '../partner-carousel/partner-carousel.component';

export interface FeatureData {
  id: string;
  type: 'erp' | 'api' | 'accounts' | 'partners';
  icon: string;
  title: string;
  description: string;
  backgroundColor: 'gray' | 'white';
  additionalItems?: {
    title?: string;
    items: Array<{
      label: string;
      icon?: string;
    }>;
  };
}

@Component({
  selector: 'app-feature-card',
  standalone: true,
  imports: [
    CommonModule, 
    AccountsAnimationComponent,
    ApiAnimationComponent,
    ErpAnimationComponent,
    PartnerCarouselComponent
  ],
  templateUrl: './feature-card.component.html',
  styleUrls: ['./feature-card.component.scss']
})
export class FeatureCardComponent {
  @Input() feature!: FeatureData;
}
# Marketplace Micro Frontend Reference

## Overview

This project is a modular micro frontend (MFE) implementation for a business banking marketplace web application. It demonstrates a scalable, maintainable approach to building a marketplace using modern web technologies, modular architecture, and responsive design.

---

## Purpose

- **Marketplace**: A web app for business banking solutions, featuring a homepage with product cards, navigation tabs, and detailed product pages (e.g., Deposit Accounts, Xero integration).
- **Micro Frontend**: The UI is split into modular, reusable components (MFEs) that can be loaded dynamically into host pages.

---

## Key Features

- **Homepage with Tabs**: Displays categories (Accounts, Service Settings, App Integration, Partner Offers, API) as tabs, each showing a grid of product cards.
- **Product Pages**: Dedicated pages for products like Deposit Accounts and Xero, each with a header and a two- or three-column layout for content, overview, and CTAs.
- **Responsive Design**: Uses CSS container queries and grid layouts for responsive behavior across devices.
- **Annotation Overlay**: Developer overlays show card/container dimensions for design QA.

---

## Project Structure

```
HtmlPlayground/MP_Reference_Final/
├── css/
│   ├── cards.css
│   ├── mp_homepage_mfe.css
│   ├── depositaccounts.css
│   ├── xero.css
│   └── host-pro.css
├── js/
│   ├── mfe.js
│   ├── host_pro.js
│   ├── annotation.js
│   ├── EN.json
│   └── FR.json (French localization data)
├── partials/
│   ├── mfe-home.html       ← maps to `?product=home`
│   ├── mfe-depositaccounts.html ← maps to `?product=DepositAccounts`
│   └── mfe-xero.html        ← maps to `?product=Xero`
├── pages/
│   ├── Homepage.html
│   ├── DepositAccounts.html
│   ├── Xero.html
│   └── Lite.html
└── README.md
```

---

## Main Files & Folders

- **pages/**: Host HTML files for the main app, Deposit Accounts, Xero, and Lite version.
- **partials/**: HTML fragments for MFE content, loaded dynamically into host pages.
- **css/**: Stylesheets for cards, layout shells, product pages, and host-specific styles.
- **js/**:
  - `mfe.js`: Loads product data, renders tabs/cards, handles tab switching, and navigation.
  - `host_pro.js`: Handles annotation toggling and language selection for the Pro host.
  - `annotation.js`: Renders overlays showing dimensions for cards and containers.
  - `EN.json`: Product/category data in English.
  - `FR.json` (French localization data)

---

## How It Works

1. **Host Page Loads**: A host HTML page (e.g., Homepage.html) loads the main CSS/JS and an empty `.mfe-container`.
2. **Partial Injection**: On load, JavaScript fetches the appropriate partial (e.g., `mfe-home.html`, `mfe-depositaccounts.html`, `mfe-xero.html`) and injects it into `.mfe-container`.
3. **Dynamic Rendering**: The MFE JS (`mfe.js`) loads product/category data from `EN.json`, renders tabs and cards, and handles navigation (e.g., clicking a card navigates to a product page).
4. **Responsive Layout**: CSS container queries adjust the grid and layout based on container width, not just viewport size.
5. **Annotations**: Developers can toggle overlays to see real-time card/container dimensions for QA.
- **Annotations**: Click the “Enable Annotations” button in the top nav (Pro) or call `renderAnnotations()` in the console (Lite) to view dimension overlays.

---

## Breakpoints & Container Queries

Key responsive configurations:
- **Marketplace Grid (Homepage)**  
  - ≥1280px: 3 columns (min 384px, max 448px), 32px gap  
  - 1024–1279px: 3 columns (min 384px, max 384px), 24px gap  
  - 768–1023px: 2 columns (min 320px), 24px gap  
  - 448–599px: 1 column (min 320px), 16px gap  
  - <448px: 1 column (scaled), 16px gap  
- **Product Page (DepositAccounts)**  
  - ≥864px: 2 columns (minmax(424px,1fr) + minmax(384px,480px)), 24px gap  
  - <864px: 1 column, 24px gap  
- **Product Page (Xero)**  
  - ≥1142px: 3 columns (160px + minmax(384px,1fr) + minmax(384px,480px)), 24px gap  
  - <1142px: 2 columns (160px + 1fr), CTA spans full width, 24px gap  
- **Header Shell Padding (MQ)**  
  - <768px: 16px horizontal  
  - 768–1023px: 24px horizontal  
  - ≥1024px: 32px horizontal

---

## Example Flow

- User lands on the homepage: sees tabs and cards.
- Clicking a card (e.g., "Deposit Accounts") loads the corresponding partial/page.
- The product page uses a grid layout for logo, overview, and CTA sections.
- All layouts are responsive and annotated for developer inspection.

> **Note:** All images (e.g. `header_image.svg`) live in `assets/images/` relative to the `partials/` directory.

---

## Summary

This project is a well-structured, scalable micro frontend for a business banking marketplace, focusing on modularity, responsive design, and developer experience (annotations, container queries). It separates host logic, MFE rendering, and product data for maintainability and reuse.

---

## Getting Started

1. **Serve the Project from a Local Server**  
   For proper loading of partials and assets, run a local server in the `HtmlPlayground/MP_Reference_Final/` directory.  
   - If you have Python installed, you can use:
     - Python 3:  
       ```
       python3 -m http.server 8000
       ```
     - Python 2:  
       ```
       python -m SimpleHTTPServer 8000
       ```
   - Or use any other static server (e.g., `npx serve`, `http-server`, etc.).

   **Alternatively, you can use the Live Server extension in VS Code:**
   - Install the [Live Server extension](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) from the VS Code Extensions marketplace.
   - Right-click on `Homepage.html` or `Lite.html` in the `pages/` folder and select **"Open with Live Server"**.
   - This will automatically launch your default browser and serve the project with live reload.

2. **Access the Application in Your Browser**  
   - For the **Pro version**, open:  
     [http://localhost:8000/pages/Homepage.html](http://localhost:8000/pages/Homepage.html)
   - For the **Lite version**, open:  
     [http://localhost:8000/pages/Lite.html](http://localhost:8000/pages/Lite.html)
   - **Lite version**: open `http://localhost:8000/pages/Lite.html?product=home` to view the side-nav host shell.

3. The app will dynamically load the appropriate MFE partial and render the UI.

4. Use the annotation toggle (if available) for developer overlays.

---

## License

For demonstration and educational purposes only.

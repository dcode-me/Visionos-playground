/**
 * mfe.js
 * Micro-frontend initializer for Marketplace:
 * - Loads language JSON data
 * - Renders tabs and cards
 * - Handles tab and card navigation
 * - Exposes initialization APIs for host integration
 */

// -- Global Configuration --
window.currentLanguage = 'EN';

// Base path for navigation (current host page)
const MFE_BASE_PATH = window.location.pathname;

// -- Load and Render Marketplace Data --
function loadData(lang) {
  fetch(`../js/${lang}.json`)
    .then(res => res.json())
    .then(data => {
      const tabsList = document.querySelector('.tabs');
      tabsList.innerHTML = '';
      const categories = Object.keys(data);
      // Generate tabs
      categories.forEach((key, idx) => {
        const tab = document.createElement('li');
        tab.className = 'tab';
        tab.dataset.tab = key;
        tab.textContent = data[key].Title || key;
        if (idx === 0) tab.classList.add('active');
        tabsList.appendChild(tab);
      });
      // Attach tab handlers
      tabsList.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
          document.querySelector('.tab.active').classList.remove('active');
          tab.classList.add('active');
          renderCards(data, tab.dataset.tab);
        });
      });
      // Render initial cards
      renderCards(data, categories[0]);
    })
    .catch(err => console.error(`Failed to load ${lang}.json`, err));
}

// -- Card Element Factory --
function createCard(cardData) {
	const card = document.createElement("div");
	card.className = `card ${cardData.cardType}`;

	if (cardData.logoType) {
		const logo = document.createElement("img");
		logo.src =
			"https://olbbdemo.dev.bmo.com/ui/MarketPlaceWeb/assets/images/SJ_BMO.svg";
		logo.alt = `${cardData.logoType} logo`;
		logo.className = "card-logo";
		logo.width = 48;
		logo.height = 48;
		card.appendChild(logo);
	}

	if (cardData.title || cardData.description) {
		const textGroup = document.createElement("div");
		textGroup.className = "card-text";

		if (cardData.title) {
			const titleEl = document.createElement(
				cardData.cardType === "card-03" ? "h3" : "h3"
			);
			titleEl.className = "card-title";
			titleEl.textContent = cardData.title;
			textGroup.appendChild(titleEl);
		}
		if (cardData.cardType !== "card-03" && cardData.description) {
			const descEl = document.createElement("p");
			descEl.className = "card-description";
			descEl.innerHTML = cardData.description;
			textGroup.appendChild(descEl);
		}
		card.appendChild(textGroup);
	}

	if (cardData.link && cardData.cardType === "card-02") {
		const linkEl = document.createElement("a");
		linkEl.className = "card-link";
		linkEl.href = cardData.link;
		linkEl.textContent = cardData.linkText;
		card.appendChild(linkEl);
	}

	if (cardData.cardType === "card-03") {
		const button = document.createElement("button");
		button.className = "card-button";
		button.textContent = "Suggest an app";
		card.appendChild(button);
	}

	// Wrap card in link wrapper if URL is provided
	if (cardData.url) {
	  const wrapper = document.createElement('a');
	  wrapper.href = cardData.url;
	  wrapper.className = 'card-link-wrapper';
	  wrapper.appendChild(card);
	  return wrapper;
	}
	return card;
}

// -- Render Cards for Active Tab --
function renderCards(data, categoryKey) {
  const container = document.getElementById('MP_HP_tabs_content');
  container.innerHTML = '';
  const items = data[categoryKey];
  Object.keys(items).forEach(key => {
    if (key === 'Title') return;
    const item = items[key];
    // Determine product navigation URL
    let url = null;
    if (categoryKey === 'Accounts' && key === 'deposit_accounts') {
      url = `${MFE_BASE_PATH}?product=DepositAccounts`;
    } else if (categoryKey === 'App Integeration' && key === 'xero') {
      url = `${MFE_BASE_PATH}?product=Xero`;
    }
    const cardData = {
      logoType: 'BMO',
      title: item.title,
      description: item.short_description,
      link: item.link_text || null,
      url: url,
      linkText: item.link_text || null,
      cardType: getCardType(categoryKey, key)
    };
    container.appendChild(createCard(cardData));
  });
  // Always move the existing Suggest an app card to the end
  const suggestCardEl = container.querySelector('.card-03');
  if (suggestCardEl) {
    container.appendChild(suggestCardEl);
  }
}

// -- Determine Card Type by Category --
function getCardType(categoryKey, itemKey) {
  if (['Partner Offers', 'API'].includes(categoryKey)) {
    return 'card-02';
  }
  if (categoryKey === 'App Integeration' && itemKey === 'suggest_app') {
    return 'card-03';
  }
  return 'card-01';
}

// -- Tab Background Color Handler --
document.querySelectorAll(".tab").forEach((tab) => {
	tab.addEventListener("click", () => {
		// Toggle active state
		document.querySelector(".tab.active").classList.remove("active");
		tab.classList.add("active");
		// Change background of tabs content
		const container = document.getElementById("MP_HP_tabs_content");
		switch (tab.dataset.tab) {
			case "tab1":
				container.style.background = "#ffe0e0";
				break;
			case "tab2":
				container.style.background = "#e0ffe0";
				break;
			case "tab3":
				container.style.background = "#e0e0ff";
				break;
			case "tab4":
				container.style.background = "#ffffe0";
				break;
			case "tab5":
				container.style.background = "#e0ffff";
				break;
		}
	});
});

// -- Expose Initialization API to Host --
window.initializeMarketplace = function() {
  if (typeof loadData === 'function') {
    loadData(window.currentLanguage);
  }
};
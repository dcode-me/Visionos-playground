import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { DesignSystemService } from './core/design-system/design-system.service';
import { GsapService } from './core/animations/gsap.service';
import { StickyHeaderComponent } from './features/landing/sections/header/sticky-header.component';
import { HeroExperienceComponent } from './features/landing/sections/hero-experience/hero-experience.component';
import { FeaturesContainerComponent } from './features/landing/sections/features/features-container.component';
import { CtaSectionComponent } from './features/landing/sections/cta-section/cta-section.component';

@Component({
  selector: 'app-root',
  imports: [StickyHeaderComponent, HeroExperienceComponent, FeaturesContainerComponent, CtaSectionComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'BMO Marketplace';
  private designSystem = inject(DesignSystemService);
  private gsapService = inject(GsapService);

  ngOnInit() {
    // Initialize app
  }

  ngOnDestroy() {
    // Clean up all GSAP animations
    this.gsapService.cleanupAll();
  }
}

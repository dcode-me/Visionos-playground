import { Component, OnInit, AfterViewInit, ElementRef, inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { TranslationService } from '../../../../core/services/translation.service';

declare const gsap: any;
declare const ScrollTrigger: any;

@Component({
  selector: 'app-cta-section',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cta-section.component.html',
  styleUrls: ['./cta-section.component.scss']
})
export class CtaSectionComponent implements OnInit, AfterViewInit {
  translationService = inject(TranslationService);
  private elementRef = inject(ElementRef);
  private platformId = inject(PLATFORM_ID);
  
  ctaCards = [
    {
      id: 'submitproduct',
      titleKey: 'cta.cards.submitProduct.title',
      buttonKey: 'cta.cards.submitProduct.button',
      ariaKey: 'cta.cards.submitProduct.aria',
      colorClass: 'white'
    },
    {
      id: 'newtobmo',
      titleKey: 'cta.cards.newToBmo.title',
      buttonKey: 'cta.cards.newToBmo.button',
      ariaKey: 'cta.cards.newToBmo.aria',
      colorClass: 'brand-50'
    },
    {
      id: 'signin',
      titleKey: 'cta.cards.signin.title',
      buttonKey: 'cta.cards.signin.button',
      ariaKey: 'cta.cards.signin.aria',
      colorClass: 'brand-70'
    }
  ];
  
  hoveredButton: string | null = null;

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initializeAnimations();
    }
  }

  private initializeAnimations(): void {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      return;
    }

    const element = this.elementRef.nativeElement;
    const section = element.querySelector('.cta-section');
    const cards = element.querySelectorAll('.cta-section__card');
    
    if (!section || !cards.length) return;
    
    gsap.set(cards, {
      opacity: 0,
      y: 30
    });
    
    gsap.to(cards, {
      opacity: 1,
      y: 0,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power2.out',
      scrollTrigger: {
        trigger: section,
        start: 'top 80%',
        once: true
      }
    });
  }

  onButtonHover(cardId: string): void {
    this.hoveredButton = cardId;
  }

  onButtonLeave(): void {
    this.hoveredButton = null;
  }

  isButtonHovered(cardId: string): boolean {
    return this.hoveredButton === cardId;
  }

  onCtaClick(cardId: string): void {
    switch(cardId) {
      case 'signin':
        break;
      case 'newtobmo':
        break;
      case 'submitproduct':
        break;
    }
  }
}
import { Component, OnInit, AfterViewInit, OnDestroy, Inject, PLATFORM_ID, ViewChild, ElementRef } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

declare const gsap: any;

@Component({
  selector: 'app-api-animation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './api-animation.component.html',
  styleUrls: ['./api-animation.component.scss']
})
export class ApiAnimationComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('animationContainer', { static: false }) container!: ElementRef;
  
  private cards: any[] = [];
  private currentIndex = 0;
  private isAnimating = false;
  
  private readonly cardPositions = [
    { x: 0, y: 0, z: 0, rotateY: -2, rotateX: 1, opacity: 1, scale: 1, zIndex: 3 },
    { x: 35, y: -60, z: -50, rotateY: -2, rotateX: 1, opacity: 0.95, scale: 0.97, zIndex: 2 },
    { x: 70, y: -120, z: -100, rotateY: -2, rotateX: 1, opacity: 0.90, scale: 0.94, zIndex: 1 }
  ];
  
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initAnimation();
    }
  }

  ngOnDestroy(): void {
    this.cleanup();
  }

  private initAnimation(): void {
    if (typeof gsap === 'undefined' || !this.container) return;
    
    const el = this.container.nativeElement;
    this.cards = Array.from(el.querySelectorAll('.api-animation__card'));
    
    gsap.set('.api-animation__code-line', { opacity: 0, y: 10 });
    
    this.updateCards(false);
    this.animateCodeLines(this.cards[0]);
    
    this.setupCardInteractions();
    
    this.playEntranceAnimations();
  }
  
  private animateCodeLines(card: HTMLElement): void {
    if (typeof gsap === 'undefined') return;
    
    const codeLines = card.querySelectorAll('.api-animation__code-line');
    gsap.to(codeLines, {
      opacity: 1,
      y: 0,
      duration: 0.4,
      stagger: 0.05,
      ease: "power2.out"
    });
  }
  
  private hideCodeLines(card: HTMLElement): void {
    if (typeof gsap === 'undefined') return;
    
    const codeLines = card.querySelectorAll('.api-animation__code-line');
    gsap.to(codeLines, {
      opacity: 0,
      y: 10,
      duration: 0.2,
      stagger: 0.02,
      ease: "power2.in"
    });
  }
  
  private updateCards(animate = true): void {
    if (this.isAnimating || typeof gsap === 'undefined') return;
    this.isAnimating = true;
    
    let animationCount = 0;
    let totalAnimations = animate ? this.cards.length : 0;
    
    this.cards.forEach((card, index) => {
      const cardIndex = parseInt(card.dataset.index);
      const positionIndex = (cardIndex - this.currentIndex + 3) % 3;
      const position = this.cardPositions[positionIndex];
      
      if (animate) {
        gsap.to(card, {
          x: position.x,
          y: position.y,
          z: position.z,
          rotateY: position.rotateY,
          rotateX: position.rotateX,
          opacity: position.opacity,
          scale: position.scale,
          zIndex: position.zIndex,
          duration: 0.6,
          ease: "power2.inOut",
          onComplete: () => {
            if (positionIndex === 0) {
              this.animateCodeLines(card);
            }
            animationCount++;
            if (animationCount === totalAnimations) {
              this.isAnimating = false;
            }
          }
        });
        
        if (positionIndex !== 0) {
          this.hideCodeLines(card);
        }
      } else {
        gsap.set(card, {
          x: position.x,
          y: position.y,
          z: position.z,
          rotateY: position.rotateY,
          rotateX: position.rotateX,
          opacity: position.opacity,
          scale: position.scale,
          zIndex: position.zIndex
        });
        
        if (positionIndex === 0) {
          this.animateCodeLines(card);
        }
      }
    });
    
    if (!animate) {
      this.isAnimating = false;
    }
  }
  
  private setupCardInteractions(): void {
    if (typeof gsap === 'undefined') return;
    
    this.cards.forEach((card, index) => {
      card.addEventListener('mouseenter', () => {
        const cardIndex = parseInt(card.dataset.index);
        const positionIndex = (cardIndex - this.currentIndex + 3) % 3;
        
        gsap.killTweensOf(card);
        
        if (positionIndex === 0) {
          gsap.to(card, {
            scale: 1.02,
            boxShadow: "0 0 0 2px rgba(78, 205, 196, 0.6), 0 20px 60px -10px rgba(78, 205, 196, 0.4), 0 30px 80px -20px rgba(0, 0, 0, 0.3)",
            filter: "brightness(1.08) contrast(1.05)",
            duration: 0.05,
            ease: "power2.out",
            overwrite: true
          });
        } else if (positionIndex === 1) {
          gsap.to(card, {
            y: -75,
            scale: 0.99,
            boxShadow: "0 0 0 2px rgba(255, 159, 67, 0.6), 0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            duration: 0.06,
            ease: "power2.out",
            overwrite: true
          });
        } else if (positionIndex === 2) {
          gsap.to(card, {
            y: -135,
            scale: 0.96,
            boxShadow: "0 0 0 2px rgba(255, 107, 107, 0.6), 0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            duration: 0.06,
            ease: "power2.out",
            overwrite: true
          });
        }
      });
      
      card.addEventListener('mouseleave', () => {
        const cardIndex = parseInt(card.dataset.index);
        const positionIndex = (cardIndex - this.currentIndex + 3) % 3;
        
        if (positionIndex === 0) {
          gsap.to(card, {
            scale: 1,
            boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            filter: "brightness(1) contrast(1)",
            duration: 0.15,
            ease: "elastic.out(1, 0.8)",
            overwrite: true
          });
        } else if (positionIndex === 1) {
          const position = this.cardPositions[1];
          gsap.to(card, {
            y: position.y,
            scale: position.scale,
            boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            duration: 0.18,
            ease: "elastic.out(1, 0.8)",
            delay: 0.02,
            overwrite: true
          });
        } else if (positionIndex === 2) {
          const position = this.cardPositions[2];
          gsap.to(card, {
            y: position.y,
            scale: position.scale,
            boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            duration: 0.18,
            ease: "elastic.out(1, 0.8)",
            delay: 0.02,
            overwrite: true
          });
        }
      });
      
      card.addEventListener('click', (e: Event) => {
        e.stopPropagation();
        const cardIndex = parseInt(card.dataset.index);
        const positionIndex = (cardIndex - this.currentIndex + 3) % 3;
        
        if (positionIndex !== 0 && !this.isAnimating) {
          this.currentIndex = cardIndex;
          this.updateCards();
        }
      });
    });
  }
  
  private playEntranceAnimations(): void {
    if (typeof gsap === 'undefined') return;
    
    gsap.from('.api-animation__wrapper', {
      opacity: 0,
      x: 30,
      duration: 1,
      delay: 0.2,
      ease: "power3.out"
    });
  }
  
  private cleanup(): void {
    if (typeof gsap !== 'undefined' && this.cards) {
      this.cards.forEach(card => {
        gsap.killTweensOf(card);
      });
    }
  }
}
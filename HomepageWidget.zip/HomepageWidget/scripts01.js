document.addEventListener("DOMContentLoaded", function () {
	const smallTableBody = document.querySelector(".small-table tbody");
	const largeTableBody = document.querySelector(".large-table tbody");
	const totalsBalances = document.querySelector(".totals-balances");
	const largerTotalsTable = document.querySelector(".totals-table tbody");

	let accountData = [];

	// Establish WebSocket connection
	const ws = new WebSocket("ws://localhost:8080");

	ws.onmessage = function (event) {
		const data = JSON.parse(event.data);
		data.forEach((account) => {
			accountData.push(account);
			updateTables(account);
			updateTotals();
		});
	};

	function updateTables(data) {
		const smallTableRow = `
        <tr>
          <td>
            <div class="account-name">${data.accountName}</div>
            <div class="account-number">${data.accountNumber}</div>
          </td>
          <td>
            <div class="balance">${data.balance}</div>
            <div class="balance-label">Current Balance</div>
          </td>
        </tr>
      `;

		const largeTableRow = `
        <tr>
          <td>${data.accountNumber}</td>
          <td>${data.accountName}</td>
          <td>${data.currency}</td>
          <td>${data.balance}</td>
          <td>${data.previousBalance}</td>
        </tr>
      `;

		smallTableBody.insertAdjacentHTML("beforeend", smallTableRow);
		largeTableBody.insertAdjacentHTML("beforeend", largeTableRow);
	}

	function updateTotals() {
		const totals = accountData.reduce((acc, account) => {
			if (!acc[account.currency]) {
				acc[account.currency] = { balance: 0, previousBalance: 0 };
			}
			acc[account.currency].balance += parseFloat(account.balance);
			acc[account.currency].previousBalance += parseFloat(
				account.previousBalance
			);
			return acc;
		}, {});

		totalsBalances.innerHTML = "";
		largerTotalsTable.innerHTML = "";

		let firstCurrency = true;

		for (const [currency, total] of Object.entries(totals)) {
			const roundedBalance = total.balance.toFixed(2);
			const roundedPreviousBalance = total.previousBalance.toFixed(2);

			totalsBalances.insertAdjacentHTML(
				"beforeend",
				`<div>${roundedBalance} ${currency}</div>`
			);
			largerTotalsTable.insertAdjacentHTML(
				"beforeend",
				`
			<tr>
			  <td style="width: 150px;"></td>
			  <th style="width: 150px;">${firstCurrency ? "Totals" : ""}</th>
			  <td style="width: 100px;">${currency}</td>
			  <td style="width: 155px;">${roundedBalance}</td>
			  <td style="width: 155px;">${roundedPreviousBalance}</td>
			</tr>
		  `
			);
			firstCurrency = false;
		}
	}
	const expandIcon = document.getElementById("expandIcon");
	const collapseIcon = document.getElementById("collapseIcon");
	const widget = document.getElementById("widget");
	const smallTableSection = document.querySelector(".small-table-section");
	const largeTableSection = document.querySelector(".large-table-section");

	expandIcon.addEventListener("click", () => {
		widget.classList.add("expanded");
		expandIcon.style.display = "none";
		collapseIcon.style.display = "inline";
		smallTableSection.style.display = "none";
		largeTableSection.style.display = "block";
	});

	collapseIcon.addEventListener("click", () => {
		widget.classList.remove("expanded");
		expandIcon.style.display = "inline";
		collapseIcon.style.display = "none";
		smallTableSection.style.display = "block";
		largeTableSection.style.display = "none";
	});
});

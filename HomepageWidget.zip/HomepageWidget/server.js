const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });

// Generate stub data
const currencies = ['CAD', 'USD'];
const accounts = Array.from({ length: 660 }, (_, i) => {
    const currency = currencies[i % currencies.length];
    const balance = (Math.random() * 10000).toFixed(2);
    const previousBalance = (balance - (Math.random() * 500)).toFixed(2);
    return {
        accountName: `Account ${i + 1}`,
        accountNumber: `000${i + 1}`,
        currency: currency,
        balance: balance,
        previousBalance: previousBalance
    };
});

wss.on('connection', ws => {
    console.log('Client connected');
    ws.on('message', message => {
        console.log(`Received: ${message}`);
        const request = JSON.parse(message);

        if (request.type === 'AccountDetails') {
            const accountDetails = accounts.map(account => ({
                accountNumber: account.accountNumber,
                accountName: account.accountName,
                currency: account.currency
            }));
            ws.send(JSON.stringify(accountDetails));
        } else if (request.type === 'AccountBalances') {
            let index = 0;
            const chunkSize = 1;
            const sendChunk = () => {
                if (index < accounts.length) {
                    const accountBalances = accounts.slice(index, index + chunkSize).map(account => ({
                        accountNumber: account.accountNumber,
                        balance: account.balance,
                        previousBalance: account.previousBalance
                    }));
                    ws.send(JSON.stringify(accountBalances));
                    index += chunkSize;
                    setTimeout(sendChunk, 200); // Simulate delay
                }
            };
            sendChunk();
        }
    });
});

console.log('WebSocket server is running on ws://localhost:8080');
document.addEventListener("DOMContentLoaded", function () {
	const smallTableBody = document.querySelector(".small-table tbody");
	const largeTableBody = document.querySelector(".large-table tbody");
	const totalsBalances = document.querySelector(".totals-balances");
	const largerTotalsTable = document.querySelector(".totals-table tbody");

	let accountData = [];

	const stubData = [
		{
			accountName: "Account 1",
			accountNumber: "001",
			currency: "CAD",
			balance: "1000.00",
			previousBalance: "950.00",
		},
		{
			accountName: "Account 2",
			accountNumber: "002",
			currency: "CAD",
			balance: "2000.00",
			previousBalance: "1950.00",
		},
		{
			accountName: "Account 3",
			accountNumber: "003",
			currency: "USD",
			balance: "1500.00",
			previousBalance: "1450.00",
		},
		{
			accountName: "Account 4",
			accountNumber: "004",
			currency: "USD",
			balance: "2500.00",
			previousBalance: "2450.00",
		},
	];

	function simulateDataLoad() {
		stubData.forEach((data, index) => {
			setTimeout(() => {
				accountData.push(data);
				updateTables(data);
				updateTotals();
			}, index * 5000); // Simulate data arrival every second
		});
	}

	function updateTables(data) {
		const smallTableRow = `
        <tr>
          <td>
            <div class="account-name">${data.accountName}</div>
            <div class="account-number">${data.accountNumber}</div>
          </td>
          <td>
            <div class="balance">${data.balance}</div>
            <div class="balance-label">Current Balance</div>
          </td>
        </tr>
      `;

		const largeTableRow = `
        <tr>
          <td>${data.accountNumber}</td>
          <td>${data.accountName}</td>
          <td>${data.currency}</td>
          <td>${data.balance}</td>
          <td>${data.previousBalance}</td>
        </tr>
      `;

		smallTableBody.insertAdjacentHTML("beforeend", smallTableRow);
		largeTableBody.insertAdjacentHTML("beforeend", largeTableRow);
	}

    function updateTotals() {
        const totals = accountData.reduce((acc, account) => {
          if (!acc[account.currency]) {
            acc[account.currency] = { balance: 0, previousBalance: 0 };
          }
          acc[account.currency].balance += parseFloat(account.balance);
          acc[account.currency].previousBalance += parseFloat(account.previousBalance);
          return acc;
        }, {});
    
        totalsBalances.innerHTML = '';
        largerTotalsTable.innerHTML = '';
    
        let firstCurrency = true;
    
        for (const [currency, total] of Object.entries(totals)) {
          totalsBalances.insertAdjacentHTML('beforeend', `<div>${total.balance} ${currency}</div>`);
          largerTotalsTable.insertAdjacentHTML('beforeend', `
            <tr>
              <td style="width: 150px;"></td>
              <th style="width: 150px;">${firstCurrency ? 'Totals' : ''}</th>
              <td style="width: 100px;">${currency}</td>
              <td style="width: 155px;">${total.balance}</td>
              <td style="width: 155px;">${total.previousBalance}</td>
            </tr>
          `);
          firstCurrency = false;
        }
      }

	

	const expandIcon = document.getElementById("expandIcon");
	const collapseIcon = document.getElementById("collapseIcon");
	const widget = document.getElementById("widget");
	const smallTableSection = document.querySelector(".small-table-section");
	const largeTableSection = document.querySelector(".large-table-section");

	expandIcon.addEventListener("click", () => {
		widget.classList.add("expanded");
		expandIcon.style.display = "none";
		collapseIcon.style.display = "inline";
		smallTableSection.style.display = "none";
		largeTableSection.style.display = "block";
	});

	collapseIcon.addEventListener("click", () => {
		widget.classList.remove("expanded");
		expandIcon.style.display = "inline";
		collapseIcon.style.display = "none";
		smallTableSection.style.display = "block";
		largeTableSection.style.display = "none";
	});

	simulateDataLoad();
});

const expandIcon = document.getElementById("expandIcon");
const collapseIcon = document.getElementById("collapseIcon");
const widget = document.getElementById("widget");
const smallTableSection = document.querySelector(".small-table-section");
const largeTableSection = document.querySelector(".large-table-section");

expandIcon.addEventListener("click", () => {
	widget.classList.add("expanded");
	expandIcon.style.display = "none";
	collapseIcon.style.display = "inline";
	smallTableSection.style.display = "none";
	largeTableSection.style.display = "block";
});

collapseIcon.addEventListener("click", () => {
	widget.classList.remove("expanded");
	expandIcon.style.display = "inline";
	collapseIcon.style.display = "none";
	smallTableSection.style.display = "block";
	largeTableSection.style.display = "none";
});

import { PerfectScrollbarModule, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { accountDetailComponent } from './deposit-accountdetails-overlay/account-details.component';
import { viewBalanceComponent } from './deposit-view-balances/deposit-view-balances.component';
import { NgModule } from '@angular/core';
import { DepositAcctBalancesComponent } from './deposit-acct-balances.component';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragDropModule } from "@angular/cdk/drag-drop";
import { SearchPipe} from './pipes/search.pipe';
import { PopoverModule } from 'ngx-popover';
import { DateRangePickerModule } from './daterangepicker/daterangepicker.module';

@NgModule({
  declarations: [DepositAcctBalancesComponent,
     SearchPipe, viewBalanceComponent, accountDetailComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DragDropModule,
    PopoverModule,
    DateRangePickerModule,
    PerfectScrollbarModule
  ],
  exports: [DepositAcctBalancesComponent,SearchPipe,viewBalanceComponent,accountDetailComponent],
  entryComponents: [DepositAcctBalancesComponent,viewBalanceComponent,accountDetailComponent]
})
export class DepositAcctBalancesModule { }

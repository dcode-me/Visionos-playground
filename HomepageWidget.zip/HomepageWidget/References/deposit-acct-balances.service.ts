import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { Response, ResponseContentType } from '@angular/http';


@Injectable({
  providedIn: 'root'
})
export class DepositAcctBalancesService {
  public http: HttpClient;
  customizedAccounts:any = "/apihp/RestAccountBalanceSvc/customizeAccount";
  depositAccountsURL :any = "/apihp/RestAccountBalanceSvc/acctbal/balance";
  PDFAccountsURL :any = "/apihp/RestAccountBalanceSvc/acctbal/exportpdf";
  csvAccountsURL:any = "/apihp/RestAccountBalanceSvc/acctbal/exportcsv";
  accountDetailsURL:any = "/apihp/RestAccountBalanceSvc/acctbal";
  transactions:any ="/apihp/RestAccountBalanceSvc/acctbal/";
  filterTransaction:any = "/apihp/RestAccountBalanceSvc/";
  downloadAccountDetailsURL:any = "/apihp/RestAccountBalanceSvc/acctbal/transactions/search/";
  getaccountdetails :any= "/apihp/RestAccountBalanceSvc/acctbal";
  tmpaccountDetailsList:any =[];
  stopevent: boolean = true;
  constructor() { }

  public getDepositEntitle() {
     return this.http.get('assets/mock-data/GET_ACCOUNT_Entitle.json', { responseType: 'json' });
    //return this.http.get(this.getaccountdetails + '/GET_ACCOUNT_DETAILS?rnd=' + new Date().getTime());
   }


  public getDepositAccounts() {
    return this.http.get('assets/mock-data/GET_ACCOUNT_DETAILS.json', { responseType: 'json' });

    //return this.http.get('/apihp/RestAccountBalanceSvc/acctbal/GET_ACCOUNT_DETAILS');
   //return this.http.get(this.depositAccountsURL + '/GET_DEPOSIT_ACCOUNT_BALANCE?rnd=' + new Date().getTime());
  }
  public getCustomizedAccounts() {
    //return this.http.get(this.customizedAccounts + '/GET_ACCOUNT_DEPOSIT?rnd=' + new Date().getTime());
     return this.http.get('assets/mock-data/deposit_customize_accounts.json', { responseType: 'json' });
}
 public getPDFAccounts() {
  window.open(this.PDFAccountsURL + '/Deposit?rnd=' + new Date().getTime());
    // return this.http.get('assets/mock-data/deposit_customize_accounts.json', { responseType: 'json' });
}
public getCSVAccounts() {
  // return this.http.get(this.csvAccountsURL + '/Deposit?rnd=' + new Date().getTime(),{observe: 'response', responseType: 'blob'});
  window.open(this.csvAccountsURL + '/Deposit?rnd=' + new Date().getTime());
}
public getAccountDetails(postData): Observable<any> {
  return this.http.get('assets/mock-data/GET_ACCOUNT_PageDETAILS.json', { responseType: 'json' });
  //return this.http.post(this.accountDetailsURL + '/accountDetails?rnd=' + new Date().getTime(), postData);
}
public getAccountTransactionHistory(postData): Observable<any> {
  return this.http.get('assets/mock-data/deposit-transaction-history.json', { responseType: 'json' });
   //return this.http.post(this.transactions + 'transactions/?rnd=' + new Date().getTime(), postData);
}
filterResult(transType, jsonForPost) {
  //return this.http.get('assets/mock-data/deposit-transaction-history.json', { responseType: 'json' });
    return this.http.post(this.filterTransaction +'acctbal/' + transType, jsonForPost);
}
public getPDFAccountDetails() {
  window.open(this.downloadAccountDetailsURL + '/pdf?rnd=' + new Date().getTime());
}
public getCSVAccountDetails () {
  window.open(this.downloadAccountDetailsURL + '/csv?rnd=' + new Date().getTime());
}
public getQBOAccountDetails () {
  window.open(this.downloadAccountDetailsURL + '/qbo?rnd=' + new Date().getTime());
}
public getQFXAccountDetails () {
  window.open(this.downloadAccountDetailsURL + '/qfx?rnd=' + new Date().getTime());
}
stopBubbling(isInput: boolean, $event: KeyboardEvent) {
  if (!$event.shiftKey) {
    if (isInput) $event.stopPropagation();
    else $event.preventDefault();
  }
}

customSortAll(fieldName: string, isAscending: boolean, arrayToBeSorted: any, isNumeric?: boolean): any {
  if (fieldName === 'accountNumber' || fieldName ==='maskAccountNumber') {
      isNumeric = true;
    }        
  if (arrayToBeSorted.length > 0) {          
    if (fieldName === 'previousBalance' || fieldName === 'availableBalance' || fieldName=== 'currentBalance' || fieldName=== 'previousAvailableBalance') {
      isNumeric = true;
      arrayToBeSorted.sort(function (a: any, b: any) {
        if(a[fieldName] !== null && b[fieldName] !== null) {
        if (null == a[fieldName]['sortBalance'] || a[fieldName]['sortBalance'] === '' || a[fieldName]['statusMessage'] === 'NOTAVAIL') {
          return 1;
        } else if (null == b[fieldName]['sortBalance']  || b[fieldName]['sortBalance']  === '' || b[fieldName]['statusMessage']  === 'NOTAVAIL') {
          return -1;
        }
        // console.log(a[fieldName]);
        var aValue = isNumeric ? a[fieldName]['sortBalance']  : a[fieldName]['sortBalance'] .toUpperCase();
        var bValue = isNumeric ? b[fieldName]['sortBalance']  : b[fieldName]['sortBalance'] .toUpperCase();
        if (isNumeric) {
          if (typeof aValue == "number") {
            aValue = String(aValue);
            bValue = String(bValue);
          }
          // aValue = Number(aValue.replace(/\D/g, ''));
          // bValue = Number(bValue.replace(/\D/g, ''));
          aValue = Number(aValue.replace(/(?!^-)[^0-9.]/g, ''));
          bValue = Number(bValue.replace(/(?!^-)[^0-9.]/g, ''));
        }
        if (aValue === bValue) {
          return 0;
        } else if (isAscending) {
          return aValue < bValue ? -1 : 1;
        } else if (!isAscending) {
          return aValue < bValue ? 1 : -1;
        }
        } else {
          if (null == a[fieldName] || a[fieldName] === '') {
            return 1;
          } else if (null == b[fieldName] || b[fieldName] === '') {
            return -1;
          }
      }
      });
      
    } else {
      arrayToBeSorted.sort(function (a: any, b: any) {
        if (null == a[fieldName] || a[fieldName] === '') {
          return 1;
        } else if (null == b[fieldName] || b[fieldName] === '') {
          return -1;
        }
        // console.log(a[fieldName]);
        var aValue = isNumeric ? a[fieldName] : a[fieldName].toUpperCase();
        var bValue = isNumeric ? b[fieldName] : b[fieldName].toUpperCase();
        if (isNumeric) {
          if (typeof aValue == "number") {
            aValue = String(aValue);
            bValue = String(bValue);
          }
          aValue = Number(aValue.replace(/\D/g, ''));
          bValue = Number(bValue.replace(/\D/g, ''));
        }
        if (aValue === bValue) {
          return 0;
        } else if (isAscending) {
          return aValue < bValue ? -1 : 1;
        } else if (!isAscending) {
          return aValue < bValue ? 1 : -1;
        }
      });
    }

    }      

  return arrayToBeSorted;
  }

  public handleErrorPromise(error: Response | any) {
    console.error(error.message || error);
  }
}

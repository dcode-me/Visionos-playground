import { DepositAcctBalancesService } from './deposit-acct-balances.service';
import { Component, OnInit, ChangeDetectorRef, ViewChild, HostListener, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PerfectScrollbarModule, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Subscription } from 'rxjs';
declare let $: any;

@Component({
  selector: 'lib-deposit-acct-balances',
  templateUrl: './deposit-acct-balances-1col.component.html',
  styleUrls: ['./deposit-acct-balances.component.scss']
})
export class DepositAcctBalancesComponent implements OnInit, OnDestroy {
  // public widgetsize :any;
  colSpan: any;
  rowSpan: any;
  isMobile: any;
  public widget: any;
  public data: any;
  translations: any = {};
  showLoader: boolean = false;
  error: boolean = false;
  public http: HttpClient;
  depositAccountList: any = [];
  depositSummaryList: any = [];
  leftSummaryTotals: any = [];
  rightSummaryTotals: any = [];
  public errorString = "Unable to retrieve balances !!!";
  appLang: string = 'en';
  maskDepositFlag: boolean = false;
  sortType: any;
  sortIndex: number = 0;
  ascending: any = true;
  public eventService: any;
  searchValue: string = '';
  origDepositAccountList: any = [];
  noResultsFlag: boolean = false;
  searchFlag: boolean = false;
  public widgetid: any;
  widgetObj: any;
  noAcctSelectedFlag: boolean = false;
  activeDepositaccountDetails: any = [];
  //  @ViewChild('viewBalanceModal')viewBalanceModal :any;
  acctDetailsList = [];
  currentColumnFlag: boolean = false;
  previousColumnFlag: boolean = false;
  selectedColName: string;
  entitleEnable: any = false;
  largeWidgetFlag: boolean = false;
  smallWidgetFlag: boolean = false;
  terminateExecuton: boolean = false;
  summaryTotals = [];
  defaultSort: boolean = false;
  // firstTimeLoad:any = true;
  showViewBalanceTooltip: boolean = false;
  addAccountTooltip: boolean = false;
  public utilityService: any;
  emptyArray = [];
  depositSearchPlaceholder: string = '';
  scrollEle: any;
  bcategoryapi: any = true;
  displayEdit = false;
  resizeWindow = false;

  tabletPortrait = false;
  tabletLandscape = false;
  leftArrowDisable = true;
  rightArrowDisable = false;
  indexNumber: number = 0;
  index: number = 0;
  lastSelectedC1: number = 0;
  lastSelected2: number = 0;
  savedasboardSubscription: Subscription;
  rowIndex = 0;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.getTableBodyHeight('ele', this.rowSpan, true);
    setTimeout(() => {
      this.splitSummaryList(this.depositSummaryList);
    }, 100);

    this.cd.detectChanges();
  }

  public config: PerfectScrollbarConfigInterface = {
    suppressScrollX: true,
    wheelPropagation: false,
    minScrollbarLength: 25
  };

  constructor(public cd: ChangeDetectorRef, public depositAcctService: DepositAcctBalancesService) {
    this.translations = {};
  }
  updateEntilement() {

    setInterval(() => {

      if (this.utilityService.refreshEntitleflag && this.bcategoryapi) {
        this.bcategoryapi = false;
        this.getDepositentitle();
      }
    }, 300);
  }
  mainSub: Subscription;
  saveSub: Subscription
  ngOnDestroy() {
    if (this.mainSub) {
      this.mainSub.unsubscribe();
    }
    if (this.saveSub) {
      this.saveSub.unsubscribe();
    }
    if (this.savedasboardSubscription) {
      this.savedasboardSubscription.unsubscribe();
    }
  }
  ngOnInit() {
    this.appLang = this.utilityService.appLang;
    this.tabletPortrait = this.utilityService.tabletPortrait;
    this.tabletLandscape = this.utilityService.tabletLandscape;
    this.showLoader = true;
    console.log(this.tabletPortrait, this.tabletLandscape);
    this.cd.detectChanges();
    this.selectedColName = "current";
    this.depositAcctService.http = this.http;
    this.largeWidgetFlag = false;
    this.smallWidgetFlag = false;

    if (this.tabletPortrait === true || this.tabletLandscape === true) {
      this.resizeWindow = true;
    } else {
      this.resizeWindow = false;
    }
    let colSpan = this.widget.calculatedColSpan;
    let rowSpan = this.widget.calculatedRowSpan;
    this.colSpan = colSpan.toString();
    this.rowSpan = rowSpan.toString();
    this.isMobile = this.widget.isMobile;
    if (this.colSpan === '60') {
      this.largeWidgetFlag = true;
    } else {
      this.smallWidgetFlag = true;
    }

    if (this.widget.wgtcollist !== null && this.widget.wgtcollist !== undefined && this.widget.wgtcollist.length > 0) {
      this.selectedColName = this.widget.wgtcollist[0].wgtColname;
    }
    this.eventService.publishTopic({
      "topic": "hideLoader",
      "data": {
        'widget': this.widget
      }
    });
    this.getBalanceColumn();
    this.widgetObj = this.widget;
    this.widget = this.data;
    //this.getDepositAccounts();
    //this.getDepositentitle();
    this.updateEntilement();
    this.eventService.topic()
      .subscribe(eventData => {

        if (eventData.topic === 'lang-change') {
          this.appLang = eventData.data;
          if (!this.utilityService.accountEntitlementDeposit) {
            this.getBalanceColumn();
            this.depositAccountList = [];
            this.showLoader = true;
            this.error = false;
            if (this.tabletLandscape || this.tabletPortrait) {
              this.leftArrowDisable = true;
              this.rightArrowDisable = false;
            }
            this.getDepositAccounts();
            this.cd.detectChanges();
          }

        }
        if (eventData.topic === 'resize-device-view') {
          this.resizeWindow = eventData.data.resizeView;
          this.tabletPortrait = eventData.data.tabletPortrait;
          this.tabletLandscape = eventData.data.tabletLandscape;
          this.ajustingTable();
        }
        if (eventData.topic === 'depositTable-enableDisable-lastSelected') {
          this.leftArrowDisable = eventData.data.leftArrowDisable;
          this.rightArrowDisable = eventData.data.rightArrowDisable;
          this.lastSelectedC1 = eventData.data.lastSelectedC1;
          this.lastSelected2 = eventData.data.lastSelected2;
          this.cd.detectChanges();
        }
        //   if (eventData.topic === 'resize-device-view') {
        //     this.resizeWindow = eventData.data.resizeView;
        //  }
        if (eventData.topic === 'searchValue') {
          if (eventData.data.from === "deposit") {
            this.searchValue = eventData.data.value;
            this.searchText();

          }
          this.cd.detectChanges();
        }

        // if (eventData.topic === "confirm-widgets-yes") {

        //   this.terminateExecuton = true;
        //   this.publishAccountDetailsComponent();
        //   this.terminateExecuton = false;
        //   this.cd.detectChanges();


        // }
      });
    this.saveSub = this.eventService.topic()
      .subscribe(eventData => {
        if (eventData.topic === "saved-account-settings") {
          if (eventData.data && eventData['from'] !== null && eventData['from'] === 'Deposit-Widget') {
            this.utilityService.accountEntitlement['EntAccCountDeposit'] = '1';
            this.selectedColName = eventData['balancType'];
            this.getBalanceColumn();
            this.depositAccountList = [];
            this.showLoader = true;
            this.error = false;
            //this.getDepositAccounts();
            //this.getDepositentitle();
            //this.loadSearchComponent();
            this.getDepositAccounts();

            this.cd.detectChanges();
          }
        }
      });
    this.mainSub = this.eventService.topic()
      .subscribe(eventData => {

        if (eventData.topic === 'clearSearchValue') {
          if (eventData.data.from === "deposit") {
            this.noResultsFlag = false;
            this.searchFlag = false;
            this.depositAccountList = this.origDepositAccountList;
            if (this.depositAccountList.length == 0) {
              this.noResultsFlag = true;
            }
            setTimeout(() => {
              this.ajustingTable();
            }, 400);

          }
          this.cd.detectChanges();
          if (eventData.data.from === "deposit") {
            if (this.tabletPortrait || this.tabletLandscape) {
              this.eventService.publishTopic({
                "topic": "search-clicked",
                "data": {
                  'tableID': 'depositTable',
                  'widgetColClass': 'deposit-widget-c'
                }
              });
            }
          }

        }
        if (eventData.topic === 'show-account-settings' && eventData['data'] !== null) {
          if (eventData['data']["widgetname"] === 'W_DEPOSIT_ACBAL_V0') {
            this.publishdepositcomponent();
            this.cd.detectChanges();
          }
        }

      });
    this.savedasboardSubscription = this.eventService.topic()
      .subscribe(eventData => {
        if (eventData.topic == 'save-dasboard') {
          this.closetooltip(this.rowIndex, 'accountHitBox');
          this.closetooltip(-1, 'viewBalances');
        }
      });
    this.cd.detectChanges();
  }

  getTableBodyHeight(ele, size, onresize?) {
    this.scrollEle = onresize ? this.scrollEle : ele;
    let parentEle = $(this.scrollEle.directiveRef.elementRef.nativeElement).offsetParent() &&
      $(this.scrollEle.directiveRef.elementRef.nativeElement).offsetParent().offsetParent() &&
      $(this.scrollEle.directiveRef.elementRef.nativeElement).offsetParent().offsetParent()[0];
    if (parentEle && parentEle.id) {
      let height = $('#' + parentEle.id).height() - $('#' + parentEle.id + ' .heading-layout').outerHeight() -
        ($('#' + parentEle.id + ' .view-balance').height() > 58 ? $('#' + parentEle.id + ' .view-balance').height() : 58);
      if (this.noAcctSelectedFlag) {
        return $('#' + parentEle.id).height() - $('#' + parentEle.id + ' .heading-layout').outerHeight() - 15;
      }
      if (size === '30') {
        if (onresize) {
          $(this.scrollEle.directiveRef.elementRef.nativeElement).offsetParent().css('height', height - 10);
        } else {
          return height - 10;
        }
      } else {
        height = height - ($('#' + parentEle.id + ' .header-div').height() || 53) - 27;
        if (onresize) {
          $(this.scrollEle.directiveRef.elementRef.nativeElement).offsetParent().css('height', height);
        } else {
          return height;
        }
      }
    } else {
      return size === '30' ? 249 : 590;
    }
  }

  getDepositentitle() {
    this.showLoader = true;

    if (this.utilityService.accountEntitlement['EntAccCountDeposit'] === "0" && this.utilityService.accountEntitlementDeposit) {
      this.showLoader = false;
      this.entitleEnable = true;
      this.eventService.publishTopic({
        "topic": "enforce-widget-entitlement",
        "data": {
          id: "W_DEPOSIT_ACBAL_V0"
        }
      });
      // this.ajustingTable();
      this.cd.detectChanges();

    } else if (this.utilityService.accountEntitlement['EntAccCountDeposit'] === "0" && !this.utilityService.accountEntitlementDeposit) {
      this.noAcctSelectedFlag = true;
      this.eventService.publishTopic({
        "topic": "deposit-no-accounts",
        "data": ''
      });
      //this.getCustomize();
      this.showLoader = false;
      this.cd.detectChanges();
    } else {


      this.getBalanceColumn();
      this.depositAccountList = [];
      if (this.largeWidgetFlag) {
        this.loadSearchComponent();
      }
      this.getDepositAccounts();
      this.cd.detectChanges();
    }


  }

  /*    relocateEdit(event , i ){
     
       let clickedLocation:Number = event.pageY;
       let minHeight:Number = 70 ;
     
       if(!this.showViewBalanceTooltip)  {
       let viewBtnLocation:Number = $('#dpViewBal') && $('#dpViewBal').offset().top - 10 ;
       let relHeight:Number = Number(viewBtnLocation) - Number(clickedLocation) ;
       if (minHeight>relHeight){
         $('#tooltipEdit'+i).addClass('hitBox-popover-one-top');
         $('#tooltipEdit'+ i ).removeClass('hitBox-popover-one');
        
     
       } else {
         $('#tooltipEdit' + i ).addClass('hitBox-popover-one');
         $('#tooltipEdit' + i ).removeClass('hitBox-popover-one-top');
       }
     }
     } */
  relocatePopover(event, i) {
    let clickedLocation: Number = event.pageY;
    let minHeight: Number = 70;
    $('.select-account-popover').removeClass('tooltipTop');
    $('.select-account-popover-big').removeClass('tooltipTop');
    let addBtnLocation: Number = $('.action-footer') && $('.action-footer').offset().top - 10;
    let relHeight: Number = Number(addBtnLocation) - Number(clickedLocation);
    if (minHeight > relHeight) {
      if (i == 'addAccBtn1') {
        $('.select-account-popover-big').addClass('tooltipTop');
      } else
        $('.select-account-popover').addClass('tooltipTop');
    }
  }
  relocateEditMode(event, flag) {
    if ($(".action-footer") && flag == "true") {
      let scroll = document.getElementById("depositWidgetScroll");
      let viewBalLoan = document.getElementById("dpViewBal")
      let viewBalTop = viewBalLoan.getBoundingClientRect().top - 25;
      let footer = document.getElementsByClassName('action-footer')[0];
      let footerRect = footer.getBoundingClientRect();
      let scrollRect = scroll.getBoundingClientRect();
      let rightPoint = scrollRect.right - 10;
      let leftPoint = scrollRect.left + 10;
      let bottomPoint = viewBalTop;
      let pageContainer = document.getElementById('page-main-container');
      let pageRect = pageContainer.getBoundingClientRect();
      let pageLeft = pageRect.left + 10;
      let pageRight = pageRect.right - 10;
      let footerPoint = footerRect.top;
      let ClientPointerX = event.clientX;
      let ClientPointerY = event.clientY;
      let tooltipHeight = 60;
      let tooltipWidth = 262;
      let rightCheck = ClientPointerX + tooltipWidth;
      let leftCheck = ClientPointerX - (tooltipWidth);
      let bottomCheck = event.clientY + tooltipHeight + 10;
      console.log("rightCheck : " + rightCheck + " < rightPoint : " + rightPoint + "leftCheck : " + leftCheck + " > leftPoint : " + leftPoint + " ClientPointerX: " + ClientPointerX);

      if (this.smallWidgetFlag) {
        if (rightCheck <= rightPoint) {
          $('#editModeTooltip1').css({ "display": "block !important", "position": "fixed", "left": ClientPointerX + "px", "z-index": 2 });
          $('#editI').css({ "left": "10px" });
          console.log("rightCheck <= rightPoint");

        } else {

          if (leftCheck - pageLeft < 0) {
            $('#editModeTooltip1').css({ "display": "block !important", "position": "fixed", "left": ClientPointerX + "px", "z-index": 2 });
            $('#editI').css({ "left": "10px" });
          }
          else {
            // do nothing
            $('#editModeTooltip1').css({ "display": "block !important", "position": "fixed", "left": (ClientPointerX - (tooltipWidth)) + "px", "z-index": 2 });
            $('#editI').css({ "left": (tooltipWidth - 20) + "px" });
          }
        }
        if (bottomCheck > bottomPoint || bottomCheck > footerPoint) {
          $('#editModeTooltip1').css({ "top": (ClientPointerY - tooltipHeight) + "px" });
          $('#editI').css({ "top": "55px", "transform": "rotate(45deg)" });
        } else {
          $('#editModeTooltip1').css({ "top": (ClientPointerY + 20) + "px" });
          $('#editI').css({ "top": "-1px", "transform": "rotate(225deg)" });
        }
      } else if (this.largeWidgetFlag) {
        if (rightCheck <= rightPoint) {
          $('#editModeTooltip2').css({ "display": "block !important", "position": "fixed", "left": ClientPointerX + "px", "z-index": 2 });
          $('#editI').css({ "left": "10px" });
        } else {
          $('#editModeTooltip2').css({ "display": "block !important", "position": "fixed", "left": (ClientPointerX - tooltipWidth) + "px", "z-index": 2 });
          $('#editI').css({ "left": "242px" });
        }
        if (bottomCheck > bottomPoint || bottomCheck > footerPoint) {
          $('#editModeTooltip2').css({ "top": (ClientPointerY - tooltipHeight) + "px" });
          $('#editI').css({ "top": "55px", "transform": "rotate(45deg)" });
        } else {
          $('#editModeTooltip2').css({ "top": (ClientPointerY + 20) + "px" });
          $('#editI').css({ "top": "-1px", "transform": "rotate(225deg)" });
        }

      }
    }

  }
  relocateEditFlag(flag, $event) {


    if (flag == 'true' && this.utilityService.isFormChanged) {
      this.displayEdit = true;
    } else {
      this.displayEdit = false;
    }
    this.cd.detectChanges();

  }


  getDepositAccounts() {
    this.depositAcctService.getDepositAccounts().subscribe(
      response => {
        if (response["error"] !== null) {
          this.error = true;
          this.showLoader = false;
        }
        if (response !== null && response["data"]) {
          // console.log(response["data"][0]);
          this.activeDepositaccountDetails = [];
          this.depositAccountList = [];
          this.depositSummaryList = [];
          this.origDepositAccountList = [];
          this.depositAccountList = response["data"][0].depositAccountList;
          // this.origDepositAccountList = response["data"][0].depositAccountList;
          this.origDepositAccountList = JSON.parse(JSON.stringify(response["data"][0].depositAccountList));
          this.depositSummaryList = response["data"][0].depositSummaryList;
          this.maskDepositFlag = response["data"][0].maskDeposit;
          this.noAcctSelectedFlag = false;
          // this.getFormattedAmount(this.depositAccountList);
          //   if(this.depositAccountList.length > 0) {
          //      this.sortColumns('accountNumber');
          // }
          this.activeDepositaccountDetails = this.depositAccountList.filter(obj => obj.enableLink === true);

          if (this.depositSummaryList.length > 0 || this.depositAccountList.length > 0) {
            this.depositSummaryList = this.depositAcctService.customSortAll('total_type', true, this.depositSummaryList);
            this.splitSummaryList(this.depositSummaryList);
          } else {
            this.noAcctSelectedFlag = true;
            this.eventService.publishTopic({
              "topic": "deposit-no-accounts",
              "data": ''
            });
          }

          if (this.maskDepositFlag) {
            this.depositSearchPlaceholder = this.translations.searchByAccName;
          } else {
            this.depositSearchPlaceholder = this.translations.searchByAccNameorNum;
          }

          if (this.largeWidgetFlag && !this.noAcctSelectedFlag) {
            this.eventService.publishTopic({
              "topic": "placeholder-value-deposit",
              "data": this.depositSearchPlaceholder
            });
          }
          // if(this.firstTimeLoad) {
          // this.loadSearchComponent();
          //   this.firstTimeLoad = false;
          // }

          this.error = false;
          this.showLoader = false;
          // console.log("this.depositAccountList", this.depositAccountList);
          // console.log('json fetched');
        } else {
          this.error = true;
          this.showLoader = false;
        }
        this.cd.detectChanges();
        this.ajustingTable();
      }, error => {
        this.error = true;
        this.showLoader = false;
        this.cd.detectChanges();
        console.log('error from deposit acct balance service', error);
      });
  }


  splitSummaryList(depositSummaryList) {
    this.leftSummaryTotals = [];
    this.rightSummaryTotals = [];
    this.summaryTotals = [];

    depositSummaryList.forEach(d => {
      if (d.total_type === 'CAD' || d.total_type === 'USD') {
        this.leftSummaryTotals.push(d);
      } else {
        this.rightSummaryTotals.push(d);
      }
    });

    this.summaryTotals.push(this.leftSummaryTotals);
    this.emptyArray = [];
    let objItem = {
      AVAILABLE: "",
      AVAILABLE_CREDIT: "",
      CURRENT: "",
      LASTSTMT: "",
      PREVIOUS: "",
      PREVIOUS_DAY_AVAILABLE: "",
      total_type: ""
    };

    if (this.leftSummaryTotals.length > 0 && (!this.tabletLandscape && !this.tabletPortrait)) {
      this.emptyArray.push(objItem);
      this.summaryTotals.push(this.emptyArray);
    }
    this.summaryTotals.push(this.rightSummaryTotals);

    this.summaryTotals = [].concat.apply([], this.summaryTotals);

    if (this.rightSummaryTotals.length > 0 && this.smallWidgetFlag) {
      let notEmptyCurrent = false;
      if (this.currentColumnFlag) {
        for (var i in this.rightSummaryTotals) {
          if (this.rightSummaryTotals[i].CURRENT !== '') {
            notEmptyCurrent = true;
            break;
          }
        }
        if (!notEmptyCurrent) {
          this.rightSummaryTotals = [];
        }
      }

      let notEmptyPrevious = false;
      if (this.previousColumnFlag) {
        for (var i in this.rightSummaryTotals) {
          if (this.rightSummaryTotals[i].PREVIOUS !== '') {
            notEmptyPrevious = true;
            break;
          }
        }
        if (!notEmptyPrevious) {
          this.rightSummaryTotals = [];
        }
      }
    }


    if (this.rightSummaryTotals.length === 0 && this.smallWidgetFlag) {
      this.rightSummaryTotals = this.leftSummaryTotals;
      this.leftSummaryTotals = [];
    }

    if (this.summaryTotals.length > 0 || this.summaryTotals !== undefined) {
      for (let i = 0; i < this.summaryTotals.length; i++) {
        if (i == 0) {
          this.summaryTotals[i].totalsLabel = this.translations.totals;
        } else {
          this.summaryTotals[i].totalsLabel = '';
        }
      }
    }
  }
  getFormattedAmount(depositAccountList) {
    for (var i = 0; i < depositAccountList.length; i++) {
      if (depositAccountList[i].currentBalance) {
        depositAccountList[i].currentBalance.balance =
          this.amountFormatter(depositAccountList[i].currentBalance.balance);
      }
      if (depositAccountList[i].availableBalance) {
        depositAccountList[i].availableBalance.balance =
          this.amountFormatter(depositAccountList[i].availableBalance.balance);
      }
      if (depositAccountList[i].previousBalance) {
        depositAccountList[i].previousBalance.balance =
          this.amountFormatter(depositAccountList[i].previousBalance.balance);
      }
      if (depositAccountList[i].previousAvailableBalance) {
        depositAccountList[i].previousAvailableBalance.balance =
          this.amountFormatter(depositAccountList[i].previousAvailableBalance.balance);
      }
    }
  }
  amountFormatter(balance) {
    if (this.appLang.toLowerCase() == "fr") {
      return (balance.replace(/\,/g, " ").replace(/\./g, ",")) + '$';
    } else {
      return '$' + balance;
    }
  }
  relocate(event) {
    //$('.context-menu-trigger')[0] && $('.context-menu-trigger')[0].click();
    let clickedLocation: Number = event.pageY;
    let viewBtnLocation: Number = $('#dpViewBal') && $('#dpViewBal').offset().top - 10;
    //console.log ("clicklok : "+clickedLocation + " viewBtnLocation: "+viewBtnLocation );
    let relHeight: Number = Number(viewBtnLocation) - Number(clickedLocation);
    //console.log ("relHeight : " +relHeight);
    let minHeight: Number = 65;
    let loc = event.target.id.split('_')[1];
    //console.log ("loc: "+loc );
    if (minHeight > relHeight) {
      $('#tooltip' + loc).addClass('no-count-popover-lastcolumn-top');
      $('#tooltip' + loc).removeClass('no-count-popover-lastcolumn');


    } else {
      $('#tooltip' + loc).addClass('no-count-popover-lastcolumn');
      $('#tooltip' + loc).removeClass('no-count-popover-lastcolumn-top');
    }
  }
  relocatePopup(event) {
    //$('.context-menu-trigger')[0] && $('.context-menu-trigger')[0].click();
    let clickedLocation: Number = event.pageY;
    let viewBtnLocation: Number = $('#dpViewBal') && $('#dpViewBal').offset().top - 10;
    //console.log ("clicklok : "+clickedLocation + " viewBtnLocation: "+viewBtnLocation );
    let relHeight: Number = Number(viewBtnLocation) - Number(clickedLocation);
    //console.log ("relHeight : " +relHeight);
    let minHeight: Number = 65;
    let loc = event.target.id.split('_')[1];
    //console.log ("loc: "+loc );
    if (minHeight > relHeight) {
      $('#tooltip' + loc).addClass('no-count-popover-top');
      $('#tooltip' + loc).removeClass('no-count-popover');


    } else {
      $('#tooltip' + loc).addClass('no-count-popover');
      $('#tooltip' + loc).removeClass('no-count-popover-top');
    }
  }

  sortColumns(fieldName) {
    if (fieldName === 'accountNumber' && this.maskDepositFlag) {
      fieldName = 'maskAccountNumber';
      // this.sortType = fieldName;
      this.defaultSort = false;
    } else {
      // this.sortType = fieldName;
      this.defaultSort = false;
    }
    if (this.sortType === fieldName) {
      this.sortIndex++;
      if (this.sortIndex == 1) {
        this.ascending = true;
      } else if (this.sortIndex == 2) {
        this.ascending = false;
      }
      else if (this.sortIndex == 3) {
        this.ascending = false;
        this.defaultSort = true;
        let depositOriginalArray = [];
        depositOriginalArray = JSON.parse(JSON.stringify(this.origDepositAccountList));
        this.depositAccountList = depositOriginalArray;
        this.cd.detectChanges();
        if (this.tabletPortrait || this.tabletLandscape) {
          this.eventService.publishTopic({
            "topic": "tablet-sort-clicked",
            "data": {
              'tableID': 'depositTable',
              'widgetColClass': 'deposit-widget-c'
            }
          });
        }
        return;
      }
      else {
        this.ascending = true;
        this.sortType = fieldName;
        this.sortIndex = 1;
      }
    }
    else {
      this.sortIndex = 1;
      this.sortType = fieldName;
      this.ascending = true;
    }
    this.getNegativeNumbers(this.depositAccountList);
    this.depositAccountList = this.depositAcctService.customSortAll(fieldName, this.ascending, this.depositAccountList, false);
    this.cd.detectChanges();
    if (this.tabletPortrait || this.tabletLandscape) {
      this.eventService.publishTopic({
        "topic": "tablet-sort-clicked",
        "data": {
          'tableID': 'depositTable',
          'widgetColClass': 'deposit-widget-c'
        }
      });
    }
  }

  getTop() {
    if ($('.oneditMode').length > 0) {
      return $('.action-footer').offset().top;
    } else if ((window.document.documentElement.offsetHeight - window.document.querySelector('footer').getClientRects()[0].top) >= 1) {
      return $('.bmo-footer').offset().top;
    } else {
      return window.document.documentElement.offsetHeight;
    }
  }

  opentooltip(i, balance) {
    this.rowIndex = i;
    var self = this;
    if (this.isMobile) {
      setTimeout(() => {
        $('#dp-tbl-row' + i).css('background', 'none');
        $('#dp-tbl-row' + i).removeClass('activeClassLink');
        self.closetooltip(i, balance);
        self.cd.detectChanges();
      }, 2000);
    }
    //let btnTop = $('#dpViewBal') && $('#dpViewBal').offset().top;    
    let btnTop: any;
    let btnOffset = $('#dpViewBal') && $('#dpViewBal').offset();
    if (btnOffset != null && btnOffset != undefined) {
      btnTop = btnOffset.top;
    }
    if (balance != 'viewBalances' && balance != 'add-account-tooltip')
      $('#dp-tbl-row' + i).css('background', '#edf6fb');
    $('#dp-tbl-row' + i).addClass('activeClassLink');
    if (balance !== 'add-account-tooltip' && this.depositAccountList[i]) {
      this.depositAccountList[i].showPreviousTooltip = false;
      this.depositAccountList[i].showTooltip = false;
    }

    this.showViewBalanceTooltip = false;

    if (this.utilityService.isFormChanged) {

      if (balance === 'viewBalances') {
        this.showViewBalanceTooltip = true;
        this.cd.detectChanges();
        if (btnTop != null && btnTop != undefined) {
          if (this.getTop() - btnTop < 100) {
            $('#dpViewBaltooltip').addClass('content-up');
          } else {
            $('#dpViewBaltooltip').removeClass('content-up');
          }
        }
      }
      else if (balance === 'add-account-tooltip') {
        this.addAccountTooltip = true;
      }
      else if (this.depositAccountList[i]) {
        this.depositAccountList[i].accountHitBoxTooltip = true;
      }
      this.cd.detectChanges();
      return;
    }

    if (balance === 'current' && this.depositAccountList[i]) {
      this.depositAccountList[i].showTooltip = true;
    } else if (balance === 'previous' && this.depositAccountList[i]) {
      this.depositAccountList[i].showPreviousTooltip = true;
    }
    this.cd.detectChanges();
  }
  closetooltip(i, balance) {
    if (balance != 'viewBalances' && balance != 'add-account-tooltip')
      $('#dp-tbl-row' + i).css('background', 'none');
    $('#dp-tbl-row' + i).removeClass('activeClassLink');
    if (this.utilityService.isFormChanged) {
      if (balance === 'viewBalances') {
        this.showViewBalanceTooltip = false;
      }
      else if (balance === 'add-account-tooltip') {
        this.addAccountTooltip = false;
      }
      else if (this.depositAccountList[i]) {
        this.depositAccountList[i].accountHitBoxTooltip = false;
        this.displayEdit = false;
      }
      this.cd.detectChanges();
      return;
    }

    if (balance === 'current' && this.depositAccountList[i]) {
      this.depositAccountList[i].showTooltip = false;
    } else if (balance === 'previous' && this.depositAccountList[i]) {
      this.depositAccountList[i].showPreviousTooltip = false;
    }
    this.cd.detectChanges();
  }

  searchText() {
    this.depositAccountList = [];
    this.noResultsFlag = false;
    this.searchFlag = false;
    if (this.searchValue != undefined && this.searchValue.length > 0) {
      let fieldName = '';
      if (this.maskDepositFlag) {
        fieldName = 'accountName';
      } else {
        fieldName = 'accountNumber';
      }
      if (this.origDepositAccountList && this.origDepositAccountList.length > 0) {
        for (let i = 0; i < this.origDepositAccountList.length; i++) {

          // const language = (this.utilityService.appLang && this.utilityService.appLang.toUpperCase()) === 'FR' ? 'Fr' : 'En';
          if ((this.origDepositAccountList[i][fieldName].toUpperCase().includes(this.searchValue.toUpperCase()) ||
            this.origDepositAccountList[i]['accountName'].toUpperCase().includes(this.searchValue.toUpperCase()))) {
            this.depositAccountList.push(this.origDepositAccountList[i]);
            this.searchFlag = true;
          }
        }
        if (this.depositAccountList.length == 0) {
          this.noResultsFlag = true;
        }
      }
      this.cd.detectChanges();
      this.ajustingTable();
    }
    else {
      this.depositAccountList = this.origDepositAccountList;
      this.cd.detectChanges();
      this.ajustingTable();
    }
  }
  publishdepositcomponent() {
    this.eventService.publishTopic({
      "topic": "show-popover",
      "data": {
        data: {
          from: "Deposit-Widget", colspan: this.colSpan, balance: this.selectedColName,
          deposit_setting_title: this.translations.deposit_setting_title,
          deposit_setting_account_order: this.translations.deposit_setting_account_order,
          appLang: this.appLang
        },
        addon: "/ui/HPWidgetsWeb/common-module/bundles/common-module.umd.min.js",
        module: "CommonModuleModule",
        componentClassName: "CommonAccSettingComponent",
        selector: "common-acct-balances",
        divid: "dynamicModal",
        //modalCss:"depositoverlay",
        translationUrl: "/olbb-library-app/assets/i18n/common-module"
      }
    });
  }
  loadSearchComponent() {
    let objwidget = this.widget;
    let widgetdivid = $("#" + this.widgetid).attr('tileid');
    widgetdivid = widgetdivid + "searchWidget";
    this.eventService.publishTopic({
      "topic": "load-search-component",
      "data": {
        data: objwidget,
        addon: "/ui/HPWidgetsWeb/common-module/bundles/common-module.umd.min.js",
        module: "CommonModuleModule",
        componentClassName: "searchComponent",
        selector: "search-component",
        divid: widgetdivid,
        widgetObj: this.widgetObj,
        maskDepositFlag: this.maskDepositFlag,
        searchFrom: "deposit"
        // modalCss:"depositoverlay"
      }
    });

  };
  openDepositAccount(){
    window.open("https://olbbdemo.dev.bmo.com/ui/SimpleJourneyWeb/#/open-deposit-accounts","_self");
  };
  openViewBalancesOverlay() {
    if (this.utilityService.isFormChanged) {
      return;
    }
    this.publishViewBalanceComponent();
    this.cd.detectChanges();
  }
  // ischeckdashboardDirty(accountdetails) {
  //   this.terminateExecuton = false;
  //   this.depositAcctService.stopevent = true;
  //   this.eventService.publishTopic({
  //     "topic": "show-confirm-widget-dialog",
  //     "data": {
  //       "id": "dtywidgetDialog",
  //       "action": "navigateaway",
  //       "from": "dirty-dashboard-widget-dialog",
  //       "accountdetails": accountdetails
  //     }
  //   });
  // }

  openAccountDetailsOverlay(accountNumber, Deposit, accountSource, accountType, benableLink) {
    if (this.utilityService.isFormChanged) {
      return;
    }
    this.depositAcctService.stopevent = true;
    if (this.depositAcctService.stopevent && benableLink) {
      this.depositAcctService.stopevent = false;
      this.acctDetailsList = [];
      this.acctDetailsList.push({
        accountNumber: accountNumber,
        categoryType: Deposit,
        accountSource: accountSource,
        accountType: accountType
      });
      // if (!this.terminateExecuton) {

      //   this.ischeckdashboardDirty(this.acctDetailsList);

      //   return;
      // }
      this.publishAccountDetailsComponent();

    }

  }

  openSettingsOverlay() {
    if (this.utilityService.isFormChanged) {
      return;
    }
    this.publishdepositcomponent();
  }
  publishViewBalanceComponent() {
    let widgetdivid = this.getIndexID();

    this.eventService.publishTopic({
      "topic": "view-balances-popover",
      "data": {
        from: "deposit-widget",
        addon: "/ui/HPWidgetsWeb/common-module/bundles/common-module.umd.min.js",
        module: "CommonModuleModule",
        componentClassName: "viewBalanceComponent",
        selector: "common-view-balances",
        divid: "dynamicModal",
        //modalCss:"viewBalanceOverlay",
        tableData: this.origDepositAccountList,
        leftSummaryList: this.leftSummaryTotals,
        rightSummaryList: this.rightSummaryTotals,
        summaryTotalList: this.summaryTotals,
        maskFlag: this.maskDepositFlag,
        activeAccountDetails: this.activeDepositaccountDetails,
        translationUrl: "/olbb-library-app/assets/i18n/common-module",
        appLang: this.appLang,
        widgetId: widgetdivid
      }
    });
  }
  publishAccountDetailsComponent() {
    let widgetdivid = this.getIndexID();

    this.eventService.publishTopic({
      "topic": "view-detail-acctbalance",
      "data": {
        addon: "/ui/HPWidgetsWeb/deposit-acct-balances/bundles/deposit-acct-balances.umd.min.js",
        module: "DepositAcctBalancesModule",
        componentClassName: "accountDetailComponent",
        selector: "account-details",
        divid: "dynamicModal",
        //modalCss:"viewBalanceOverlay",
        acctDetailsList: this.acctDetailsList,
        maskFlag: this.maskDepositFlag,
        activeAccountDetails: this.activeDepositaccountDetails,
        tableData: this.origDepositAccountList,
        leftSummaryList: this.leftSummaryTotals,
        rightSummaryList: this.rightSummaryTotals,
        summaryTotalList: this.summaryTotals,
        appLang: this.appLang,
        widgetId: widgetdivid
      }
    });
  }

  getBalanceColumn() {
    this.currentColumnFlag = false;
    this.previousColumnFlag = false;
    if (this.selectedColName === 'current') {
      this.currentColumnFlag = true;
    } else {
      this.previousColumnFlag = true;
    }
  }
  getNegativeNumbers(accountList) {
    for (var i = 0; i < accountList.length; i++) {
      if (accountList[i].currentBalance) {
        if (accountList[i].currentBalance.balance.indexOf('(') != -1) {
          accountList[i].currentBalance.sortBalance = this.replaceMinusSign(accountList[i].currentBalance.balance);
        } else {
          accountList[i].currentBalance.sortBalance = accountList[i].currentBalance.balance;
        }
      }
      if (accountList[i].previousBalance) {
        if (accountList[i].previousBalance.balance.indexOf('(') != -1) {
          accountList[i].previousBalance.sortBalance = this.replaceMinusSign(accountList[i].previousBalance.balance);
        } else {
          accountList[i].previousBalance.sortBalance = accountList[i].previousBalance.balance;
        }
      }
    }
  }
  replaceMinusSign(nagativeNumber) {
    nagativeNumber = nagativeNumber.replace(/\(|\)/g, '');
    nagativeNumber = "-" + nagativeNumber;
    return nagativeNumber;
  }
  ajustingTable() {
    this.eventService.publishTopic({
      "topic": "adjustTabletTable",
      "data": {
        'tableID': 'depositTable',
        'widgetColClass': 'deposit-widget-c'
      }
    });
  }
  shiftRightColumns() {
    this.eventService.publishTopic({
      "topic": "clicked-right",
      "data": {
        'tableID': 'depositTable',
        'widgetColClass': 'deposit-widget-c'
      }
    });
  }

  shiftLeftColumns() {
    this.eventService.publishTopic({
      "topic": "clicked-left",
      "data": {
        'tableID': 'depositTable',
        'widgetColClass': 'deposit-widget-c'
      }
    });
  }

  getIndexID() {
    var iWidgetIndex = $("#" + this.widgetid).attr('tileid');
    var widgetTextArray = this.widgetid.split('_V');
    console.log("99999999999999991111 getIndex", this.widgetid);
    var widgetIndexArray = Number(widgetTextArray[1]);

    for (let i = 0; i < 50; i++) {
      var tmpWidgetID = widgetIndexArray < 10 ? widgetTextArray[0] + "_V0" + i : widgetTextArray[0] + "_V" + i;
      console.log("99999999999999991111 tmpWidgetID", tmpWidgetID);
      var objWidgetIndex = $("#" + tmpWidgetID).attr('tileid');
      if (objWidgetIndex > 0) {
        console.log("99999999999999991111 matchfound", objWidgetIndex);
        return objWidgetIndex;
      } else {
        var _WidgetID = widgetTextArray[0] + "_V0" + i;

        console.log("99999999999999991111 else _WidgetID", _WidgetID);
        var _WidgetIndex = $("#" + _WidgetID).attr('tileid');
        if (_WidgetIndex > 0) {

          console.log("99999999999999991111 else matchfound", _WidgetIndex);
          return _WidgetIndex;
        }

      }

    }

  }
}

// server.js
const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });

// Generate stub data
const accounts = Array.from({ length: 560 }, (_, i) => ({
    name: `Account ${i + 1}`,
    number: `000${i + 1}`,
    balance: (Math.random() * 10000).toFixed(2)
}));

wss.on('connection', ws => {
    console.log('Client connected');
    ws.on('message', message => {
        console.log(`Received: ${message}`);
    });

    // Send accounts data in chunks
    let index = 0;
    const chunkSize = 5;
    const sendChunk = () => {
        if (index < accounts.length) {
            ws.send(JSON.stringify(accounts.slice(index, index + chunkSize)));
            index += chunkSize;
            setTimeout(sendChunk, 100); // Simulate delay
        }
    };
    sendChunk();
});

console.log('WebSocket server is running on ws://localhost:8080');
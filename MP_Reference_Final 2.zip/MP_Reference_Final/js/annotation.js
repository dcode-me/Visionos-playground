/**
 * annotation.js
 * Dynamically adds real-time dimension overlays for MFE elements:
 * - Card dimensions
 * - Content-area widths
 * - Section-shell paddings & widths
 * - CSS grid gaps and column widths
 * - MFE container width
 * - Product page shells, content, and grid annotations
 */

// Initialize annotations when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  // Enable annotations by default
  window.annotationEnabled = true;
  // Ensure shell elements are positioned for overlay anchoring
  ['DA_header_shell', 'DA_content_shell', 'XERO_header_shell', 'XERO_content_shell'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.position = el.style.position || 'relative';
  });
  // Main annotation update routine
  function updateAnnotations() {
    if (!window.annotationEnabled) return;
    // Annotate each card: width & height
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
      if (!card) return;
      card.style.position = 'relative';
      let overlay = card.querySelector('.annotation-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay';
        card.appendChild(overlay);
      }
      const width = `${card.clientWidth}px`;
      const height = `${card.clientHeight}px`;
      overlay.innerText = `W: ${width}\nH: ${height}`;
      Object.assign(overlay.style, {
        position: 'absolute',
        top: '2px',
        left: '2px',
        background: 'rgba(0, 0, 0, 0.7)',
        color: '#fff',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        whiteSpace: 'pre-line',
        pointerEvents: 'none',
        zIndex: '10000'
      });
    });
    // Annotate marketplace content-area widths
    ['MP_HP_header_content', 'MP_HP_tabs_content'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      let overlay = el.querySelector('.annotation-overlay-content');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay-content';
        el.appendChild(overlay);
      }
      const width = `Content Area Width: ${el.clientWidth}px`;
      overlay.innerText = `${width}`;
      Object.assign(overlay.style, {
        position: 'absolute',
        top: '2px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(11, 130, 36, 0.7)',
        color: '#fff',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        whiteSpace: 'pre-line',
        pointerEvents: 'none',
        zIndex: '10000'
      });
    });
    // Annotate marketplace section-shell paddings & widths
    ['MP_HP_header_shell', 'MP_HP_tabs_shell'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      let overlay = el.querySelector('.annotation-overlay-shell');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay-shell';
        el.appendChild(overlay);
      }
      const cs = getComputedStyle(el);
      const vert = `PV: ${cs.paddingTop} / ${cs.paddingBottom}`;
      const hor  = `PH: ${cs.paddingLeft} / ${cs.paddingRight}`;
      const widthStr = `Section Shell Width: ${el.clientWidth}px`;
      overlay.innerText = `${vert}\n${hor}\n${widthStr}`;
      Object.assign(overlay.style, {
        position: 'absolute',
        top: '2px',
        right: '2px',
        background: 'rgba(208, 119, 4, 0.7)',
        color: '#fff',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        whiteSpace: 'pre-line',
        pointerEvents: 'none',
        zIndex: '10000'
      });
    });
    // Annotate CSS grid gap for tabs content
    const gridEl = document.getElementById('MP_HP_tabs_content');
    if (gridEl) {
      let overlay = gridEl.querySelector('.annotation-overlay-gap');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay-gap';
        gridEl.appendChild(overlay);
      }
      const csGrid = getComputedStyle(gridEl);
      const gapValue = csGrid.gap || `${csGrid.rowGap} / ${csGrid.columnGap}`;
      overlay.innerText = `CSS Grid Gap: ${gapValue}`;
      Object.assign(overlay.style, {
        position: 'absolute',
        bottom: '2px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(255, 255, 0, 0.7)',
        color: '#000',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        whiteSpace: 'pre-line',
        pointerEvents: 'none',
        zIndex: '10000'
      });
    }
    // Annotate overall MFE container width
    const navEl = document.getElementById('top_nav_shell');
    const mfeWidth = document.querySelector('.mfe-container')?.clientWidth;
    if (navEl && mfeWidth != null) {
      let overlay = navEl.querySelector('.annotation-overlay-mfe');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay-mfe';
        navEl.appendChild(overlay);
      }
      overlay.innerText = `MFE Container Width: ${mfeWidth}px`;
      Object.assign(overlay.style, {
        position: 'absolute',
        bottom: '2px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(151, 75, 183, 0.7)',
        color: '#fff',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        whiteSpace: 'pre-line',
        pointerEvents: 'none',
        zIndex: '10000'
      });
    }

    // Annotate DepositAccounts/Xero section-shells
    ['DA_header_shell', 'DA_content_shell', 'XERO_header_shell', 'XERO_content_shell'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      let overlay = el.querySelector('.annotation-overlay-da-shell');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay-da-shell';
        el.appendChild(overlay);
      }
      const cs = getComputedStyle(el);
      const pl = `PL: ${cs.paddingLeft}`;
      const pr = `PR: ${cs.paddingRight}`;
      const width = `Section Shell Width: ${el.clientWidth}px`;
      overlay.innerText = `${pl} / ${pr}\n${width}`;
      Object.assign(overlay.style, {
        position: 'absolute',
        top: '2px',
        right: '2px',
        background: 'rgba(208, 119, 4, 0.7)',
        color: '#fff',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        pointerEvents: 'none',
        zIndex: '10000',
        whiteSpace: 'pre-line'
      });
    });

    // Annotate DepositAccounts/Xero content-area widths
    ['DA_header_content', 'DA_content', 'XERO_header_content', 'XERO_content'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      let overlay = el.querySelector('.annotation-overlay-da-content');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'annotation-overlay-da-content';
        el.appendChild(overlay);
      }
      overlay.innerText = `Content W: ${el.clientWidth}px`;
      Object.assign(overlay.style, {
        position: 'absolute',
        top: '2px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(11, 130, 36, 0.7)',
        color: '#fff',
        fontSize: '12px',
        padding: '4px',
        borderRadius: '4px',
        pointerEvents: 'none',
        zIndex: '10000',
        whiteSpace: 'pre-line'
      });
    });

    // Annotate DepositAccounts/Xero grid layout columns & widths
    ['DA_content', 'XERO_content'].forEach(gridId => {
      const gridEl = document.getElementById(gridId);
      if (gridEl) {
        let overlay = gridEl.querySelector('.annotation-overlay-da-grid');
        if (!overlay) {
          overlay = document.createElement('div');
          overlay.className = 'annotation-overlay-da-grid';
          gridEl.appendChild(overlay);
        }
        const csGrid = getComputedStyle(gridEl);
        const cols = csGrid.gridTemplateColumns;
        const gap = csGrid.columnGap || csGrid.gap || '';
        const columns = Array.from(gridEl.children)
          .filter(el => el.matches('.xero-logo-section, .product-overview, .product-cta, .card, .card-link-wrapper'));
        const childWidths = columns
          .map((col, i) => `Col ${i+1}: ${col.clientWidth}px`)
          .join('\n');
        overlay.innerText = `Grid cols: ${cols}\nGap: ${gap}\n${childWidths}`;
        Object.assign(overlay.style, {
          position: 'absolute',
          bottom: '2px',
          left: '50%',
          transform: 'translateX(-50%)',
          background: 'rgba(255, 255, 0, 0.7)',
          color: '#000',
          fontSize: '12px',
          padding: '4px',
          borderRadius: '4px',
          pointerEvents: 'none',
          zIndex: '10000',
          whiteSpace: 'pre-line'
        });
      }
    });
  }
  // Re-run annotations when tab content changes
  const container = document.getElementById('MP_HP_tabs_content');
  if (container) {
    const observer = new MutationObserver(updateAnnotations);
    observer.observe(container, { childList: true });
  }
  // Update annotations on window resize
  window.addEventListener('resize', updateAnnotations);
  // Initial annotation pass
  updateAnnotations();
  // Expose annotation control functions
  window.updateAnnotations = updateAnnotations;

  window.renderAnnotations = function() {
    window.annotationEnabled = true;
    updateAnnotations();
  };
});
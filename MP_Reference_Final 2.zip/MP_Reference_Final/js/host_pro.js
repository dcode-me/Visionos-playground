/**
 * host_pro.js
 * Manages annotation toggle and language switch for the host application.
 */

// -- Initial Annotation State --
window.annotationEnabled = true;

// -- Initialize Toggles on DOM Ready --
document.addEventListener("DOMContentLoaded", () => {
	// Annotation Toggle Button Setup
	const toggleBtn = document.getElementById("annotation-toggle");
	if (toggleBtn) {
		toggleBtn.setAttribute("aria-pressed", "true");
		toggleBtn.textContent = window.annotationEnabled
			? "Disable Annotations"
			: "Enable Annotations";
		// Handle annotation enable/disable clicks
		toggleBtn.addEventListener("click", () => {
			window.annotationEnabled = !window.annotationEnabled;
			toggleBtn.setAttribute("aria-pressed", window.annotationEnabled);
			toggleBtn.textContent = window.annotationEnabled
				? "Disable Annotations"
				: "Enable Annotations";
			if (window.annotationEnabled) {
				if (typeof updateAnnotations === "function") {
					updateAnnotations();
				}
			} else {
				document
					.querySelectorAll(
						".annotation-overlay, .annotation-overlay-content, .annotation-overlay-shell, .annotation-overlay-gap, .annotation-overlay-mfe"
					)
					.forEach((el) => el.remove());
			}
		});
	}
	// Language Switcher Logic
	const langSelect = document.getElementById('language-toggle');
	if (langSelect) {
		langSelect.value = window.currentLanguage;
		langSelect.addEventListener('change', e => {
			window.currentLanguage = e.target.value;
			if (typeof window.loadData === 'function') {
				window.loadData(window.currentLanguage);
			}
		});
	}
});

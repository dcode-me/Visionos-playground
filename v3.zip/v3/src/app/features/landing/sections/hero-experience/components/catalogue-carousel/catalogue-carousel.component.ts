import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, inject, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy, Output, EventEmitter, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CatalogueDataService, Product } from '../../services/catalogue-data.service';
import { TranslationService } from '../../../../../../core/services/translation.service';
import { TranslatePipe } from '../../../../../../shared/pipes/translate.pipe';

declare var gsap: any;
declare var ScrollToPlugin: any;

const canUseGsap = typeof gsap !== 'undefined' && typeof ScrollToPlugin !== 'undefined';
if (canUseGsap) {
  gsap.registerPlugin(ScrollToPlugin);
}

interface Category {
  key: string;
  label: string;
  icon?: string;
}

@Component({
  selector: 'app-catalogue-carousel',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslatePipe],
  templateUrl: './catalogue-carousel.component.html',
  styleUrls: ['./catalogue-carousel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CatalogueCarouselComponent implements OnInit, AfterViewInit, OnDestroy {
  // Constants for magic numbers and strings
  private readonly DEFAULT_CATEGORY = 'app-integrations';
  private readonly PARTNER_OFFERS_CATEGORY = 'partner-offers';
  private readonly ANIMATION_DURATION = 0.6;
  private readonly SEARCH_DEBOUNCE_MS = 300;
  private readonly FOCUS_ANIMATION_DELAY_MS = 400;
  private readonly SEARCH_BLUR_DELAY_MS = 200;
  private readonly NAV_UPDATE_DELAY_MS = 100;
  private readonly ANNOUNCE_DELAY_MS = 100;
  private readonly SCROLL_POLL_INTERVAL_MS = 50;
  private readonly SCROLL_POLL_MAX_COUNT = 40; // 40 * 50ms = 2s
  private readonly POSITION_THRESHOLD_PX = 1;
  private readonly POSITION_EPSILON_PX = 3;
  private readonly SAME_POSITION_COUNT = 3;
  private readonly VELOCITY_THRESHOLD = 0.5;
  private readonly MOMENTUM_MULTIPLIER = 150;
  private readonly SEGMENTED_WIDTH_ADJUSTMENT_PX = 16;
  private readonly MOBILE_INDICATOR_WIDTH_PX = 58;
  private readonly MOBILE_TRACK_WIDTH_PX = 176;
  private readonly TABINDEX_FOCUSABLE = 0;
  private readonly TABINDEX_NOT_FOCUSABLE = -1;
  
  // CSS Selectors
  private readonly SELECTORS = {
    RADIO: '[role="radio"]',
    CARD: '.carousel__card',
    DIVIDER: '.ds-segment-divider',
    SPACER_LEFT: '.carousel__spacer--left',
    SEARCH_ACTIVE: 'search-active'
  } as const;

  @ViewChild('carouselElement') carouselElement!: ElementRef;
  @ViewChild('carouselTrack') carouselTrack!: ElementRef;
  @ViewChild('inlineSearchInput') inlineSearchInput!: ElementRef;
  @ViewChild('segmentedControl') segmentedControlRef!: ElementRef;
  @ViewChild('searchToggle') searchToggle!: ElementRef;
  @ViewChild('carouselAnnouncer') carouselAnnouncer!: ElementRef<HTMLDivElement>;
  
  @Output() productClick = new EventEmitter<Product>();
  
  protected catalogueDataService = inject(CatalogueDataService);
  protected translationService = inject(TranslationService);
  private cdr = inject(ChangeDetectorRef);
  
  currentCategory = this.DEFAULT_CATEGORY;
  searchQuery = '';
  isSearching = false;
  isInlineSearchExpanded = false;
  products: Product[] = [];
  filteredProducts: Product[] = [];
  categories: Category[] = [];
  private isNavigating = false;
  private lastAnnounced = '';
  expandedCategories = new Set<string>();
  expandedMobileCategories = new Set<string>(); // Track expanded accordion sections on mobile
  
  get isLoading(): boolean {
    return this.catalogueDataService.isLoading();
  }
  
  segmentedControlWidth: number | null = null;
  originalRadioGroupWidth: number | null = null;
  private resizeObserver: ResizeObserver | null = null;
  private touchHandlersSetup = false;
  private windowResizeHandler?: () => void;
  
  canScrollPrev = false;
  canScrollNext = true;
  
  mobileProgressPosition = 0;
  
  private animationDuration = this.ANIMATION_DURATION;
  private searchDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private reducedMotion = false;
  private previousLanguage: string | undefined;
  
  constructor() {
    effect(() => {
      this.categories = this.catalogueDataService.categories();
      
      this.products = this.catalogueDataService.getAllProducts();
      this.filteredProducts = [...this.products];
      
      // Initialize first category as expanded on mobile when data loads
      if (this.categories.length > 0 && this.expandedMobileCategories.size === 0) {
        this.expandedMobileCategories.add(this.categories[0].key);
      }
      
      this.cdr.markForCheck();
      
      setTimeout(() => {
        this.updateNavigationButtons();
      }, this.NAV_UPDATE_DELAY_MS);
    });

    effect(() => {
      const currentLang = this.translationService.language();
      
      if (!this.previousLanguage) {
        this.previousLanguage = currentLang;
        return;
      }
      
      if (this.previousLanguage !== currentLang) {
        if (typeof window !== 'undefined') {
          window.location.reload();
        }
      }
    });
  }
  
  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    
    if (!this.catalogueDataService.isLoading()) {
      this.categories = this.catalogueDataService.categories();
      this.products = this.catalogueDataService.getAllProducts();
      this.filteredProducts = [...this.products];
      
      // Initialize first category as expanded on mobile
      if (this.categories.length > 0) {
        this.expandedMobileCategories.add(this.categories[0].key);
      }
    }
  }
  
  ngAfterViewInit(): void {
    if (typeof window === 'undefined') return;
    
    requestAnimationFrame(() => {
      if (this.segmentedControlRef) {
        this.captureSegmentedControlWidth();
        this.setupResizeObserver();
      }
      
      if (this.carouselTrack) {
        const track = this.carouselTrack.nativeElement;
        let rafId: number | null = null;
        
        track.addEventListener('scroll', () => {
          if (rafId) return;
          
          rafId = requestAnimationFrame(() => {
            rafId = null;
            
            this.updateNavigationButtons();
            
            if (!this.isNavigating) {
              const newCategory = this.detectCategoryByScroll();
              
              if (newCategory && newCategory !== this.currentCategory) {
                const focusInGroup = this.segmentedControlRef?.nativeElement?.contains(document.activeElement);
                
                const radioButtons = this.segmentedControlRef?.nativeElement.querySelectorAll(this.SELECTORS.RADIO);
                radioButtons?.forEach((btn: HTMLElement) => {
                  const isSelected = btn.dataset['category'] === newCategory;
                  btn.setAttribute('aria-checked', isSelected ? 'true' : 'false');
                  
                  if (!focusInGroup) {
                    btn.tabIndex = isSelected ? this.TABINDEX_FOCUSABLE : this.TABINDEX_NOT_FOCUSABLE;
                  }
                });
                
                this.currentCategory = newCategory;
                this.announceOnce(`Now viewing ${this.categories.find(c => c.key === newCategory)?.label} section`);
                this.cdr.markForCheck();
              }
            }
          });
        });
        
        // Only setup touch handlers for horizontal carousel (tablet/desktop)
        // Skip on mobile to avoid blocking vertical scrolling
        if (typeof window !== 'undefined' && window.innerWidth >= 768) {
          this.setupTouchHandlers(track);
          this.touchHandlersSetup = true;
        }
        
        // Handle window resize (orientation changes on mobile)
        if (typeof window !== 'undefined') {
          this.windowResizeHandler = () => {
            const currentWidth = window.innerWidth;
            const shouldHaveTouchHandlers = currentWidth >= 768;
            
            // Add touch handlers if viewport is now tablet/desktop and they're not set up
            if (shouldHaveTouchHandlers && !this.touchHandlersSetup) {
              this.setupTouchHandlers(track);
              this.touchHandlersSetup = true;
            }
            // Note: We don't remove touch handlers when going to mobile
            // as they check viewport width internally before preventing default
            
            // Recapture segmented control width on resize
            this.captureSegmentedControlWidth();
          };
          
          window.addEventListener('resize', this.windowResizeHandler);
        }
      }
      
      this.setupNumberKeyShortcuts();
      
      this.updateNavigationButtons();
    });
  }
  
  ngOnDestroy(): void {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
    if (this.windowResizeHandler && typeof window !== 'undefined') {
      window.removeEventListener('resize', this.windowResizeHandler);
    }
  }
  
  onTabClick(category: string): void {
    if (category !== this.currentCategory) {
      this.scrollToCategory(category);
    }
  }

  onRadioGroupKeydown(event: KeyboardEvent): void {
    const radios = Array.from((this.segmentedControlRef?.nativeElement as HTMLElement).querySelectorAll(this.SELECTORS.RADIO)) as HTMLElement[];
    if (radios.length === 0 || this.isInlineSearchExpanded) return;
    
    const active = document.activeElement as HTMLElement;
    const currentIndex = Math.max(0, radios.indexOf(active));
    let nextIndex = currentIndex;
    
    switch (event.key) {
      case 'ArrowLeft':
      case 'ArrowUp':
        event.preventDefault();
        nextIndex = currentIndex - 1 >= this.TABINDEX_FOCUSABLE ? currentIndex - 1 : radios.length - 1;
        break;
      case 'ArrowRight':
      case 'ArrowDown':
        event.preventDefault();
        nextIndex = currentIndex + 1 < radios.length ? currentIndex + 1 : this.TABINDEX_FOCUSABLE;
        break;
      case 'Home':
        event.preventDefault();
        nextIndex = this.TABINDEX_FOCUSABLE;
        break;
      case 'End':
        event.preventDefault();
        nextIndex = radios.length - 1;
        break;
      case ' ':
      case 'Enter':
        event.preventDefault();
        const category = radios[currentIndex]?.getAttribute('data-category');
        if (category) {
          this.scrollToCategory(category);
        }
        return;
    }
    
    if (nextIndex !== currentIndex) {
      const next = radios[nextIndex];
      if (next) {
        radios[currentIndex].tabIndex = this.TABINDEX_NOT_FOCUSABLE;
        next.tabIndex = this.TABINDEX_FOCUSABLE;
        next.focus();
        
        radios.forEach((el, i) => {
          el.setAttribute('aria-checked', i === nextIndex ? 'true' : 'false');
        });
        
        const category = next.getAttribute('data-category');
        if (category) {
          this.scrollToCategory(category);
        }
      }
    }
  }
  
  private setupNumberKeyShortcuts(): void {
    if (typeof document === 'undefined') return;
    
    document.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      
      const inContext = this.segmentedControlRef?.nativeElement?.contains(document.activeElement) || 
                        this.carouselTrack?.nativeElement?.contains(document.activeElement) ||
                        document.activeElement === this.carouselElement?.nativeElement;
      
      if (!inContext || this.isInlineSearchExpanded) return;
      
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= this.categories.length) {
        e.preventDefault();
        const targetCategory = this.categories[num - 1];
        if (targetCategory) {
          this.scrollToCategory(targetCategory.key, 'number-key');
          this.announceOnce(`Navigated to ${targetCategory.label} section`);
        }
      }
    });
  }
  
  scrollToCategory(category: string, source: string = 'unknown'): void {
    if (category === this.currentCategory && source !== 'number-key') return;
    
    if (this.isSearching) {
      this.clearSearch();
    }
    
    this.isNavigating = true;
    this.currentCategory = category;
    
    // Only select desktop cards for navigation
    const targetCard = this.carouselElement.nativeElement.querySelector(
      `.carousel__desktop-cards ${this.SELECTORS.CARD}[data-category="${category}"]`
    );
    
    if (targetCard && this.carouselTrack) {
      const scrollPosition = (targetCard as HTMLElement).offsetLeft;  // Use direct offsetLeft
      
      if (canUseGsap && !this.reducedMotion) {
        const currentPos = this.carouselTrack.nativeElement.scrollLeft;
        const distance = Math.abs(scrollPosition - currentPos);
        const viewportWidth = this.carouselTrack.nativeElement.clientWidth;
        
        let duration = Math.min(1.2, 0.4 + (distance / viewportWidth) * 0.3);
        
        duration = Math.max(0.3, duration);
        
        gsap.to(this.carouselTrack.nativeElement, {
          scrollTo: { x: scrollPosition, autoKill: false },
          duration: duration,
          ease: 'power2.inOut',
          onComplete: () => {
            this.isNavigating = false;
            this.updateNavigationButtons();
          }
        });
      } else {
        this.scrollWithFallback(scrollPosition);
      }
    }
  }
  
  onSearchInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.searchQuery = input.value;
    
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
    
    this.searchDebounceTimer = setTimeout(() => {
      this.handleSearch();
    }, this.SEARCH_DEBOUNCE_MS);
  }
  
  handleSearch(): void {
    const query = this.searchQuery.trim().toLowerCase();
    
    if (query) {
      this.isSearching = true;
      this.filteredProducts = this.products.filter(product => {
        const searchableText = [
          product.title,
          product.description,
          ...(product.keywords || [])
        ].join(' ').toLowerCase();
        
        return searchableText.includes(query);
      });
      
      // Auto-expand categories with search results on mobile
      const categoriesWithResults = new Set<string>();
      this.filteredProducts.forEach(product => {
        categoriesWithResults.add(product.category);
      });
      
      // Clear and set expanded categories based on search results
      this.expandedMobileCategories.clear();
      categoriesWithResults.forEach(category => {
        this.expandedMobileCategories.add(category);
      });
      
      const resultCount = this.filteredProducts.length;
      if (resultCount === 0) {
        this.announceOnce(`No results found for "${this.searchQuery}"`);
      } else if (resultCount === 1) {
        this.announceOnce(`1 result found for "${this.searchQuery}"`);
      } else {
        this.announceOnce(`${resultCount} results found for "${this.searchQuery}"`);
      }
      
      this.cdr.markForCheck();
      // Update navigation buttons after search results change
      setTimeout(() => this.updateNavigationButtons(), 0);
    } else {
      this.clearSearch();
    }
  }
  
  clearSearch(): void {
    this.searchQuery = '';
    this.isSearching = false;
    this.filteredProducts = [...this.products];
    
    // Restore default expansion state (first category) on mobile
    this.expandedMobileCategories.clear();
    if (this.categories.length > 0) {
      this.expandedMobileCategories.add(this.categories[0].key);
    }
    
    this.cdr.markForCheck();
    // Update navigation buttons after clearing search
    setTimeout(() => this.updateNavigationButtons(), 0);
  }
  
  expandInlineSearch(): void {
    if (this.isInlineSearchExpanded) return;
    
    // Ensure we have captured the widths before expanding
    if ((!this.segmentedControlWidth || !this.originalRadioGroupWidth) && this.segmentedControlRef) {
      this.captureSegmentedControlWidth();
    }
    
    
    this.isInlineSearchExpanded = true;
    
    // Add search-active class to segmented control
    this.segmentedControlRef?.nativeElement?.classList.add(this.SELECTORS.SEARCH_ACTIVE);
    
    // Set aria-busy to indicate the radiogroup is temporarily unavailable
    this.segmentedControlRef?.nativeElement?.setAttribute('aria-busy', 'true');
    
    // Store original tabindex and hide radio buttons from screen readers
    const radioButtons = this.segmentedControlRef?.nativeElement.querySelectorAll(this.SELECTORS.RADIO);
    radioButtons?.forEach((btn: HTMLElement) => {
      btn.setAttribute('aria-hidden', 'true');
      btn.setAttribute('data-prev-tabindex', btn.tabIndex.toString());
      btn.tabIndex = this.TABINDEX_NOT_FOCUSABLE;
    });
    
    // Also hide divider from screen readers
    const divider = this.segmentedControlRef?.nativeElement.querySelector(this.SELECTORS.DIVIDER);
    if (divider) {
      divider.setAttribute('aria-hidden', 'true');
    }
    
    // Focus input after animation completes
    setTimeout(() => {
      if (this.inlineSearchInput) {
        this.inlineSearchInput.nativeElement.focus();
      }
    }, this.FOCUS_ANIMATION_DELAY_MS); // Match CSS animation duration
    
    this.announceOnce(this.translationService.get('catalogue.searchExpanded') || 'Search expanded. Type to search products.');
    this.cdr.markForCheck();
  }
  
  collapseInlineSearch(): void {
    if (!this.isInlineSearchExpanded) return;
    
    const hadSearchContent = this.searchQuery.trim().length > 0;
    this.isInlineSearchExpanded = false;
    
    // Always clear search when closing
    this.searchQuery = '';
    this.clearSearch();
    
    // Remove search-active class from segmented control
    this.segmentedControlRef?.nativeElement?.classList.remove(this.SELECTORS.SEARCH_ACTIVE);
    
    // Remove aria-busy state
    this.segmentedControlRef?.nativeElement?.removeAttribute('aria-busy');
    
    // Restore radio buttons to screen readers and keyboard navigation
    const radioButtons = this.segmentedControlRef?.nativeElement.querySelectorAll(this.SELECTORS.RADIO);
    radioButtons?.forEach((btn: HTMLElement) => {
      btn.removeAttribute('aria-hidden');
      const prevTabIndex = btn.getAttribute('data-prev-tabindex');
      if (prevTabIndex !== null) {
        btn.tabIndex = parseInt(prevTabIndex, 10);
        btn.removeAttribute('data-prev-tabindex');
      }
    });
    
    // Restore divider visibility
    const divider = this.segmentedControlRef?.nativeElement.querySelector(this.SELECTORS.DIVIDER);
    if (divider) {
      divider.removeAttribute('aria-hidden');
    }
    
    // Return focus to search toggle for accessibility
    setTimeout(() => {
      this.searchToggle?.nativeElement?.focus?.();
    }, 0);
    
    // Announce appropriate message based on whether search had content
    if (hadSearchContent) {
      this.announceOnce(this.translationService.get('catalogue.searchClearedAndCollapsed') || 'Search cleared and collapsed.');
    } else {
      this.announceOnce(this.translationService.get('catalogue.searchCollapsed') || 'Search collapsed.');
    }
    
    this.cdr.markForCheck();
  }
  
  onInlineSearchBlur(event: FocusEvent): void {
    // Don't collapse if clicking the search button
    const relatedTarget = event.relatedTarget as HTMLElement;
    if (relatedTarget === this.searchToggle?.nativeElement) {
      return;
    }
    
    // Delay to allow for click events to register
    setTimeout(() => {
      if (this.isInlineSearchExpanded && !this.searchQuery) {
        this.collapseInlineSearch();
      }
    }, this.SEARCH_BLUR_DELAY_MS);
  }
  
  onInlineSearchInput(event: Event): void {
    // Reuse existing search logic
    this.onSearchInput(event);
  }

  // Focus trap and keyboard support for expanded search (circular trap)
  onInlineSearchKeydown(event: KeyboardEvent): void {
    if (!this.isInlineSearchExpanded) return;
    
    // Escape key to close search
    if (event.key === 'Escape') {
      event.preventDefault();
      this.collapseInlineSearch();
      return;
    }
    
    // Tab key handling for focus trap
    if (event.key === 'Tab') {
      // Both Tab and Shift+Tab from input go to button (circular)
      event.preventDefault();
      this.searchToggle?.nativeElement?.focus?.();
    }
  }

  onSearchButtonKeydown(event: KeyboardEvent): void {
    // Handle Space and Enter to toggle search when collapsed
    if (!this.isInlineSearchExpanded) {
      if (event.key === ' ' || event.key === 'Enter') {
        event.preventDefault();
        this.expandInlineSearch();
      }
      return;
    }
    
    // When expanded, handle focus trap and escape
    // Tab key handling for focus trap
    if (event.key === 'Tab') {
      // Both Tab and Shift+Tab from button go to input
      event.preventDefault();
      this.inlineSearchInput?.nativeElement?.focus?.();
    }
    
    // Allow Escape key to close from button as well
    if (event.key === 'Escape') {
      event.preventDefault();
      this.collapseInlineSearch();
    }
    
    // Space and Enter to close when expanded
    if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault();
      this.collapseInlineSearch();
    }
  }
  
  // Navigation - using CSS variables for flexibility
  navigatePrev(): void {
    if (!this.canScrollPrev || !this.carouselTrack) return;
    
    const track = this.carouselTrack.nativeElement;
    const targets = this.getCardTargets();
    if (targets.length === 0) return;
    const scrollLeft = track.scrollLeft;
    
    // Find nearest card index
    let currentIdx = 0;
    let bestDist = Infinity;
    targets.forEach((t, i) => {
      const d = Math.abs(scrollLeft - t.targetLeft);
      if (d < bestDist) {
        bestDist = d;
        currentIdx = i;
      }
    });
    
    const nextIdx = Math.max(0, currentIdx - 1);
    if (nextIdx !== currentIdx) {
      const target = targets[nextIdx];
      const newCategory = (target.el as HTMLElement).dataset['category'];
      if (newCategory && newCategory !== this.currentCategory) {
        this.currentCategory = newCategory;
        this.announceCategory(newCategory);
        this.cdr.markForCheck();
      }
      this.isNavigating = true;
      this.scrollToPosition(target.targetLeft);
    }
  }
  
  navigateNext(): void {
    if (!this.canScrollNext || !this.carouselTrack) return;
    
    const track = this.carouselTrack.nativeElement;
    const targets = this.getCardTargets();
    if (targets.length === 0) return;
    const scrollLeft = track.scrollLeft;
    
    // Find nearest card index
    let currentIdx = 0;
    let bestDist = Infinity;
    targets.forEach((t, i) => {
      const d = Math.abs(scrollLeft - t.targetLeft);
      if (d < bestDist) {
        bestDist = d;
        currentIdx = i;
      }
    });
    
    const nextIdx = Math.min(targets.length - 1, currentIdx + 1);
    if (nextIdx !== currentIdx) {
      const target = targets[nextIdx];
      const newCategory = (target.el as HTMLElement).dataset['category'];
      if (newCategory && newCategory !== this.currentCategory) {
        this.currentCategory = newCategory;
        this.announceCategory(newCategory);
        this.cdr.markForCheck();
      }
      this.isNavigating = true;
      this.scrollToPosition(target.targetLeft);
    }
  }
  
  // Helper to compute card targets using direct offsetLeft
  private getCardTargets(): Array<{ el: Element; targetLeft: number; width: number }> {
    const track = this.carouselTrack?.nativeElement as HTMLElement | undefined;
    if (!track) return [];
    // Only select desktop cards (not mobile accordion cards)
    const cards = Array.from(track.querySelectorAll('.carousel__desktop-cards .carousel__card'));
    return cards.map(card => {
      const el = card as HTMLElement;
      return {
        el,
        targetLeft: el.offsetLeft,  // Use direct offsetLeft, no spacer adjustment needed
        width: el.offsetWidth
      };
    }).sort((a, b) => a.targetLeft - b.targetLeft);
  }
  
  // Helper method to get spacer width
  private getSpacerWidth(): number {
    const spacer = this.carouselTrack?.nativeElement.querySelector(this.SELECTORS.SPACER_LEFT) as HTMLElement;
    return spacer?.offsetWidth || 0;
  }
  
  // Read the flex gap used by the track. Needed to correctly determine
  // whether we are at the very start, since the first card sits after
  // the left spacer AND one inter-item gap.
  private getTrackGap(): number {
    const track = this.carouselTrack?.nativeElement as HTMLElement | undefined;
    if (!track || typeof window === 'undefined') return 0;
    const styles = window.getComputedStyle(track);
    // Prefer columnGap; fall back to gap for broader support
    const gapValue = styles.columnGap || styles.gap || '0';
    const parsed = parseFloat(gapValue);
    return Number.isNaN(parsed) ? 0 : parsed;
  }
  
  private scrollToPosition(position: number): void {
    if (!this.carouselTrack) return;
    
    // Use same tiered approach as scrollToCategory
    if (canUseGsap && !this.reducedMotion) {
      gsap.to(this.carouselTrack.nativeElement, {
        scrollTo: { x: position, autoKill: false },
        duration: this.animationDuration,
        ease: 'power2.inOut',
        onComplete: () => {
          this.isNavigating = false;
          this.updateNavigationButtons();
        }
      });
    } else {
      this.scrollWithFallback(position);
    }
  }
  
  // TIER 2 & 3: Native scrollend event and polling fallback
  private scrollWithFallback(scrollPosition: number): void {
    if (!this.carouselTrack) return;
    const track = this.carouselTrack.nativeElement;
    
    // Check if scrollend event is supported (Chrome 114+, Safari 17+)
    if ('onscrollend' in track) {
      const handleScrollEnd = () => {
        this.isNavigating = false;
        this.updateNavigationButtons();
        track.removeEventListener('scrollend', handleScrollEnd);
      };
      
      track.addEventListener('scrollend', handleScrollEnd, { once: true });
      track.scrollTo({
        left: scrollPosition,
        behavior: this.reducedMotion ? 'auto' : 'smooth'
      });
    } else {
      // Fallback to position polling
      this.scrollWithPolling(scrollPosition);
    }
  }

  // TIER 3: Position polling (works everywhere)
  private scrollWithPolling(scrollPosition: number): void {
    if (!this.carouselTrack) return;
    const track = this.carouselTrack.nativeElement;
    
    let lastPos = track.scrollLeft;
    let samePositionCount = 0;
    let pollCount = 0;
    const maxPolls = this.SCROLL_POLL_MAX_COUNT; // 2 seconds max (40 * 50ms)
    
    track.scrollTo({
      left: scrollPosition,
      behavior: this.reducedMotion ? 'auto' : 'smooth'
    });
    
    const pollInterval = setInterval(() => {
      const currentPos = track.scrollLeft;
      pollCount++;
      
      // Position unchanged for 3 checks = scroll ended
      if (Math.abs(currentPos - lastPos) < this.POSITION_THRESHOLD_PX) {
        samePositionCount++;
        if (samePositionCount >= this.SAME_POSITION_COUNT) {
          clearInterval(pollInterval);
          this.isNavigating = false;
          this.updateNavigationButtons();
        }
      } else {
        samePositionCount = 0;
        lastPos = currentPos;
      }
      
      // Safety timeout after 2 seconds
      if (pollCount >= maxPolls) {
        clearInterval(pollInterval);
        this.isNavigating = false;
        this.updateNavigationButtons();
      }
    }, this.SCROLL_POLL_INTERVAL_MS);
  }
  
  private updateNavigationButtons(): void {
    if (!this.carouselTrack) return;
    
    // Disable both buttons if no products to display
    if (this.getDisplayProducts().length === 0) {
      if (this.canScrollPrev || this.canScrollNext) {
        this.canScrollPrev = false;
        this.canScrollNext = false;
        this.mobileProgressPosition = 0;
        this.cdr.markForCheck();
      }
      return;
    }
    
    const track = this.carouselTrack.nativeElement;
    const scrollLeft = track.scrollLeft;
    const targets = this.getCardTargets();
    if (targets.length === 0) {
      if (this.canScrollPrev || this.canScrollNext) {
        this.canScrollPrev = false;
        this.canScrollNext = false;
        this.cdr.markForCheck();
      }
      return;
    }
    
    // Check if content fits within viewport (no scrolling needed)
    const scrollWidth = track.scrollWidth;
    const clientWidth = track.clientWidth;
    const hasScrollableContent = scrollWidth > clientWidth + 1; // +1 for rounding tolerance
    
    if (!hasScrollableContent) {
      // Content fits entirely in viewport, disable both arrows
      if (this.canScrollPrev || this.canScrollNext) {
        this.canScrollPrev = false;
        this.canScrollNext = false;
        this.cdr.markForCheck();
      }
      return;
    }
    const roundedLeft = Math.round(scrollLeft);
    const EPS = this.POSITION_EPSILON_PX;
    
    // Find nearest target index
    let currentIdx = 0;
    let minDist = Infinity;
    targets.forEach((t, i) => {
      const d = Math.abs(scrollLeft - t.targetLeft);
      if (d < minDist) {
        minDist = d;
        currentIdx = i;
      }
    });
    
    // Boundaries
    const firstCard = targets[0];
    const lastCard = targets[targets.length - 1];
    const maxScroll = track.scrollWidth - track.clientWidth; // physical limit
    
    // For start detection: check if we're at or near the beginning
    const atStart = roundedLeft <= EPS;
    
    // For end detection: check if we've reached the maximum scroll position
    // This works correctly with dynamic card widths
    const atEnd = roundedLeft >= Math.round(maxScroll) - EPS;
    
    const nearTarget = minDist <= EPS;
    let canGoPrev: boolean;
    let canGoNext: boolean;
    if (nearTarget) {
      canGoPrev = currentIdx > 0;
      canGoNext = currentIdx < targets.length - 1;
    } else {
      canGoPrev = !atStart;
      canGoNext = !atEnd;
    }
    
    // Update mobile progress indicator
    if (maxScroll > 0) {
      const progress = Math.min(1, Math.max(0, scrollLeft / maxScroll));
      const indicatorWidth = this.MOBILE_INDICATOR_WIDTH_PX;
      const trackWidth = this.MOBILE_TRACK_WIDTH_PX;
      const maxTranslate = trackWidth - indicatorWidth;
      this.mobileProgressPosition = progress * maxTranslate;
    }
    
    if (this.canScrollPrev !== canGoPrev || this.canScrollNext !== canGoNext) {
      this.canScrollPrev = canGoPrev;
      this.canScrollNext = canGoNext;
      this.cdr.markForCheck();
    }
  }

  // Detect category based on nearest card using offset math
  // SAFARI/iOS COMPATIBILITY: Use offsetLeft, NOT getBoundingClientRect()
  // getBoundingClientRect() causes layout thrashing on iOS Safari during scroll
  private detectCategoryByScroll(): string {
    const track = this.carouselTrack?.nativeElement as HTMLElement | undefined;
    if (!track) return this.currentCategory;
    
    const scrollLeft = track.scrollLeft;
    // Only select desktop cards (not mobile accordion cards)
    const cards = Array.from(track.querySelectorAll('.carousel__desktop-cards .carousel__card'));
    
    // Find card closest to left edge of viewport
    let bestCard: Element | null = null;
    let bestDist = Infinity;
    
    for (const card of cards) {
      // Safari-safe: offsetLeft from container, not viewport
      const targetLeft = (card as HTMLElement).offsetLeft;
      const dist = Math.abs(scrollLeft - targetLeft);
      if (dist < bestDist) {
        bestDist = dist;
        bestCard = card;
      }
    }
    
    // Fallback to current if no card found (edge case protection)
    return (bestCard as HTMLElement)?.dataset?.['category'] || this.currentCategory;
  }

  // Live region announce helpers with spam guard
  private announce(message: string): void {
    if (!this.carouselAnnouncer) return;
    const el = this.carouselAnnouncer.nativeElement;
    // Clear then set to ensure announcement
    el.textContent = '';
    setTimeout(() => {
      el.textContent = message;
    }, this.ANNOUNCE_DELAY_MS);
  }
  
  // Announce only if message is different from last (spam guard)
  private announceOnce(message: string): void {
    if (message !== this.lastAnnounced) {
      this.announce(message);
      this.lastAnnounced = message;
    }
  }

  private announceCategory(categoryKey: string): void {
    const label = this.categories.find(c => c.key === categoryKey)?.label || categoryKey;
    const msg = this.translationService.get('catalogue.nowViewing', { section: label }) || `Now viewing ${label} section`;
    this.announceOnce(msg);
  }
  
  getDisplayProducts(): Product[] {
    if (this.isSearching && this.searchQuery) {
      return this.filteredProducts;
    }
    return this.products;
  }

  getProductsByCategory(categoryKey: string): Product[] {
    const products = this.getDisplayProducts();
    return products.filter(p => p.category === categoryKey);
  }
  
  expandCategory(categoryKey: string): void {
    this.expandedCategories.add(categoryKey);
    this.cdr.markForCheck();
  }
  
  isCategoryExpanded(categoryKey: string): boolean {
    return this.expandedCategories.has(categoryKey);
  }
  
  getVisibleProductsForCategory(categoryKey: string): Product[] {
    const products = this.getProductsByCategory(categoryKey);
    
    if (categoryKey === this.PARTNER_OFFERS_CATEGORY && !this.isCategoryExpanded(categoryKey)) {
      return [];
    }
    
    return products;
  }
  
  shouldShowViewMore(categoryKey: string): boolean {
    return categoryKey === this.PARTNER_OFFERS_CATEGORY && 
           !this.isCategoryExpanded(categoryKey) && 
           this.getProductsByCategory(categoryKey).length > 0;
  }
  
  getProductIcon(product: Product): string {
    return this.catalogueDataService.getProductIcon(product);
  }
  
  getCategoryIcon(category: string): string {
    return category;
  }
  
  trackByProductId(_index: number, product: Product): string {
    return product.id;
  }
  
  
  trackByCategoryKey(_index: number, category: Category): string {
    return category.key;
  }
  
  private captureSegmentedControlWidth(): void {
    if (!this.segmentedControlRef) return;
    
    const element = this.segmentedControlRef.nativeElement;
    
    const actualWidth = element.offsetWidth;
    
    if (actualWidth > 0 && !this.isInlineSearchExpanded) {
      this.originalRadioGroupWidth = actualWidth;
      
      this.segmentedControlWidth = actualWidth - this.SEGMENTED_WIDTH_ADJUSTMENT_PX;
    }
  }
  
  private setupResizeObserver(): void {
    if (!this.segmentedControlRef || typeof ResizeObserver === 'undefined') return;
    
    this.resizeObserver = new ResizeObserver(() => {
      if (!this.isInlineSearchExpanded) {
        this.captureSegmentedControlWidth();
      }
    });
    
    this.resizeObserver.observe(this.segmentedControlRef.nativeElement);
  }
  
  getSegmentedControlWidth(): string | null {
    if (this.isInlineSearchExpanded && this.originalRadioGroupWidth) {
      return `${this.originalRadioGroupWidth}px`;
    }
    return null;
  }
  
  private setupTouchHandlers(track: HTMLElement): void {
    let startX = 0;
    let startScrollLeft = 0;
    let isDragging = false;
    let velocity = 0;
    let lastX = 0;
    let lastTime = Date.now();
    
    track.addEventListener('touchstart', (e: TouchEvent) => {
      startX = e.touches[0].clientX;
      startScrollLeft = track.scrollLeft;
      isDragging = true;
      velocity = 0;
      lastX = startX;
      lastTime = Date.now();
    }, { passive: true });
    
    track.addEventListener('touchmove', (e: TouchEvent) => {
      if (!isDragging) return;
      
      e.preventDefault();
      const currentX = e.touches[0].clientX;
      const diff = startX - currentX;
      
      const currentTime = Date.now();
      const timeDiff = currentTime - lastTime;
      if (timeDiff > 0) {
        velocity = (currentX - lastX) / timeDiff;
      }
      
      lastX = currentX;
      lastTime = currentTime;
      
      track.scrollLeft = startScrollLeft + diff;
    }, { passive: false });
    
    track.addEventListener('touchend', () => {
      isDragging = false;
      
      if (Math.abs(velocity) > this.VELOCITY_THRESHOLD) {
        const momentum = velocity * this.MOMENTUM_MULTIPLIER;
        track.scrollBy({
          left: -momentum,
          behavior: 'smooth'
        });
      }
      
      startX = 0;
      startScrollLeft = 0;
      velocity = 0;
    }, { passive: true });
    
    track.addEventListener('touchcancel', () => {
      isDragging = false;
      startX = 0;
      startScrollLeft = 0;
      velocity = 0;
    }, { passive: true });
  }
  
  onCardClick(eventOrProduct: Event | Product, product?: Product): void {
    if (eventOrProduct instanceof Event) {
      eventOrProduct.preventDefault();
      if (product) {
        this.handleProductClick(product);
      }
    } else {
      this.handleProductClick(eventOrProduct);
    }
  }
  
  private handleProductClick(product: Product): void {
    this.productClick.emit(product);
    
    if (product.url) {
      window.open(product.url, '_blank', 'noopener,noreferrer');
    }
  }

  // Mobile accordion methods
  toggleMobileCategory(categoryKey: string): void {
    if (this.expandedMobileCategories.has(categoryKey)) {
      this.expandedMobileCategories.delete(categoryKey);
      this.announceOnce(`${this.categories.find(c => c.key === categoryKey)?.label} section collapsed`);
    } else {
      this.expandedMobileCategories.add(categoryKey);
      this.announceOnce(`${this.categories.find(c => c.key === categoryKey)?.label} section expanded`);
    }
    this.cdr.markForCheck();
  }
  
  isMobileCategoryExpanded(categoryKey: string): boolean {
    return this.expandedMobileCategories.has(categoryKey);
  }
  
  onMobileAccordionKeydown(event: KeyboardEvent, categoryKey: string): void {
    if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault();
      this.toggleMobileCategory(categoryKey);
    }
  }

}
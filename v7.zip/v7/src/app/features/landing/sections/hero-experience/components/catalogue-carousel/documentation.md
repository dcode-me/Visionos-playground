# Documentation: CatalogueCarouselComponent

This document provides a detailed explanation of the `CatalogueCarouselComponent`, its architecture, and its core functionalities.

## 1. High-Level Overview

The `CatalogueCarouselComponent` is a feature-rich, interactive UI component designed to showcase a collection of products.

### Core Responsibilities:

- **Display Products:** Renders a list of products in a horizontal, scrollable carousel.
- **Categorization:** Groups products by category and allows users to filter by selecting category tabs.
- **Multi-faceted Navigation:** Provides several methods for navigation:
    - Clicking category tabs.
    - Previous/Next arrow buttons.
    - Manual scroll/swipe.
    - Keyboard shortcuts (Arrows, Home/End, Number keys).
- **Inline Search:** Features an integrated, animated search bar to filter products in real-time.
- **Accessibility (A11y):** Built with robust accessibility, including ARIA roles, screen reader announcements, and full keyboard support.

---

## 2. Architecture & Data Flow

The component follows a modern, reactive Angular architecture.

### State Management:

- **`CatalogueDataService`:** The component gets all its data (products, categories, loading status) from this injectable service. This service acts as the single source of truth.
- **Angular Signals & `effect()`:** The component is highly reactive. It uses an `effect()` within its `constructor` to automatically subscribe to data changes from the signals provided by the `CatalogueDataService`. When data is updated in the service (e.g., products finish loading), the `effect` re-runs, updating the component's internal state.
- **`ChangeDetectionStrategy.OnPush`:** The component is optimized for performance by only re-rendering when its inputs change or when explicitly told to via `cdr.markForCheck()`. This prevents unnecessary render cycles.

---

## 3. Component Lifecycle

The component leverages Angular's lifecycle hooks to manage setup and teardown in an organized manner.

- **`constructor()`:**
    - Injects dependencies (`CatalogueDataService`, `TranslationService`, `ChangeDetectorRef`).
    - Sets up the primary `effect()` to react to data changes from the service throughout the component's lifetime.
- **`ngOnInit()`:**
    - Runs after the constructor.
    - Handles non-DOM-related setup, such as checking the user's OS-level preference for reduced motion (`prefers-reduced-motion`).
- **`ngAfterViewInit()`:**
    - Runs once after the component's view (HTML) has been rendered.
    - This is where all DOM manipulation and event listener setup occurs, as `@ViewChild` properties are now available.
    - **Key tasks:**
        - Attaches a `scroll` event listener to the carousel track.
        - Sets up custom touch handlers for mobile swiping.
        - Initializes a `ResizeObserver` to watch for element size changes.
        - Attaches global keyboard shortcut listeners.
- **`ngOnDestroy()`:**
    - Runs just before the component is removed from the DOM.
    - **Performs cleanup:** Disconnects the `ResizeObserver` and clears any pending timers (`setTimeout`) to prevent memory leaks.

---

## 4. Scrolling & Navigation Logic

This is the most complex part of the component, handling both programmatic and user-driven scrolling.

### The "Sync Guard" Pattern

The component must handle two scenarios without them conflicting:
1.  **Programmatic Scroll:** The user clicks a tab, and the code scrolls the carousel to the correct position.
2.  **Manual Scroll:** The user scrolls the carousel, and the code updates the active tab.

A private boolean flag, `isNavigating`, is used as a "sync guard" to manage this.

- When `scrollToCategory()` is called (programmatic scroll), it immediately sets `this.isNavigating = true`.
- The `scroll` event listener is wrapped in an `if (!this.isNavigating)` check. While the programmatic animation is running, this check fails, and the listener does nothing.
- Once the GSAP animation is complete, its `onComplete` callback sets `this.isNavigating = false`, returning control to the user.

### Tiered Scrolling Implementation

For maximum compatibility and performance, programmatic scrolling uses a tiered fallback system:
1.  **Tier 1 (GSAP):** If the GSAP library is available, it's used for smooth, powerful, and interruptible animations.
2.  **Tier 2 (`scrollend` event):** If GSAP is not available, it tries to use the modern, native `scrollend` browser event to know when a `scrollTo` action has finished.
3.  **Tier 3 (Polling):** As a final fallback for older browsers, it manually polls the element's `scrollLeft` position in a `setInterval` to guess when the scrolling has stopped.

---

## 5. Inline Search Feature

The component includes a sophisticated inline search that animates smoothly within the category tab bar.

### Core Mechanics:

- **Debouncing Input:** To prevent performance issues, the search does not run on every keystroke. It uses a `setTimeout` to "debounce" the input. The actual search logic (`handleSearch`) only runs after the user has stopped typing for 300ms.
- **Animation with Width Preservation:** The smooth expand/collapse animation is a clever illusion:
    1.  When the user clicks the search icon, the component first measures and saves the exact pixel width of the tab container.
    2.  It then sets the `isInlineSearchExpanded` flag to `true`.
    3.  In the template, this flag hides the category tabs and shows the search input.
    4.  Crucially, the saved width is applied as an inline `style.width` to the tab container. This prevents the container from "janking" or resizing jarringly during the animation. The search bar appears to expand perfectly into the space formerly occupied by the tabs.
- **`ResizeObserver`:** To handle cases where the user resizes the browser window, a `ResizeObserver` is attached to the tab container. It automatically re-measures and updates the stored width whenever the container's size changes, ensuring the animation is always smooth.

---

## 6. Accessibility (A11y) & Keyboard Navigation

The component is built to be highly accessible for users who rely on keyboards or screen readers.

### Core Features:

- **Accessible Tabs with Roving Tabindex:**
    - The category tabs are implemented semantically as a `role="radiogroup"`.
    - It uses the **roving tabindex** pattern: only the currently active tab has `tabindex="0"`, making it part of the page's natural tab order. All other tabs have `tabindex="-1"`.
    - Users navigate *between* the tabs using the Arrow keys, as is standard for radio groups, rather than having to press `Tab` multiple times.
- **Focus Trap:**
    - When the inline search feature is expanded, a **focus trap** is activated.
    - This means the user's focus is contained entirely within the search input and its close button. Pressing `Tab` cycles between these two elements, preventing the focus from getting lost on the page behind the search UI.
    - The trap is released when the user presses `Escape` or clicks the close button.
- **Screen Reader Announcements:**
    - A visually hidden `div` with an `aria-live="polite"` attribute acts as a screen reader announcer.
    - Helper methods (`announceOnce`) are used to push helpful, non-visual information to this div, such as "5 results found" or "Now viewing App Integrations section," keeping the user informed of dynamic changes on the screen.
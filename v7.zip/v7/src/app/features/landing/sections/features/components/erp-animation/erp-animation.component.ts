import { Component, AfterViewInit, OnDestroy, Inject, PLATFORM_ID, signal, ElementRef, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

declare const gsap: any;

interface TabData {
  id: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-erp-animation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './erp-animation.component.html',
  styleUrls: ['./erp-animation.component.scss']
})
export class ErpAnimationComponent implements AfterViewInit, OnDestroy {
  @ViewChild('tablist', { static: false }) tablistRef!: ElementRef;
  @ViewChildren('syncContainer') syncContainers!: QueryList<ElementRef>;
  @ViewChildren('payablesContainer') payablesContainers!: QueryList<ElementRef>;
  @ViewChildren('cashflowContainer') cashflowContainers!: QueryList<ElementRef>;

  private readonly SWITCH_INTERVAL = 5000;
  private readonly TAB1_INTERVAL = 6250; // Matches Tab 1 timeline duration
  private readonly TAB2_INTERVAL = 6500;
  private readonly TAB3_INTERVAL = 6000;
  private autoSwitchTimer?: number;
  private pausedProgress?: number;
  private remainingTime?: number;

  // Animation timelines
  private syncTimeline?: any;
  private syncTimelineProgress?: number;
  private payablesTimeline?: any;
  private payablesTimelineProgress?: number;
  private cashflowTimeline?: any;
  private cashflowTimelineProgress?: number;
  private shouldRestartFromBeginning?: boolean;

  currentTabIndex = signal(0);
  isPlaying = signal(true);
  userInteracted = signal(false);
  private tabChangeAnnouncement = signal('');
  private playStateAnnouncement = signal('');
  
  readonly tabs: TabData[] = [
    {
      id: 'sync-reconcile',
      title: 'Sync & Reconcile',
      description: 'Automatically sync and reconcile your financial data across all systems'
    },
    {
      id: 'automate-payables',
      title: 'Automate Payables',
      description: 'Streamline your payment processes with intelligent automation'
    },
    {
      id: 'cashflow-insights',
      title: 'Cashflow Insights',
      description: 'Real-time visibility into your cash position and financial health'
    }
  ];
  
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private elementRef: ElementRef
  ) {}

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initializeCarousel();
      this.setupEventListeners();
      setTimeout(() => {
        this.initializeAnimations();
        this.startAutoSwitch();
      }, 100);
    }
  }

  ngOnDestroy(): void {
    this.cleanup();
    this.destroyAnimations();
  }

  private initializeAnimations(): void {
    if (!isPlatformBrowser(this.platformId) || typeof gsap === 'undefined') return;

    this.initializeSyncAnimation();
    this.initializePayablesAnimation();
    this.initializeCashflowAnimation();
  }

  private initializeSyncAnimation(): void {
    const syncContainer = this.syncContainers.first;
    if (!syncContainer) return;

    const container = syncContainer.nativeElement;
    const bmoWrapper = container.querySelector('#bmo-wrapper');
    const xeroWrapper = container.querySelector('#xero-wrapper');
    const connectionLineTop = container.querySelector('.connection-line-top');
    const connectionLineBottom = container.querySelector('.connection-line-bottom');
    const connectionCircle = container.querySelector('.connection-circle');
    const pulseTop = container.querySelector('.pulse-top');
    const pulseBottom = container.querySelector('.pulse-bottom');
    const ballContainer = container.querySelector('.ball-container');
    const ball1 = container.querySelector('.ball-1');
    const ball2 = container.querySelector('.ball-2');
    const checkMark = container.querySelector('.check-mark');

    if (!bmoWrapper || !xeroWrapper) return;

    this.syncTimeline = gsap.timeline({
      repeat: -1,
      repeatDelay: 0.5,
      paused: true
    });

    // Initial states
    gsap.set(bmoWrapper, { opacity: 0, y: -15 });
    gsap.set(xeroWrapper, { opacity: 0, y: 15 });
    gsap.set(connectionCircle, { scale: 0, opacity: 0 });
    gsap.set([connectionLineTop, connectionLineBottom], { scaleY: 0, opacity: 0 });
    gsap.set(pulseTop, { bottom: 'calc(50% + 60px)', opacity: 0 });
    gsap.set(pulseBottom, { top: 'calc(50% + 60px)', opacity: 0 });
    gsap.set(ballContainer, { rotation: 0, opacity: 0 });
    gsap.set(checkMark, { scale: 0, opacity: 0 });

    // Animation sequence
    this.syncTimeline
      .add("entry")
      .to(bmoWrapper, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power2.out"
      }, "entry")
      .to(xeroWrapper, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power2.out"
      }, "entry")
      .to(connectionLineTop, {
        scaleY: 1,
        opacity: 1,
        duration: 0.3,
        ease: "power2.inOut"
      }, "entry+=0.4")
      .to(connectionLineBottom, {
        scaleY: 1,
        opacity: 1,
        duration: 0.3,
        ease: "power2.inOut"
      }, "entry+=0.4")
      .add("pulseStart", "entry+=0.8")
      .to(pulseTop, {
        opacity: 1,
        duration: 0.15,
        ease: "power2.in"
      }, "pulseStart")
      .to(pulseBottom, {
        opacity: 1,
        duration: 0.15,
        ease: "power2.in"
      }, "pulseStart")
      .to(pulseTop, {
        bottom: 'calc(50% - 16px)',
        duration: 0.5,
        ease: "none"
      }, "pulseStart")
      .to(pulseBottom, {
        top: 'calc(50% - 16px)',
        duration: 0.5,
        ease: "none"
      }, "pulseStart")
      .to(connectionCircle, {
        opacity: 1,
        scale: 0.9,
        duration: 0.2,
        ease: "power2.out"
      }, "pulseStart+=0.15")
      .to(connectionCircle, {
        scale: 1,
        duration: 0.2,
        ease: "power2.out"
      }, "pulseStart+=0.25")
      .add("transform", "pulseStart+=0.5")
      .to([pulseTop, pulseBottom], {
        opacity: 0,
        duration: 0.05,
        ease: "power2.out"
      }, "transform")
      .set(ballContainer, {
        opacity: 1
      }, "transform")
      .to(ballContainer, {
        rotation: 360,
        duration: 1.4,
        ease: "none"
      }, "transform+=0.05")
      .add("merge", "transform+=1.45")
      .to(bmoWrapper, {
        y: 60,
        zIndex: 4,
        duration: 0.9,
        ease: "power2.inOut"
      }, "merge")
      .to(xeroWrapper, {
        y: -60,
        duration: 0.9,
        ease: "power2.inOut"
      }, "merge")
      .to([connectionLineTop, connectionLineBottom], {
        opacity: 0,
        scaleY: 0.5,
        duration: 0.6,
        ease: "power2.in"
      }, "merge")
      .to(ballContainer, {
        rotation: 720,
        duration: 1.2,
        ease: "none"
      }, "merge")
      .add("collision", "merge+=0.9")
      .to(ball1, {
        top: '50%',
        transform: 'translate(-50%, -50%)',
        duration: 0.4,
        ease: "power2.in"
      }, "collision")
      .to(ball2, {
        bottom: 'auto',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        duration: 0.4,
        ease: "power2.in"
      }, "collision")
      .to([ball1, ball2], {
        scale: 0,
        duration: 0.3,
        ease: "power2.out"
      }, "collision+=0.4")
      .to([bmoWrapper, xeroWrapper], {
        opacity: 0.5,
        duration: 0.3,
        ease: "power2.out"
      }, "collision+=0.3")
      .add("success", "collision+=0.8")
      .to(connectionCircle, {
        backgroundColor: '#10b981',
        border: '2px solid rgba(16, 185, 129, 0.3)',
        boxShadow: '0 0 30px rgba(16, 185, 129, 0.8), inset 0 0 20px rgba(16, 185, 129, 0.2)',
        duration: 0.4,
        ease: "power2.inOut"
      }, "success")
      .set(checkMark, {
        scale: 0,
        opacity: 1
      }, "success")
      .to(checkMark, {
        scale: 1,
        duration: 0.5,
        ease: "back.out(1.7)"
      }, "success+=0.2")
      .set(checkMark.querySelector('svg path'), {
        strokeDasharray: 30,
        strokeDashoffset: 30
      }, "<")
      .to(checkMark.querySelector('svg path'), {
        strokeDashoffset: 0,
        duration: 0.5,
        ease: "power2.out"
      }, "<")
      .to([bmoWrapper, xeroWrapper], {
        opacity: 1,
        duration: 0.3,
        ease: "power2.out"
      }, "success+=0.3")
      // Hold state
      .to({}, { duration: 0.5 })
      // Exit animation
      .to([bmoWrapper, xeroWrapper, connectionCircle], {
        opacity: 0,
        scale: 0.9,
        duration: 0.6,
        ease: "power2.in",
        onComplete: () => {
          // Reset all elements for clean loop
          gsap.set(bmoWrapper, { opacity: 0, y: -15, scale: 1, zIndex: 'auto' });
          gsap.set(xeroWrapper, { opacity: 0, y: 15, scale: 1, zIndex: 'auto' });
          gsap.set(connectionCircle, { scale: 0, opacity: 0, backgroundColor: '#ffffff', border: 'none', boxShadow: '0 0 10px rgba(255, 255, 255, 0.5)' });
          gsap.set([connectionLineTop, connectionLineBottom], { scaleY: 0, opacity: 0 });
          gsap.set(pulseTop, { bottom: 'calc(50% + 60px)', opacity: 0 });
          gsap.set(pulseBottom, { top: 'calc(50% + 60px)', opacity: 0 });
          gsap.set(ballContainer, { rotation: 0, opacity: 0 });
          gsap.set([ball1, ball2], { scale: 1, opacity: 1 });
          gsap.set(ball1, { top: '4px', left: '50%', transform: 'translateX(-50%)' });
          gsap.set(ball2, { bottom: '4px', top: 'auto', left: '50%', transform: 'translateX(-50%)' });
          gsap.set(checkMark, { scale: 0, opacity: 0 });
        }
      });

    // Log the actual timeline duration (one cycle, not including repeats)
  }

  private initializePayablesAnimation(): void {
    const payablesContainer = this.payablesContainers.first;
    if (!payablesContainer) return;

    const container = payablesContainer.nativeElement;
    const steps = gsap.utils.toArray(container.querySelectorAll('.process-step'));
    const statuses = gsap.utils.toArray(container.querySelectorAll('.step-status'));
    const cardWrapper = container;

    if (!cardWrapper || steps.length === 0) return;

    this.payablesTimeline = gsap.timeline({
      repeat: -1,
      repeatDelay: 0.5,
      defaults: { ease: "power1.inOut" },
      paused: true
    });

    steps.forEach((step: any) => step.classList.remove('completed'));
    gsap.set(cardWrapper, { opacity: 0, y: 40 });
    gsap.set(steps, { opacity: 0, y: 20 });
    gsap.set(statuses, { opacity: 0, x: -10 });

    this.payablesTimeline.call(() => {
      steps.forEach((step: any) => step.classList.remove('completed'));
    });

    this.payablesTimeline.to(cardWrapper, {
      opacity: 1,
      y: 0,
      duration: 0.7,
      ease: "power3.out"
    }, 0.3);

    steps.forEach((step: any, i: number) => {
      this.payablesTimeline.to(step, {
        opacity: 1,
        y: 0,
        duration: 0.5,
        ease: "power3.out"
      }, i === 0 ? "+=0.2" : "+=0.4")
      .to(statuses[i], {
        opacity: 1,
        x: 0,
        duration: 0.3
      }, "+=0.2")
      .call(() => step.classList.add('completed'));
    });

    this.payablesTimeline.to({}, { duration: 0.5 });

    this.payablesTimeline.to(cardWrapper, {
      opacity: 0,
      y: 40,
      duration: 0.7,
      ease: "power2.in",
      onComplete: () => {
        gsap.set(steps, { opacity: 0, y: 20 });
        gsap.set(statuses, { opacity: 0, x: -10 });
        gsap.set(cardWrapper, { opacity: 0, y: 40 });
      }
    });
  }

  private initializeCashflowAnimation(): void {
    const cashflowContainer = this.cashflowContainers.first;
    if (!cashflowContainer) return;

    const container = cashflowContainer.nativeElement;
    const chartContainer = container.querySelector('.chart-container');
    const revenueBars = gsap.utils.toArray(container.querySelectorAll('.bar.revenue'));
    const expenseBars = gsap.utils.toArray(container.querySelectorAll('.bar.expense'));
    const allBars = [...revenueBars, ...expenseBars];

    if (!chartContainer || revenueBars.length === 0) return;

    this.cashflowTimeline = gsap.timeline({
      repeat: -1,
      repeatDelay: 0.5,
      defaults: { ease: "power3.out" },
      paused: true
    });

    gsap.set(chartContainer, { opacity: 0, y: 30 });
    gsap.set(revenueBars, { opacity: 0, scaleY: 0, transformOrigin: "bottom" });
    gsap.set(expenseBars, { opacity: 0, scaleY: 0, transformOrigin: "top" });

    this.cashflowTimeline.to(chartContainer, {
      opacity: 1,
      y: 0,
      duration: 0.8,
      ease: "power2.out"
    });

    this.cashflowTimeline.to(revenueBars, {
      opacity: 1,
      scaleY: 1,
      duration: 1.2,
      stagger: 0.05
    }, "+=0.2");

    this.cashflowTimeline.to(expenseBars, {
      opacity: 1,
      scaleY: 1,
      duration: 1.2,
      stagger: 0.05
    }, "-=0.6");

    this.cashflowTimeline.to({}, { duration: 0.5 });

    this.cashflowTimeline.to(allBars, {
      opacity: 0,
      scaleY: 0,
      duration: 0.8,
      stagger: 0.03,
      ease: "power2.in"
    });

    this.cashflowTimeline.to(chartContainer, {
      opacity: 0,
      y: 30,
      duration: 0.6,
      ease: "power2.in",
      onComplete: () => {
        gsap.set(chartContainer, { opacity: 0, y: 30 });
        gsap.set(revenueBars, { opacity: 0, scaleY: 0 });
        gsap.set(expenseBars, { opacity: 0, scaleY: 0 });
      }
    }, "-=0.3");
  }

  private destroyAnimations(): void {
    if (this.syncTimeline) {
      this.syncTimeline.kill();
      this.syncTimeline = null;
    }
    if (this.payablesTimeline) {
      this.payablesTimeline.kill();
      this.payablesTimeline = null;
    }
    if (this.cashflowTimeline) {
      this.cashflowTimeline.kill();
      this.cashflowTimeline = null;
    }
  }
  
  private initializeCarousel(): void {
    this.setActiveTab(0, false);
    this.resetAllProgressBars();
  }
  
  private setupEventListeners(): void {
    if (!this.tablistRef) return;
    
    const tablist = this.tablistRef.nativeElement;
    
    tablist.addEventListener('keydown', (event: KeyboardEvent) => {
      this.handleKeyboardNavigation(event);
    });
  }
  
  onTabClick(index: number): void {
    if (index === this.currentTabIndex()) return;

    this.userInteracted.set(true);
    this.stopAutoSwitch();
    this.remainingTime = undefined;
    this.pausedProgress = undefined;
    this.payablesTimelineProgress = undefined;
    this.setActiveTab(index, false);

    const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[index] as HTMLElement;
    if (progressBar) {
      progressBar.style.transition = 'width 0.2s ease-out';
      progressBar.style.width = '100%';
    }
  }
  
  togglePlayPause(): void {
    const playing = !this.isPlaying();
    this.isPlaying.set(playing);

    this.playStateAnnouncement.set(playing ?
      'Animation resumed' :
      'Animation paused');

    if (playing) {
      this.userInteracted.set(false);
      const currentIndex = this.currentTabIndex();

      if (currentIndex === 0 && this.syncTimeline && this.syncTimeline.paused()) {
        this.syncTimeline.resume();
      }

      if (currentIndex === 1 && this.payablesTimeline && this.payablesTimeline.paused()) {
        this.payablesTimeline.resume();
      }

      if (currentIndex === 2 && this.cashflowTimeline && this.cashflowTimeline.paused()) {
        this.cashflowTimeline.resume();
      }
      if (this.remainingTime && this.remainingTime > 0) {
        this.resumeAnimation();
      } else {
        this.startAutoSwitch();
      }
    } else {
      this.pauseAnimation();
    }
  }
  
  private setActiveTab(index: number, setFocus: boolean = false): void {
    const previousIndex = this.currentTabIndex();
    this.currentTabIndex.set(index);

    if (previousIndex !== index) {
      const tab = this.tabs[index];
      this.tabChangeAnnouncement.set(`Now showing ${tab.title}. ${tab.description}`);

      // Handle animation switching
      this.switchTabAnimation(previousIndex, index);
    }

    this.updateProgressBars(index);

    if (setFocus) {
      const tabs = this.elementRef.nativeElement.querySelectorAll('.erp-animation__tab');
      if (tabs[index]) {
        (tabs[index] as HTMLElement).focus();
      }
    }
  }

  private switchTabAnimation(_previousIndex: number, currentIndex: number): void {
    this.pauseAllAnimations();
    this.playTabAnimation(currentIndex);
  }

  private pauseAllAnimations(): void {
    if (this.syncTimeline) {
      this.syncTimeline.pause();
    }
    if (this.payablesTimeline) {
      this.payablesTimeline.pause();
    }
    if (this.cashflowTimeline) {
      this.cashflowTimeline.pause();
    }
  }

  private playTabAnimation(index: number): void {
    // Tab 1 (index 0) - Sync & Reconcile Animation
    if (index === 0 && this.syncTimeline) {

      if (!this.isPlaying()) {
        this.syncTimeline.restart();
        this.syncTimeline.progress(0.95);
        this.syncTimeline.pause();
        this.syncTimelineProgress = undefined;
        this.shouldRestartFromBeginning = true;
      } else {
        this.syncTimeline.restart();
        this.syncTimelineProgress = undefined;
        this.shouldRestartFromBeginning = false;
      }
    }

    if (index === 1 && this.payablesTimeline) {
      if (!this.isPlaying()) {
        this.payablesTimeline.restart();
        this.payablesTimeline.progress(0.9);
        this.payablesTimeline.pause();
        this.payablesTimelineProgress = undefined;
        this.shouldRestartFromBeginning = true;
      } else {
        this.payablesTimeline.restart();
        this.payablesTimelineProgress = undefined;
        this.shouldRestartFromBeginning = false;
      }
    }

    if (index === 2 && this.cashflowTimeline) {
      if (!this.isPlaying()) {
        this.cashflowTimeline.restart();
        this.cashflowTimeline.progress(0.8);
        this.cashflowTimeline.pause();
        this.cashflowTimelineProgress = undefined;
        this.shouldRestartFromBeginning = true;
      } else {
        this.cashflowTimeline.restart();
        this.cashflowTimelineProgress = undefined;
        this.shouldRestartFromBeginning = false;
      }
    }
  }
  
  private startAutoSwitch(): void {
    if (this.userInteracted() || !this.isPlaying()) return;

    clearTimeout(this.autoSwitchTimer);

    const currentIndex = this.currentTabIndex();

    // Check if the animation needs to be started
    if (currentIndex === 0 && this.syncTimeline && this.syncTimeline.paused()) {
      this.playTabAnimation(0);
    } else if (currentIndex === 1 && this.payablesTimeline && this.payablesTimeline.paused()) {
      this.playTabAnimation(1);
    } else if (currentIndex === 2 && this.cashflowTimeline && this.cashflowTimeline.paused()) {
      this.playTabAnimation(2);
    }

    this.remainingTime = currentIndex === 0 ? this.TAB1_INTERVAL :
                        currentIndex === 1 ? this.TAB2_INTERVAL :
                        currentIndex === 2 ? this.TAB3_INTERVAL :
                        this.SWITCH_INTERVAL;

    this.animateProgressBar(this.currentTabIndex(), this.remainingTime);

    this.autoSwitchTimer = window.setTimeout(() => {
      const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
      this.setActiveTab(nextIndex, false);
      this.startAutoSwitch();
    }, this.remainingTime);
  }
  
  private pauseAnimation(): void {
    clearTimeout(this.autoSwitchTimer);

    const currentIndex = this.currentTabIndex();
    const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[currentIndex] as HTMLElement;

    if (currentIndex === 0 && this.syncTimeline) {
      this.syncTimelineProgress = this.syncTimeline.progress();
      const totalDuration = this.syncTimeline.duration();
      const remainingDuration = totalDuration * (1 - (this.syncTimelineProgress || 0));
      this.remainingTime = remainingDuration * 1000;
      this.pausedProgress = undefined;
      this.pauseAllAnimations();

      if (progressBar) {
        const computedStyle = window.getComputedStyle(progressBar);
        const currentWidth = parseFloat(computedStyle.width);
        const parentWidth = progressBar.parentElement?.offsetWidth || 1;
        const progressPercent = (currentWidth / parentWidth) * 100;
        progressBar.style.transition = 'none';
        progressBar.style.width = `${progressPercent}%`;
      }
    } else if (currentIndex === 1 && this.payablesTimeline) {
      this.payablesTimelineProgress = this.payablesTimeline.progress();
      const totalDuration = this.payablesTimeline.duration();
      const remainingDuration = totalDuration * (1 - (this.payablesTimelineProgress || 0));
      this.remainingTime = remainingDuration * 1000;
      this.pausedProgress = undefined;
      this.pauseAllAnimations();

      if (progressBar) {
        const computedStyle = window.getComputedStyle(progressBar);
        const currentWidth = parseFloat(computedStyle.width);
        const parentWidth = progressBar.parentElement?.offsetWidth || 1;
        const progressPercent = (currentWidth / parentWidth) * 100;
        progressBar.style.transition = 'none';
        progressBar.style.width = `${progressPercent}%`;
      }
    } else if (currentIndex === 2 && this.cashflowTimeline) {
      this.cashflowTimelineProgress = this.cashflowTimeline.progress();
      const totalDuration = this.cashflowTimeline.duration();
      const remainingDuration = totalDuration * (1 - (this.cashflowTimelineProgress || 0));
      this.remainingTime = remainingDuration * 1000;
      this.pausedProgress = undefined;
      this.pauseAllAnimations();

      if (progressBar) {
        const computedStyle = window.getComputedStyle(progressBar);
        const currentWidth = parseFloat(computedStyle.width);
        const parentWidth = progressBar.parentElement?.offsetWidth || 1;
        const progressPercent = (currentWidth / parentWidth) * 100;
        progressBar.style.transition = 'none';
        progressBar.style.width = `${progressPercent}%`;
      }
    } else {
      this.pauseAllAnimations();

      if (progressBar) {
        const computedStyle = window.getComputedStyle(progressBar);
        const currentWidth = parseFloat(computedStyle.width);
        const parentWidth = progressBar.parentElement?.offsetWidth || 1;
        const progressPercent = (currentWidth / parentWidth) * 100;
        this.pausedProgress = progressPercent;
        const interval = currentIndex === 0 ? this.TAB1_INTERVAL :
                        currentIndex === 1 ? this.TAB2_INTERVAL :
                        currentIndex === 2 ? this.TAB3_INTERVAL :
                        this.SWITCH_INTERVAL;
        this.remainingTime = interval * ((100 - progressPercent) / 100);
        progressBar.style.transition = 'none';
        progressBar.style.width = `${progressPercent}%`;
      }
    }
  }

  private resumeAnimation(): void {
    const currentIndex = this.currentTabIndex();

    // Check for timeline-based animations first (before early return)
    if (currentIndex === 0 && this.syncTimeline) {
      if (this.shouldRestartFromBeginning) {
        this.syncTimeline.seek(0);
        this.syncTimeline.play();
        this.shouldRestartFromBeginning = false;
        this.syncTimelineProgress = 0;
      } else if (this.syncTimelineProgress !== undefined) {
        this.syncTimeline.resume();
      } else {
        this.syncTimeline.resume();
        this.syncTimelineProgress = this.syncTimeline.progress();
      }

      const totalDuration = this.syncTimeline.duration();
      const currentProgress = this.syncTimelineProgress || 0;
      const remainingDuration = totalDuration * (1 - currentProgress);

      const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[currentIndex] as HTMLElement;
      if (progressBar) {
        progressBar.style.transition = 'none';
        progressBar.style.width = `${currentProgress * 100}%`;
        void progressBar.offsetWidth;

        requestAnimationFrame(() => {
          progressBar.style.transition = `width ${remainingDuration}s linear`;
          progressBar.style.width = '100%';
        });
      }

      this.remainingTime = remainingDuration * 1000;

      this.autoSwitchTimer = window.setTimeout(() => {
        this.pausedProgress = undefined;
        this.remainingTime = undefined;
        this.syncTimelineProgress = undefined;
        const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
        this.setActiveTab(nextIndex, false);
        this.startAutoSwitch();
      }, this.remainingTime);

      return;
    }

    if (currentIndex === 1 && this.payablesTimeline) {
      if (this.shouldRestartFromBeginning) {
        this.payablesTimeline.seek(0);
        this.payablesTimeline.play();
        this.shouldRestartFromBeginning = false;
        this.payablesTimelineProgress = 0;
      } else if (this.payablesTimelineProgress !== undefined) {
        this.payablesTimeline.resume();
      } else {
        this.payablesTimeline.resume();
        this.payablesTimelineProgress = this.payablesTimeline.progress();
      }

      const totalDuration = this.payablesTimeline.duration();
      const currentProgress = this.payablesTimelineProgress || 0;
      const remainingDuration = totalDuration * (1 - currentProgress);

      const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[currentIndex] as HTMLElement;
      if (progressBar) {
        progressBar.style.transition = 'none';
        progressBar.style.width = `${currentProgress * 100}%`;
        void progressBar.offsetWidth;

        requestAnimationFrame(() => {
          progressBar.style.transition = `width ${remainingDuration}s linear`;
          progressBar.style.width = '100%';
        });
      }

      this.remainingTime = remainingDuration * 1000;

      this.autoSwitchTimer = window.setTimeout(() => {
        this.pausedProgress = undefined;
        this.remainingTime = undefined;
        this.payablesTimelineProgress = undefined;
        const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
        this.setActiveTab(nextIndex, false);
        this.startAutoSwitch();
      }, this.remainingTime);

      return;
    }

    if (currentIndex === 2 && this.cashflowTimeline) {
      if (this.shouldRestartFromBeginning) {
        this.cashflowTimeline.restart();
        this.shouldRestartFromBeginning = false;
        this.cashflowTimelineProgress = 0;
      } else if (this.cashflowTimelineProgress !== undefined) {
        this.cashflowTimeline.resume();
      } else {
        this.cashflowTimeline.resume();
        this.cashflowTimelineProgress = this.cashflowTimeline.progress();
      }

      const totalDuration = this.cashflowTimeline.duration();
      const currentProgress = this.cashflowTimelineProgress || 0;
      const remainingDuration = totalDuration * (1 - currentProgress);

      const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[currentIndex] as HTMLElement;
      if (progressBar) {
        progressBar.style.transition = 'none';
        progressBar.style.width = `${currentProgress * 100}%`;
        void progressBar.offsetWidth;

        requestAnimationFrame(() => {
          progressBar.style.transition = `width ${remainingDuration}s linear`;
          progressBar.style.width = '100%';
        });
      }

      this.remainingTime = remainingDuration * 1000;

      this.autoSwitchTimer = window.setTimeout(() => {
        this.pausedProgress = undefined;
        this.remainingTime = undefined;
        this.cashflowTimelineProgress = undefined;
        const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
        this.setActiveTab(nextIndex, false);
        this.startAutoSwitch();
      }, this.remainingTime);

      return;
    }

    if (!this.remainingTime || this.remainingTime <= 0) {
      this.pausedProgress = undefined;
      this.startAutoSwitch();
      return;
    }

    const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[currentIndex] as HTMLElement;
    if (progressBar && this.pausedProgress !== undefined) {
      // Use the original progress bar-based logic
      progressBar.style.transition = 'none';
      progressBar.style.width = `${this.pausedProgress}%`;
      void progressBar.offsetWidth;

      requestAnimationFrame(() => {
        progressBar.style.transition = `width ${(this.remainingTime || 0) / 1000}s linear`;
        progressBar.style.width = '100%';
      });
    }

    this.autoSwitchTimer = window.setTimeout(() => {
      this.pausedProgress = undefined;
      this.remainingTime = undefined;
      const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
      this.setActiveTab(nextIndex, false);
      this.startAutoSwitch();
    }, this.remainingTime);
  }
  
  private stopAutoSwitch(): void {
    clearTimeout(this.autoSwitchTimer);
    this.remainingTime = undefined;
    this.pausedProgress = undefined;
    this.resetAllProgressBars();
  }
  
  private animateProgressBar(tabIndex: number, duration: number = this.SWITCH_INTERVAL): void {
    const progressBars = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar');
    const progressBar = progressBars[tabIndex] as HTMLElement;

    if (!progressBar) return;

    if (tabIndex === 0) {
    }

    progressBar.style.transition = 'none';
    progressBar.style.width = '0%';
    progressBar.style.opacity = '1';

    void progressBar.offsetWidth;

    requestAnimationFrame(() => {
      progressBar.style.transition = `width ${duration / 1000}s linear`;
      progressBar.style.width = '100%';
      if (tabIndex === 0) {
      }
    });
  }
  
  private updateProgressBars(activeIndex: number): void {
    const progressBars = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar');
    
    progressBars.forEach((bar: HTMLElement, index: number) => {
      if (index === activeIndex) {
        bar.style.opacity = '1';
        if (this.userInteracted()) {
          bar.style.transition = 'width 0.2s ease-out';
          bar.style.width = '100%';
        }
      } else {
        bar.style.transition = 'width 0.3s ease-out, opacity 0.3s ease-out';
        bar.style.width = '0%';
        bar.style.opacity = '0.2';
      }
    });
  }
  
  private resetAllProgressBars(): void {
    const progressBars = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar');
    progressBars.forEach((bar: HTMLElement) => {
      bar.style.transition = 'none';
      bar.style.width = '0%';
      bar.style.opacity = '0.9';
    });
  }
  
  private handleKeyboardNavigation(event: KeyboardEvent): void {
    let newIndex = this.currentTabIndex();
    let shouldPreventDefault = true;
    
    switch (event.key) {
      case 'ArrowRight':
        newIndex = (this.currentTabIndex() + 1) % this.tabs.length;
        break;
      case 'ArrowLeft':
        newIndex = (this.currentTabIndex() - 1 + this.tabs.length) % this.tabs.length;
        break;
      case 'Home':
        newIndex = 0;
        break;
      case 'End':
        newIndex = this.tabs.length - 1;
        break;
      case ' ':
      case 'Enter':
        if (event.target && (event.target as HTMLElement).classList.contains('erp-animation__play-pause')) {
          this.togglePlayPause();
        }
        return;
      default:
        shouldPreventDefault = false;
        return;
    }
    
    if (shouldPreventDefault) {
      event.preventDefault();
    }
    
    if (newIndex !== this.currentTabIndex()) {
      this.userInteracted.set(true);
      this.stopAutoSwitch();
      this.setActiveTab(newIndex, true);
    }
  }
  
  
  getCurrentTabAnnouncement(): string {
    return this.tabChangeAnnouncement();
  }
  
  getPlayStateAnnouncement(): string {
    return this.playStateAnnouncement();
  }
  
  private cleanup(): void {
    this.stopAutoSwitch();
    this.resetAllProgressBars();
  }
}
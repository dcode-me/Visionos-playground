# ERP Feature Animation Architecture

**Last Updated**: 2025-09-17
**Component Version**: 1.0.0
**Angular Version**: 19
**GSAP Version**: 3.x (CDN)

## Component Overview

The ERP Animation Component (`erp-animation.component.ts`) is a sophisticated Angular 19 standalone component that manages three distinct GSAP animations in a tabbed interface with advanced play/pause controls, poster frames, and synchronized progress tracking. All three tabs are now fully implemented with production-ready animations.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     ERP Animation Component                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Tab Navigation                        │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │    │
│  │  │    Tab 1     │  │    Tab 2     │  │    Tab 3     │  │    │
│  │  │ Sync & Rec. │  │  Payables    │  │  Cashflow    │  │    │
│  │  │  (6.25s)    │  │   (6.5s)     │  │   (6s)       │  │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  │    │
│  │  [████████████] [          ] [          ] Progress Bars │    │
│  │                                         [Play/Pause]    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Animation Display Area (400px min)          │    │
│  │  ┌─────────────────────────────────────────────────┐    │    │
│  │  │  Tab 1: BMO + Xero sync with ball animation     │    │    │
│  │  │  Tab 2: Invoice processing with card stacking   │    │    │
│  │  │  Tab 3: Revenue/Expense bars with chart         │    │    │
│  │  └─────────────────────────────────────────────────┘    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## Core Architecture Components

### 1. State Management

#### Signals (Reactive State)
```typescript
currentTabIndex = signal(0);        // Active tab index
isPlaying = signal(true);           // Global play/pause state
userInteracted = signal(false);     // Manual control indicator
```

#### Timing Constants
```typescript
private readonly SWITCH_INTERVAL = 5000;    // Default tab duration (5s)
private readonly TAB1_INTERVAL = 6250;      // Tab 1 duration (6.25s)
private readonly TAB2_INTERVAL = 6500;      // Tab 2 duration (6.5s)
private readonly TAB3_INTERVAL = 6000;      // Tab 3 duration (6s)
```

#### Timing Variables
```typescript
private autoSwitchTimer?: number;              // Auto-rotation timer
private pausedProgress?: number;               // Progress when paused
private remainingTime?: number;                // Time remaining in current animation
private shouldRestartFromBeginning?: boolean;  // Restart flag for poster frame
```

#### Timeline Management (All Implemented)
```typescript
// Tab 1 - Sync & Reconcile
private syncTimeline?: any;                   // GSAP timeline for sync animation
private syncTimelineProgress?: number;        // Stored progress (0-1)

// Tab 2 - Payables
private payablesTimeline?: any;               // GSAP timeline for payables
private payablesTimelineProgress?: number;    // Stored progress (0-1)

// Tab 3 - Cashflow
private cashflowTimeline?: any;               // GSAP timeline for cashflow
private cashflowTimelineProgress?: number;    // Stored progress (0-1)
```

### 2. Animation Lifecycle

```
┌──────────────┐
│  Component   │
│ Initialized  │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   ngAfterViewInit()
│   - Setup event listeners
│   - Initialize animations
│   - Start auto-switch
└──────┬───────┘
       │
       ▼
┌──────────────────────────────┐
│  Auto-Rotation Active         │
│  - 5s default interval         │
│  - 6.5s for Tab 2             │
│  - Progress bar animating     │
└──────┬───────────────────────┘
       │
       ├─────► User Clicks Tab ──────┐
       │                              │
       ├─────► User Pauses ──────┐   │
       │                         │   │
       ▼                         ▼   ▼
┌──────────────┐         ┌──────────────┐
│   Playing    │         │   Paused     │
│   State      │ ◄─────► │   State      │
└──────────────┘         └──────────────┘
```

### 3. Tab Switching Logic

#### Auto-Rotation Mode
```typescript
startAutoSwitch() {
  if (userInteracted || !isPlaying) return;

  // Set interval based on current tab
  remainingTime = currentIndex === 1 ? TAB2_INTERVAL : SWITCH_INTERVAL;

  // Animate progress bar
  animateProgressBar(currentIndex, remainingTime);

  // Schedule next switch
  autoSwitchTimer = setTimeout(() => {
    setActiveTab(nextIndex);
    startAutoSwitch(); // Recursive
  }, remainingTime);
}
```

#### Manual Tab Selection
```typescript
onTabClick(index) {
  userInteracted = true;      // Stop auto-rotation
  stopAutoSwitch();           // Clear timers
  setActiveTab(index);        // Switch tab
  progressBar.width = '100%'; // Visual indicator
}
```

### 4. Animation Control Flow

#### Play/Pause Architecture

```
User Action: Press Pause
         │
         ▼
┌─────────────────────┐
│   pauseAnimation()   │
├─────────────────────┤
│ 1. Clear timer      │
│ 2. Store timeline   │
│    progress         │
│ 3. Pause GSAP       │
│ 4. Calculate        │
│    remaining time   │
│ 5. Update UI        │
└─────────────────────┘

User Action: Press Play
         │
         ▼
┌─────────────────────┐
│  resumeAnimation()   │
├─────────────────────┤
│ 1. Check restart    │
│    flag             │
│ 2. Resume/restart   │
│    timeline         │
│ 3. Sync progress    │
│    bar              │
│ 4. Set timer for    │
│    next switch      │
└─────────────────────┘
```

### 5. Timeline Synchronization

#### Progress Tracking System
```typescript
// Timeline progress (0-1 scale)
payablesTimelineProgress = timeline.progress();

// Convert to time
totalDuration = timeline.duration();
remainingDuration = totalDuration * (1 - progress);

// Sync with progress bar
progressBar.width = `${progress * 100}%`;
progressBar.transition = `width ${remainingDuration}s linear`;
```

#### Poster Frame System
When switching tabs while paused, shows a "complete" state preview:

```typescript
if (!isPlaying()) {
  timeline.restart();
  timeline.progress(0.9);  // Show near-complete state
  timeline.pause();
  shouldRestartFromBeginning = true;
}
```

### 6. State Transitions

#### State Machine
```
                    ┌─────────────┐
                    │   INITIAL   │
                    │ (Tab 1, Playing)
                    └──────┬──────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│  AUTO-ROTATE  │  │ MANUAL CONTROL│  │    PAUSED     │
│               │  │               │  │               │
│ • Timer active│  │ • No timer    │  │ • Timer saved │
│ • Progress    │  │ • Progress    │  │ • Progress    │
│   animating   │  │   at 100%     │  │   frozen      │
│ • Animations  │  │ • Animations  │  │ • Animations  │
│   playing     │  │   playing     │  │   paused      │
└───────────────┘  └───────────────┘  └───────────────┘
        ▲                  ▲                  ▲
        └──────────────────┼──────────────────┘
                    Press Play/Resume
```

### 7. Component Properties Reference

#### Configuration Constants
```typescript
private readonly SWITCH_INTERVAL = 5000;      // Default tab duration
private readonly TAB1_INTERVAL = 6250;        // Tab 1 sync animation duration
private readonly TAB2_INTERVAL = 6500;        // Tab 2 payables animation duration
private readonly TAB3_INTERVAL = 6000;        // Tab 3 cashflow animation duration
```

#### ViewChild References
```typescript
@ViewChild('tablist') tablistRef!: ElementRef;
@ViewChildren('syncContainer') syncContainers!: QueryList<ElementRef>;
@ViewChildren('payablesContainer') payablesContainers!: QueryList<ElementRef>;
@ViewChildren('cashflowContainer') cashflowContainers!: QueryList<ElementRef>;
```

#### Tab Data Structure
```typescript
readonly tabs: TabData[] = [
  { id: 'sync-reconcile', title: 'Sync & Reconcile', description: '...' },
  { id: 'automate-payables', title: 'Automate Payables', description: '...' },
  { id: 'cashflow-insights', title: 'Cashflow Insights', description: '...' }
];
```

### 8. Key Methods Reference

#### Animation Control
- `initializeAnimations()` - Set up all GSAP timelines
- `playTabAnimation(index)` - Start/restart animation for specific tab
- `pauseAllAnimations()` - Pause all active timelines
- `switchTabAnimation(prev, current)` - Handle tab transition

#### State Management
- `setActiveTab(index, setFocus)` - Update active tab
- `togglePlayPause()` - Global play/pause control
- `onTabClick(index)` - Handle manual tab selection

#### Timer Management
- `startAutoSwitch()` - Begin auto-rotation
- `pauseAnimation()` - Pause with state preservation
- `resumeAnimation()` - Resume from saved state
- `stopAutoSwitch()` - Clear all timers

### 9. Accessibility Features

#### ARIA Support
```html
<nav role="tablist" aria-orientation="horizontal">
  <button role="tab"
          [attr.aria-selected]="currentTabIndex() === i"
          [attr.aria-controls]="'panel-' + tab.id">
</nav>

<div role="tabpanel"
     [attr.aria-labelledby]="'tab-' + tab.id">
```

#### Keyboard Navigation
```typescript
handleKeyboardNavigation(event: KeyboardEvent) {
  switch (event.key) {
    case 'ArrowRight': // Next tab
    case 'ArrowLeft':  // Previous tab
    case 'Home':       // First tab
    case 'End':        // Last tab
    case ' ':          // Play/pause
  }
}
```

#### Screen Reader Announcements
```typescript
tabChangeAnnouncement = signal('');     // Tab change notifications
playStateAnnouncement = signal('');     // Play/pause notifications
```

### 10. Performance Optimizations

#### GSAP Optimizations
- Hardware-accelerated transforms only
- Timeline caching and reuse
- **CRITICAL**: Use ViewChild/ViewChildren scoped queries with `gsap.utils.toArray()`
- Cleanup on destroy with `timeline.kill()`

#### Angular Optimizations
- OnPush change detection where possible
- Signals for reactive state
- Lazy initialization of animations
- Proper cleanup in `ngOnDestroy()`

### ⚠️ CRITICAL: Angular + GSAP DOM Selection Requirements

#### The Most Important Rule
**NEVER use global document queries for GSAP animations in Angular!**

This critical requirement was discovered after a 4-hour debugging session where Tab 3 (Cashflow) animation exhibited progressive flickering starting after loop 3-4. The root cause: using global document queries instead of ViewChild/ViewChildren scoped queries.

#### Why This Matters
Angular's change detection can re-render DOM elements during the component lifecycle. When GSAP holds references to elements obtained through global queries, it continues animating increasingly stale/detached DOM nodes, causing:
- Progressive flickering that worsens with each animation loop
- Memory leaks from detached DOM nodes
- Unpredictable animation behavior
- Performance degradation over time

#### ❌ WRONG - Global Document Queries (Causes Flickering)
```typescript
// NEVER DO THIS IN ANGULAR!
private initializeAnimation(): void {
  const container = document.querySelector('.animation-wrapper');
  const elements = gsap.utils.toArray('.animation-wrapper .element');
  // These references become stale after Angular re-renders!
}
```

#### ✅ CORRECT - ViewChild/ViewChildren Scoped Queries
```typescript
// Template
<div class="animation-wrapper" #animationContainer>

// Component
@ViewChildren('animationContainer') containers!: QueryList<ElementRef>;

private initializeAnimation(): void {
  const container = this.containers.first;
  if (!container) return;

  const containerEl = container.nativeElement;
  const elements = gsap.utils.toArray(containerEl.querySelectorAll('.element'));
  // These references are always fresh and managed by Angular!
}
```

#### Key Symptoms of Using Global Queries
1. Animation works fine for first 2-3 loops
2. Flickering/glitches start appearing after loop 3-4
3. Problem progressively worsens with each subsequent loop
4. Console shows no errors (making it hard to debug)
5. Other animations using ViewChild work perfectly

#### Prevention Checklist
- [ ] Always use `@ViewChild` or `@ViewChildren` for container references
- [ ] Use `containerEl.querySelectorAll()` for scoped element selection
- [ ] Never use `document.querySelector()` or `document.querySelectorAll()`
- [ ] Pass the container context to `gsap.utils.toArray()`
- [ ] Verify all animations use the same scoped pattern

### 11. Error Handling

#### Defensive Programming
```typescript
if (!isPlatformBrowser(this.platformId) || typeof gsap === 'undefined') return;
if (!container) return;
if (!progressBar) return;
```

#### Graceful Degradation
- Animations disabled if GSAP not loaded
- Server-side rendering safety with `isPlatformBrowser`
- Null checks for all DOM queries

### 12. Testing Considerations

#### Unit Testing Points
- Tab switching logic
- Timer management
- State transitions
- Progress calculations

#### Integration Testing
- GSAP timeline execution
- DOM manipulation
- Event handling
- Accessibility features

#### E2E Testing Scenarios
- Complete user journey
- Edge cases (rapid clicking, tab switching)
- Performance under load
- Cross-browser compatibility

## Best Practices

### 1. Animation Management
- Always start timelines paused
- Use consistent easing functions
- Add labels for timeline debugging
- Include hold states before exits

### 2. State Management
- Clear state on transitions
- Store progress for resume capability
- Use flags for special states (shouldRestart)
- Maintain single source of truth

### 3. Performance
- Minimize DOM queries
- Cache element references
- Use transform/opacity for animations
- Batch DOM updates

### 4. User Experience
- Respect user preferences (prefers-reduced-motion)
- Provide clear visual feedback
- Maintain 60fps target
- Ensure smooth transitions

## Future Enhancements

### Planned Features
1. Additional animation types for remaining tabs
2. Customizable timing per deployment
3. Analytics integration for interaction tracking
4. A/B testing support for animation variations

### Scalability Considerations
- Abstract common animation patterns
- Create animation factory/builder pattern
- Implement plugin system for new animations
- Consider state management library for complex scenarios

## Debugging Guide

### Common Issues

#### Animation Not Starting
```typescript
console.log('Timeline exists:', !!this.payablesTimeline);
console.log('Timeline paused:', this.payablesTimeline?.paused());
console.log('Timeline progress:', this.payablesTimeline?.progress());
```

#### Progress Bar Desync
```typescript
console.log('Timeline progress:', timelineProgress);
console.log('Progress bar width:', progressBar.style.width);
console.log('Remaining time:', remainingTime);
```

#### State Confusion
```typescript
console.log('Current tab:', this.currentTabIndex());
console.log('Is playing:', this.isPlaying());
console.log('User interacted:', this.userInteracted());
console.log('Should restart:', this.shouldRestartFromBeginning);
```

### GSAP DevTools Integration
```javascript
// Enable GSAP DevTools in development
GSDevTools.create({
  animation: this.payablesTimeline,
  container: "#gsap-devtools"
});
```

## Implementation Status

### ✅ Completed Features (Production Ready)

#### Tab 1: Sync & Reconcile
- **Duration**: 6.25 seconds
- **Animation**: BMO and Xero logo synchronization with ball merging animation
- **Key Features**:
  - Two balls rotating and merging
  - Checkmark reveal on completion
  - Smooth entry/exit transitions
  - Poster frame at 95% progress

#### Tab 2: Automate Payables
- **Duration**: 6.5 seconds
- **Animation**: Invoice processing with card stacking
- **Key Features**:
  - Sequential card appearance
  - Stacking animation with perspective
  - Status indicators and progress tracking
  - Poster frame at 90% progress

#### Tab 3: Cashflow Insights
- **Duration**: 6 seconds
- **Animation**: Revenue and expense bars with animated chart
- **Key Features**:
  - Revenue bars growing upward
  - Expense bars growing downward
  - Dynamic value updates
  - Poster frame at 80% progress

### 🔧 Technical Improvements Implemented

1. **Fixed Tab 1 Progress Bar Sync Issue**
   - Added TAB1_INTERVAL constant (6250ms)
   - Synchronized timeline duration with progress bar animation
   - Eliminated progress bar jumping on pause/resume

2. **Resolved Tab 3 Flickering Issue**
   - Implemented ViewChild/ViewChildren scoped queries
   - Removed global document queries
   - Ensured proper DOM element referencing

3. **Standardized Animation Patterns**
   - Consistent initialization methods across all tabs
   - Unified pause/resume logic
   - Standardized poster frame implementation

## Conclusion

The ERP Feature Animation Architecture provides a robust, scalable foundation for managing complex animations in a tabbed interface. With all three animations now fully implemented and production-ready, the component delivers a smooth, performant user experience with comprehensive play/pause controls, poster frames, and perfect progress synchronization. The combination of Angular 19's reactive state management with GSAP's powerful animation capabilities ensures optimal performance and maintainability.
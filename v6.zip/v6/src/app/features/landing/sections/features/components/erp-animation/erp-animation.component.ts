import { Component, AfterViewInit, OnDestroy, Inject, PLATFORM_ID, signal, ElementRef, ViewChild } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

declare const gsap: any;

interface TabData {
  id: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-erp-animation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './erp-animation.component.html',
  styleUrls: ['./erp-animation.component.scss']
})
export class ErpAnimationComponent implements AfterViewInit, OnDestroy {
  @ViewChild('tablist', { static: false }) tablistRef!: ElementRef;
  
  private readonly SWITCH_INTERVAL = 5000;
  private autoSwitchTimer?: number;
  private animationStartTime?: number;
  private pausedProgress?: number;
  private remainingTime?: number;
  
  currentTabIndex = signal(0);
  isPlaying = signal(true);
  userInteracted = signal(false);
  private tabChangeAnnouncement = signal('');
  private playStateAnnouncement = signal('');
  
  readonly tabs: TabData[] = [
    {
      id: 'sync-reconcile',
      title: 'Sync & Reconcile',
      description: 'Automatically sync and reconcile your financial data across all systems'
    },
    {
      id: 'automate-payables',
      title: 'Automate Payables',
      description: 'Streamline your payment processes with intelligent automation'
    },
    {
      id: 'cashflow-insights',
      title: 'Cashflow Insights',
      description: 'Real-time visibility into your cash position and financial health'
    }
  ];
  
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private elementRef: ElementRef
  ) {}

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initializeCarousel();
      this.setupEventListeners();
      setTimeout(() => {
        this.startAutoSwitch();
      }, 100);
    }
  }

  ngOnDestroy(): void {
    this.cleanup();
  }
  
  private initializeCarousel(): void {
    this.setActiveTab(0, false);
    this.resetAllProgressBars();
  }
  
  private setupEventListeners(): void {
    if (!this.tablistRef) return;
    
    const tablist = this.tablistRef.nativeElement;
    
    tablist.addEventListener('keydown', (event: KeyboardEvent) => {
      this.handleKeyboardNavigation(event);
    });
  }
  
  onTabClick(index: number): void {
    if (index === this.currentTabIndex()) return;
    
    if (this.isPlaying()) {
      this.userInteracted.set(true);
      this.stopAutoSwitch();
    } else {
      this.resetAllProgressBars();
      this.remainingTime = undefined;
      this.animationStartTime = undefined;
      this.pausedProgress = undefined;
    }
    
    this.setActiveTab(index, false);
    
    if (!this.isPlaying()) {
      const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[index] as HTMLElement;
      if (progressBar) {
        progressBar.style.transition = 'width 0.2s ease-out';
        progressBar.style.width = '100%';
      }
    }
  }
  
  togglePlayPause(): void {
    const playing = !this.isPlaying();
    this.isPlaying.set(playing);
    
    this.playStateAnnouncement.set(playing ? 
      'Animation resumed' : 
      'Animation paused');
    
    if (playing) {
      this.userInteracted.set(false);
      
      if (this.remainingTime && this.remainingTime > 0) {
        this.resumeAnimation();
      } else {
        this.startAutoSwitch();
      }
    } else {
      this.pauseAnimation();
    }
  }
  
  private setActiveTab(index: number, setFocus: boolean = false): void {
    const previousIndex = this.currentTabIndex();
    this.currentTabIndex.set(index);
    
    if (previousIndex !== index) {
      const tab = this.tabs[index];
      this.tabChangeAnnouncement.set(`Now showing ${tab.title}. ${tab.description}`);
    }
    
    this.updateProgressBars(index);
    
    if (setFocus) {
      const tabs = this.elementRef.nativeElement.querySelectorAll('.erp-animation__tab');
      if (tabs[index]) {
        (tabs[index] as HTMLElement).focus();
      }
    }
  }
  
  private startAutoSwitch(): void {
    if (this.userInteracted() || !this.isPlaying()) return;
    
    clearTimeout(this.autoSwitchTimer);
    
    this.animationStartTime = Date.now();
    this.remainingTime = this.SWITCH_INTERVAL;
    
    this.animateProgressBar(this.currentTabIndex(), this.remainingTime);
    
    this.autoSwitchTimer = window.setTimeout(() => {
      const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
      this.setActiveTab(nextIndex, false);
      this.startAutoSwitch();
    }, this.remainingTime);
  }
  
  private pauseAnimation(): void {
    clearTimeout(this.autoSwitchTimer);
    
    const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[this.currentTabIndex()] as HTMLElement;
    if (progressBar) {
      const computedStyle = window.getComputedStyle(progressBar);
      const currentWidth = parseFloat(computedStyle.width);
      const parentWidth = progressBar.parentElement?.offsetWidth || 1;
      const progressPercent = (currentWidth / parentWidth) * 100;
      
      this.pausedProgress = progressPercent;
      this.remainingTime = this.SWITCH_INTERVAL * ((100 - progressPercent) / 100);
      
      progressBar.style.transition = 'none';
      progressBar.style.width = `${progressPercent}%`;
    }
  }
  
  private resumeAnimation(): void {
    if (!this.remainingTime || this.remainingTime <= 0) {
      this.pausedProgress = undefined;
      this.startAutoSwitch();
      return;
    }
    
    const progressBar = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar')[this.currentTabIndex()] as HTMLElement;
    if (progressBar) {
      if (this.pausedProgress !== undefined) {
        progressBar.style.transition = 'none';
        progressBar.style.width = `${this.pausedProgress}%`;
        void progressBar.offsetWidth;
      }
      
      requestAnimationFrame(() => {
        progressBar.style.transition = `width ${(this.remainingTime || 0) / 1000}s linear`;
        progressBar.style.width = '100%';
      });
    }
    
    this.autoSwitchTimer = window.setTimeout(() => {
      this.pausedProgress = undefined;
      this.remainingTime = undefined;
      const nextIndex = (this.currentTabIndex() + 1) % this.tabs.length;
      this.setActiveTab(nextIndex, false);
      this.startAutoSwitch();
    }, this.remainingTime);
  }
  
  private stopAutoSwitch(): void {
    clearTimeout(this.autoSwitchTimer);
    this.animationStartTime = undefined;
    this.remainingTime = undefined;
    this.pausedProgress = undefined;
    this.resetAllProgressBars();
  }
  
  private animateProgressBar(tabIndex: number, duration: number = this.SWITCH_INTERVAL): void {
    const progressBars = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar');
    const progressBar = progressBars[tabIndex] as HTMLElement;
    
    if (!progressBar) return;
    
    progressBar.style.transition = 'none';
    progressBar.style.width = '0%';
    progressBar.style.opacity = '1';
    
    void progressBar.offsetWidth;
    
    requestAnimationFrame(() => {
      progressBar.style.transition = `width ${duration / 1000}s linear`;
      progressBar.style.width = '100%';
    });
  }
  
  private updateProgressBars(activeIndex: number): void {
    const progressBars = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar');
    
    progressBars.forEach((bar: HTMLElement, index: number) => {
      if (index === activeIndex) {
        bar.style.opacity = '1';
        if (this.userInteracted()) {
          bar.style.transition = 'width 0.2s ease-out';
          bar.style.width = '100%';
        }
      } else {
        bar.style.transition = 'width 0.3s ease-out, opacity 0.3s ease-out';
        bar.style.width = '0%';
        bar.style.opacity = '0.2';
      }
    });
  }
  
  private resetAllProgressBars(): void {
    const progressBars = this.elementRef.nativeElement.querySelectorAll('.erp-animation__progress-bar');
    progressBars.forEach((bar: HTMLElement) => {
      bar.style.transition = 'none';
      bar.style.width = '0%';
      bar.style.opacity = '0.9';
    });
  }
  
  private handleKeyboardNavigation(event: KeyboardEvent): void {
    let newIndex = this.currentTabIndex();
    let shouldPreventDefault = true;
    
    switch (event.key) {
      case 'ArrowRight':
        newIndex = (this.currentTabIndex() + 1) % this.tabs.length;
        break;
      case 'ArrowLeft':
        newIndex = (this.currentTabIndex() - 1 + this.tabs.length) % this.tabs.length;
        break;
      case 'Home':
        newIndex = 0;
        break;
      case 'End':
        newIndex = this.tabs.length - 1;
        break;
      case ' ':
      case 'Enter':
        if (event.target && (event.target as HTMLElement).classList.contains('erp-animation__play-pause')) {
          this.togglePlayPause();
        }
        return;
      default:
        shouldPreventDefault = false;
        return;
    }
    
    if (shouldPreventDefault) {
      event.preventDefault();
    }
    
    if (newIndex !== this.currentTabIndex()) {
      this.userInteracted.set(true);
      this.stopAutoSwitch();
      this.setActiveTab(newIndex, true);
    }
  }
  
  
  getCurrentTabAnnouncement(): string {
    return this.tabChangeAnnouncement();
  }
  
  getPlayStateAnnouncement(): string {
    return this.playStateAnnouncement();
  }
  
  private cleanup(): void {
    this.stopAutoSwitch();
    this.resetAllProgressBars();
  }
}
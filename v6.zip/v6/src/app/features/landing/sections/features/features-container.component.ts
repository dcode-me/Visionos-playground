import { Component, OnInit, OnDestroy, AfterViewInit, inject, computed, ViewChildren, QueryList, ElementRef, isDevMode } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureCardComponent, FeatureData } from './components/feature-card/feature-card.component';
import { GsapService } from '../../../../core/animations/gsap.service';
import { TranslationService } from '../../../../core/services/translation.service';

@Component({
  selector: 'app-features-container',
  standalone: true,
  imports: [CommonModule, FeatureCardComponent],
  templateUrl: './features-container.component.html',
  styleUrls: ['./features-container.component.scss']
})
export class FeaturesContainerComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChildren('featureCard', { read: ElementRef }) 
  featureCards!: QueryList<ElementRef>;
  
  private gsapService = inject(GsapService);
  private translationService = inject(TranslationService);
  private scrollTriggers: any[] = [];
  private stackingScrollTriggers: any[] = [];
  private fpsMonitorId: number | null = null;
  
  // Master toggle for testing/debugging
  private readonly ENABLE_STACKING = true;
  
  // Expose stacking state to template
  public isStackingEnabled = false;

  // Reactive computed signals for translations
  sectionHeadline = computed(() => this.translationService.get('features.headline'));

  features = computed<FeatureData[]>(() => [
    {
      id: 'erp',
      type: 'erp',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.erp.title'),
      description: this.translationService.get('features.erp.description'),
      backgroundColor: 'gray',
      additionalItems: {
        items: [
          { label: this.translationService.get('features.erp.featured.xero'), icon: 'assets/icons/xero.svg' },
          { label: this.translationService.get('features.erp.featured.bmoSync'), icon: 'assets/icons/bmo.svg' }
        ]
      }
    },
    {
      id: 'api',
      type: 'api',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.api.title'),
      description: this.translationService.get('features.api.description'),
      backgroundColor: 'white',
      additionalItems: {
        title: this.translationService.get('features.api.availableTitle'),
        items: [
          { label: this.translationService.get('features.api.types.accountReporting') },
          { label: this.translationService.get('features.api.types.payments') },
          { label: this.translationService.get('features.api.types.pushNotifications') }
        ]
      }
    },
    {
      id: 'accounts',
      type: 'accounts',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.accounts.title'),
      description: this.translationService.get('features.accounts.description'),
      backgroundColor: 'gray',
      additionalItems: {
        title: this.translationService.get('features.accounts.availableTitle'),
        items: [
          { label: this.translationService.get('features.accounts.types.deposit') },
          { label: this.translationService.get('features.accounts.types.termInvestment') },
          { label: this.translationService.get('features.accounts.types.usCertificateDeposit') }
        ]
      }
    },
    {
      id: 'partners',
      type: 'partners',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.partnerOffers.title'),
      description: this.translationService.get('features.partnerOffers.description'),
      backgroundColor: 'white'
    }
  ]);

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.initializeAnimations();
  }
  
  private async initializeAnimations(): Promise<void> {
    await this.gsapService.waitForGSAP();
    
    // Check if we should enable stacking
    this.isStackingEnabled = this.shouldEnableStacking();
    
    if (!this.isStackingEnabled) {
      this.initializeStandardAnimations();
      return;
    }
    
    this.initializeStackingAnimation();
  }
  
  private shouldEnableStacking(): boolean {
    // Master toggle
    if (!this.ENABLE_STACKING) return false;
    
    // Respect user preferences
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return false;
    
    // Disable on mobile
    const isMobile = window.innerWidth < 768;
    if (isMobile) return false;
    
    return true;
  }
  
  private startFPSMonitor(): void {
    // Only run in development mode
    if (!isDevMode()) return;
    
    let frames = 0;
    let lastTime = performance.now();
    let fpsHistory: number[] = [];
    
    const measureFPS = () => {
      frames++;
      const currentTime = performance.now();
      
      if (currentTime >= lastTime + 1000) {
        const fps = Math.round(frames * 1000 / (currentTime - lastTime));
        fpsHistory.push(fps);
        
        // Keep only last 10 measurements
        if (fpsHistory.length > 10) {
          fpsHistory.shift();
        }
        
        const avgFPS = Math.round(fpsHistory.reduce((a, b) => a + b, 0) / fpsHistory.length);
        const minFPS = Math.min(...fpsHistory);
        const maxFPS = Math.max(...fpsHistory);
        
        // Warn if FPS drops below 30 in dev mode
        if (fps < 30 && isDevMode()) {
          console.warn('⚠️ Performance warning: FPS below 30');
        }
        
        frames = 0;
        lastTime = currentTime;
      }
      
      this.fpsMonitorId = requestAnimationFrame(measureFPS);
    };
    
    this.fpsMonitorId = requestAnimationFrame(measureFPS);
  }
  
  private stopFPSMonitor(): void {
    if (this.fpsMonitorId !== null) {
      cancelAnimationFrame(this.fpsMonitorId);
      this.fpsMonitorId = null;
    }
  }
  
  private detectGPUCapability(): { capable: boolean; tier: number } {
    // Create a canvas to test WebGL capability
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl') as WebGLRenderingContext | null;
    
    if (!gl) {
      return { capable: false, tier: 0 };
    }
    
    try {
      // Get GPU renderer info if available
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL).toLowerCase();
        
        // Tier 3: High-end GPUs
        if (renderer.includes('nvidia') || renderer.includes('radeon rx') || renderer.includes('geforce')) {
          return { capable: true, tier: 3 };
        }
        
        // Tier 2: Mid-range GPUs
        if (renderer.includes('amd') || renderer.includes('radeon') || renderer.includes('mali')) {
          return { capable: true, tier: 2 };
        }
        
        // Tier 1: Integrated/Low-end GPUs
        if (renderer.includes('intel')) {
          return { capable: true, tier: 1 };
        }
      }
      
      // Default: Capable but unknown tier
      return { capable: true, tier: 1 };
    } catch (e) {
      // Error accessing GPU info, assume basic capability
      return { capable: true, tier: 1 };
    }
  }
  
  
  private initializeStackingAnimation(): void {
    // Detect GPU capability
    const gpuInfo = this.detectGPUCapability();
    
    // GPU detection results available for debugging if needed
    
    // Configure GSAP based on GPU tier
    if (gpuInfo.capable && gpuInfo.tier > 1) {
      // Enable force3D for mid to high-end GPUs
      this.gsapService.gsap.defaults({ force3D: true });
    }
    
    // Start FPS monitoring in development mode
    this.startFPSMonitor();
    
    // Animate headline
    this.gsapService.from('.features-container__headline', {
      y: 30,
      opacity: 0,
      duration: 1,
      ease: 'power2.out',
      scrollTrigger: {
        trigger: '.features-container__headline',
        start: 'top 80%',
        once: true
      }
    });
    
    // Ensure DOM is ready before initializing
    setTimeout(() => {
      const cards = this.gsapService.gsap.utils.toArray('.features-container__stacking-card') as HTMLElement[];
      
      if (cards.length === 0) {
        return;
      }
      
      // Configuration
      const stickDistance = 100; // Extra scroll distance before unpinning
      
      // Create reference point for last card to coordinate unpinning
      const lastCardST = this.gsapService.ScrollTrigger.create({
        trigger: cards[cards.length - 1],
        start: "top 20%"
      });
      
      // Set up each card with proper stacking
      cards.forEach((card: HTMLElement, index: number) => {
        // Z-index for proper layering (first card bottom, last card top)
        card.style.zIndex = String(index + 10);
        
        // Apply GPU optimization based on capability
        if (gpuInfo.capable) {
          card.style.willChange = 'transform';
          // Add performance optimization class for tier 2+ GPUs
          if (gpuInfo.tier >= 2) {
            card.classList.add('features-container__stacking-card--optimized');
          }
        }
        
        // Progressive scaling for depth effect
        const scale = 1 - (cards.length - index) * 0.025;
        
        // Create scale animation with GPU-aware configuration
        const animationConfig: any = {
          scale: scale,
          transformOrigin: '50% -160%',
          paused: true
        };
        
        // Add force3D for individual animations on capable GPUs
        if (gpuInfo.capable && gpuInfo.tier > 1) {
          animationConfig.force3D = true;
        }
        
        const scaleAnimation = this.gsapService.gsap.to(card, animationConfig);
        
        // Create ScrollTrigger for pinning and animation
        const trigger = this.gsapService.ScrollTrigger.create({
          trigger: card,
          start: "top 20%",
          end: () => (lastCardST as any).start + stickDistance,
          pin: true,
          pinSpacing: false,
          animation: scaleAnimation,
          toggleActions: "restart none none reverse",
          id: `card-${index}`
        });
        
        this.stackingScrollTriggers.push(trigger);
      });
      
      // Ensure ScrollTrigger calculations are up to date
      this.gsapService.ScrollTrigger.refresh();
    }, 100);
  }
  
  private initializeStandardAnimations(): void {
    // Standard animations without stacking (for mobile/reduced motion)
    this.gsapService.from('.features-container__headline', {
      y: 30,
      opacity: 0,
      duration: 1,
      ease: 'power2.out',
      scrollTrigger: {
        trigger: '.features-container__headline',
        start: 'top 80%',
        once: true
      }
    });
    
    const featureCards = this.gsapService.gsap.utils.toArray('.feature-card');
    featureCards.forEach((card: any, index: number) => {
      const scrollTrigger = this.gsapService.createScrollTrigger({
        trigger: card,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          this.gsapService.from(card, {
            y: 50,
            opacity: 0,
            duration: 0.8,
            delay: index * 0.1,
            ease: 'power2.out'
          });
        }
      });
      this.scrollTriggers.push(scrollTrigger);
      
      const additionalItems = card.querySelectorAll('.feature-card__additional-item');
      if (additionalItems.length > 0) {
        const itemTrigger = this.gsapService.createScrollTrigger({
          trigger: card.querySelector('.feature-card__additional'),
          start: 'top 80%',
          once: true,
          onEnter: () => {
            this.gsapService.from(additionalItems, {
              x: -20,
              opacity: 0,
              duration: 0.6,
              stagger: 0.1,
              ease: 'power2.out'
            });
          }
        });
        this.scrollTriggers.push(itemTrigger);
      }
    });
    
    const placeholders = this.gsapService.gsap.utils.toArray('.animation-placeholder');
    placeholders.forEach((placeholder: any) => {
      const placeholderTrigger = this.gsapService.createScrollTrigger({
        trigger: placeholder,
        start: 'top 75%',
        once: true,
        onEnter: () => {
          this.gsapService.from(placeholder, {
            scale: 0.95,
            opacity: 0,
            duration: 1,
            ease: 'power2.out'
          });
        }
      });
      this.scrollTriggers.push(placeholderTrigger);
    });
  }

  ngOnDestroy(): void {
    // Stop FPS monitoring
    this.stopFPSMonitor();
    
    // Clean up stacking triggers and reset will-change
    this.stackingScrollTriggers.forEach(trigger => {
      if (trigger) {
        const element = trigger.pin as HTMLElement;
        if (element) {
          element.style.willChange = 'auto';
          // Remove optimization class if it was added
          element.classList.remove('features-container__stacking-card--optimized');
        }
        trigger.kill();
      }
    });
    this.stackingScrollTriggers = [];
    
    // Reset GSAP defaults (only if GSAP is available)
    try {
      if (this.gsapService.gsap) {
        this.gsapService.gsap.defaults({ force3D: false });
      }
    } catch (e) {
      // GSAP might not be available during destroy
    }
    
    // Clean up standard triggers
    this.scrollTriggers.forEach(trigger => trigger?.kill());
    this.scrollTriggers = [];
  }
}
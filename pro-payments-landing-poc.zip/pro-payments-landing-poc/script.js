// Navigation logic for BMO PRO Payments Landing POC

let navigationData = {};
let isOverviewMode = false;
let isMobileView = false;

// Utility: Capitalize first letter
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Check if we're in mobile view
function checkMobileView() {
  isMobileView = window.innerWidth <= 768;
  return isMobileView;
}

// Load navigation data and setup
console.log('Script starting...');

fetch('current_navigation.json')
  .then(res => res.json())
  .then(data => {
    navigationData = data;
    console.log('Navigation data loaded:', navigationData);
    setupSidenav();
  })
  .catch(error => {
    console.error('Error loading navigation:', error);
    // Setup sidenav anyway with limited functionality
    setupSidenav();
  });

function setupSidenav() {
  console.log('Setting up sidenav...');
  
  const sidenav = document.querySelector('.sidenav');
  const primaryNav = sidenav.querySelector('.sidenav__primary');
  const primaryItems = sidenav.querySelectorAll('.sidenav__item');
  const secondaryPane = document.getElementById('sidenav-secondary');
  const mainContent = document.getElementById('main-content');
  
  if (!sidenav || !secondaryPane || primaryItems.length === 0) {
    console.error('Sidenav elements not found', { sidenav: !!sidenav, secondaryPane: !!secondaryPane, primaryItems: primaryItems.length });
    return;
  }

  console.log('Found elements:', { sidenav: !!sidenav, secondaryPane: !!secondaryPane, primaryItems: primaryItems.length });

  let hoverTimeout;

  // Helper: Get secondary menu for a primary
  function getSecondaryMenu(primary) {
    if (primary === 'Dashboard') return null;
    
    let menu = [];
    let navKey = primary;
    
    // Map primary menu labels to navigation data keys
    const keyMapping = {
      'Accounts': 'Account Information',
      'Pay & Receive': 'Pay & Receive',
      'FX & Securities': 'FX & Securities',
      'Administration': 'Administration'
    };
    
    navKey = keyMapping[primary] || primary;
    
    if (!navigationData[navKey]) {
      console.warn(`No navigation data found for: ${navKey}`);
      return null;
    }
    
    // Overview first
    menu.push({ label: primary + ' Overview', isOverview: true });
    
    // Then all first-level keys (sections only, no sub-items)
    Object.keys(navigationData[navKey]).forEach(section => {
      menu.push({ label: section });
    });
    
    return menu;
  }

  // Show secondary pane with normal shadow
  function showSecondary(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      return;
    }
    
    isOverviewMode = false;
    
    // Update content without hiding/showing if already visible
    secondaryPane.innerHTML = '';
    menu.forEach((item, idx) => {
      const div = document.createElement('div');
      div.className = 'sidenav__secondary-item';
      div.textContent = item.label;
      div.dataset.index = idx;
      if (item.isOverview) div.dataset.overview = 'true';
      secondaryPane.appendChild(div);
    });
    
    // Mobile behavior - show secondary below primary
    if (checkMobileView()) {
      secondaryPane.classList.add('sidenav__secondary--visible');
      return;
    }
    
    // Desktop behavior - only add classes if not already visible (smooth transition)
    if (!secondaryPane.classList.contains('sidenav__secondary--visible')) {
      secondaryPane.classList.add('sidenav__secondary--visible');
      primaryNav.classList.add('sidenav__primary--has-secondary');
    }
    
    // Remove overview mode styling
    secondaryPane.classList.remove('sidenav__secondary--overview', 'sidenav__secondary--persistent');
  }

  // Show secondary in overview mode (dissolved shadow, persistent layout)
  function showSecondaryOverview(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      return;
    }
    
    isOverviewMode = true;
    
    // Update content
    secondaryPane.innerHTML = '';
    menu.forEach((item, idx) => {
      const div = document.createElement('div');
      div.className = 'sidenav__secondary-item';
      div.textContent = item.label;
      div.dataset.index = idx;
      if (item.isOverview) {
        div.dataset.overview = 'true';
        div.classList.add('sidenav__secondary-item--active');
      }
      secondaryPane.appendChild(div);
    });
    
    // Show with overview styling - persistent layout
    secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
    primaryNav.classList.add('sidenav__primary--has-secondary');
  }

  // Show secondary in overview mode with smooth content transition (for hover)
  function showSecondaryOverviewWithTransition(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      return;
    }
    
    // Skip transitions on mobile
    if (checkMobileView()) {
      showSecondaryOverview(primary);
      return;
    }
    
    // Add fade-out effect to current content
    secondaryPane.classList.add('sidenav__secondary--transitioning');
    
    // After fade-out, update content and fade-in
    setTimeout(() => {
      // Update content
      secondaryPane.innerHTML = '';
      menu.forEach((item, idx) => {
        const div = document.createElement('div');
        div.className = 'sidenav__secondary-item';
        div.textContent = item.label;
        div.dataset.index = idx;
        if (item.isOverview) {
          div.dataset.overview = 'true';
          div.classList.add('sidenav__secondary-item--active');
        }
        secondaryPane.appendChild(div);
      });
      
      // Ensure persistent overview styling remains
      secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      
      // Remove transition class to fade-in new content
      secondaryPane.classList.remove('sidenav__secondary--transitioning');
    }, 150);
  }

  // Hide secondary pane
  function hideSecondary() {
    isOverviewMode = false;
    secondaryPane.classList.remove('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
    primaryNav.classList.remove('sidenav__primary--has-secondary');
    
    // Clear content after animation completes
    setTimeout(() => {
      if (!secondaryPane.classList.contains('sidenav__secondary--visible')) {
        secondaryPane.innerHTML = '';
      }
    }, 300);
  }

  // Hover logic for primary nav icons (desktop only)
  primaryItems.forEach(item => {
    const icon = item.querySelector('.sidenav__icon');
    
    if (!icon) {
      console.warn('No icon found for item:', item);
      return;
    }
    
    console.log('Adding hover listeners to:', item.dataset.menu);
    
    // Desktop hover logic
    icon.addEventListener('mouseenter', e => {
      if (checkMobileView()) return; // Skip hover on mobile
      
      clearTimeout(hoverTimeout);
      const menu = item.dataset.menu;
      
      if (menu === 'Dashboard') {
        // In overview mode, don't hide secondary when hovering Dashboard
        if (!isOverviewMode) {
          hideSecondary();
        }
      } else {
        // If we're in overview mode, smoothly transition to the new menu in overview mode
        if (isOverviewMode) {
          showSecondaryOverviewWithTransition(menu);
        } else {
          // Show/update secondary for other menus (normal mode during hover)
          showSecondary(menu);
        }
      }
    });
    
    icon.addEventListener('mouseleave', e => {
      if (checkMobileView()) return; // Skip hover on mobile
      
      hoverTimeout = setTimeout(() => {
        if (!secondaryPane.matches(':hover')) {
          if (isOverviewMode) {
            // Return to overview mode if we were in overview
            const activeItem = sidenav.querySelector('.sidenav__item--active');
            if (activeItem && activeItem.dataset.menu !== 'Dashboard') {
              showSecondaryOverview(activeItem.dataset.menu);
            }
          } else {
            hideSecondary();
          }
        }
      }, 150);
    });
  });

  // Keep secondary open on hover (desktop only)
  secondaryPane.addEventListener('mouseenter', () => {
    if (!checkMobileView()) {
      clearTimeout(hoverTimeout);
    }
  });
  
  secondaryPane.addEventListener('mouseleave', () => {
    if (checkMobileView()) return; // Skip hover on mobile
    
    hoverTimeout = setTimeout(() => {
      if (isOverviewMode) {
        // Return to overview mode
        const activeItem = sidenav.querySelector('.sidenav__item--active');
        if (activeItem && activeItem.dataset.menu !== 'Dashboard') {
          showSecondaryOverview(activeItem.dataset.menu);
        }
      } else {
        hideSecondary();
      }
    }, 150);
  });

  // Click logic for primary nav (works on all devices)
  primaryItems.forEach(item => {
    item.addEventListener('click', e => {
      primaryItems.forEach(i => i.classList.remove('sidenav__item--active'));
      item.classList.add('sidenav__item--active');
      const menu = item.dataset.menu;
      
      if (menu === 'Dashboard') {
        hideSecondary();
        loadContent('Dashboard', 'Dashboard');
      } else {
        // Show secondary in overview mode and load overview content
        showSecondaryOverview(menu);
        loadContent(menu, menu + ' Overview');
      }
    });
  });

  // Click logic for secondary nav
  secondaryPane.addEventListener('click', e => {
    const target = e.target.closest('.sidenav__secondary-item');
    if (!target) return;
    selectSecondary(target);
  });

  function selectSecondary(target) {
    secondaryPane.querySelectorAll('.sidenav__secondary-item').forEach(i => 
      i.classList.remove('sidenav__secondary-item--active')
    );
    target.classList.add('sidenav__secondary-item--active');
    const primary = sidenav.querySelector('.sidenav__item--active').dataset.menu;
    
    if (target.dataset.overview === 'true') {
      // Switch to overview mode - keep secondary visible and persistent
      showSecondaryOverview(primary);
      loadContent(primary, target.textContent);
    } else {
      // For non-overview items, stay in overview mode but keep secondary persistent
      isOverviewMode = true;
      secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      loadContent(primary, target.textContent);
    }
  }

  // Handle window resize
  window.addEventListener('resize', () => {
    const wasMobile = isMobileView;
    const nowMobile = checkMobileView();
    
    if (wasMobile !== nowMobile) {
      // Layout changed between mobile/desktop - no additional styling needed
      // The CSS Grid layout handles responsive behavior automatically
    }
  });

  // Initial load: Dashboard
  loadContent('Dashboard', 'Dashboard');
  
  console.log('Sidenav setup complete');
}

// Load content into main area with smooth transitions
function loadContent(primary, secondary) {
  const main = document.getElementById('main-content');
  if (!main) return;
  
  // Add loading class for fade out effect
  main.classList.add('main-content--loading');
  
  // After fade out completes, load page partial and fade in
  setTimeout(() => {
    loadPagePartial(primary, secondary);
  }, 200);
}

// Load page partial based on content type
function loadPagePartial(primary, secondary) {
  const main = document.getElementById('main-content');
  if (!main) return;
  
  // Map content to page partials
  let pageFile = null;
  
  if (primary === 'Dashboard') {
    // For dashboard, show simple content for now
    main.innerHTML = `
      <div class="page-content">
        <div class="page-header">
          <h1 class="page-title">Dashboard</h1>
          <p class="page-description">Welcome to BMO PRO Payments. Your business banking dashboard.</p>
        </div>
      </div>
    `;
    main.classList.remove('main-content--loading');
    return;
  }
  
  // Determine which page partial to load
  if (primary === 'Pay & Receive') {
    if (secondary === 'Pay & Receive Overview') {
      pageFile = 'partials/pages/payments-overview.html';
    } else if (secondary === 'Account Transfer' && secondary.includes('Interac')) {
      pageFile = 'partials/pages/interac.html';
    } else if (secondary === 'Wire Payment') {
      pageFile = 'partials/pages/wire-transfers.html';
    }
  }
  
  // Map specific secondary items to their page partials
  const pageMapping = {
    'Account Transfer': 'partials/pages/interac.html',  // Assuming Interac is main transfer method
    'Wire Payment': 'partials/pages/wire-transfers.html'
  };
  
  if (!pageFile && pageMapping[secondary]) {
    pageFile = pageMapping[secondary];
  }
  
  if (pageFile) {
    // Load the page partial
    fetch(pageFile)
      .then(response => response.text())
      .then(html => {
        main.innerHTML = html;
        main.classList.remove('main-content--loading');
        
        // Add data labels for mobile table responsiveness
        addMobileTableLabels();
      })
      .catch(error => {
        console.error('Error loading page partial:', error);
        // Fallback to simple content
        main.innerHTML = `
          <div class="page-content">
            <div class="page-header">
              <h1 class="page-title">${primary}</h1>
              <h2 class="page-subtitle">${secondary}</h2>
              <p class="page-description">This is the ${secondary} page content.</p>
            </div>
          </div>
        `;
        main.classList.remove('main-content--loading');
      });
  } else {
    // Fallback for unmapped content
    main.innerHTML = `
      <div class="page-content">
        <div class="page-header">
          <h1 class="page-title">${primary}</h1>
          <h2 class="page-subtitle">${secondary}</h2>
          <p class="page-description">This is the ${secondary} page content.</p>
        </div>
      </div>
    `;
    main.classList.remove('main-content--loading');
  }
}

// Add data labels to table cells for mobile responsiveness
function addMobileTableLabels() {
  const tables = document.querySelectorAll('.transfers-table, .wire-table');
  
  tables.forEach(table => {
    const headers = table.querySelectorAll('.table-header .table-cell');
    const rows = table.querySelectorAll('.table-row');
    
    const headerTexts = Array.from(headers).map(header => header.textContent.trim());
    
    rows.forEach(row => {
      const cells = row.querySelectorAll('.table-cell');
      cells.forEach((cell, index) => {
        if (headerTexts[index]) {
          cell.setAttribute('data-label', headerTexts[index]);
        }
      });
    });
  });
}

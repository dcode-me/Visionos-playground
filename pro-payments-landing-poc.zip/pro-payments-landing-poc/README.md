# Pro Payments Landing POC

### **Project Plan: BMO PRO Payments Redesign**

**Project Vision:** Our goal is to prototype a modern, modular, and user-centric Payments landing page for the BMO PRO business banking platform. The landing pages will have predominantly three sections: a communication section (things we want the users to know about), an actions section (things users can do), and an information section (things users need to know about, which empowers them to manage their business and feel in control).

**Core Principles:**
*   **Modular by Design:** Components should be self-contained (simulating MFEs).
*   **User-Centric:** The layout prioritizes common user tasks and easy access to support.
*   **Modern & Clean:** Adherence to Material Design 3 layout principles for a strict content-driven layout, which is adaptive, consistent and intuitive UI.
*   **Responsive First:** The experience must be seamless across desktop, tablet, and mobile. Individual components have to be created as MFE partials so they can be responsive to the container size, adhering to a content-driven layout.

---

### **Phase 1: Foundation & Scaffolding (Milestone 1)**

This phase is about setting up the skeleton of the application. We're not building the final components yet, just the "bones" they will live inside.

*   **Task 1.1: Project & Repository Setup**
    *   Initialize a new Git repository.
    *   Create a standard `README.md` with the project vision.
    *   Create a `.gitignore` file (for `node_modules`, etc., if we add tooling).
    *   Set up the GitHub Project board (e.g., Kanban with To Do, In Progress, Done).

*   **Task 1.2: Reusable Header MFE Component**
    *   Research and scrape header content, style, and layout from the BMO PRO demo site.
    *   Create a self-contained, reusable Micro Frontend (MFE) header component that can be used across multiple projects.
    *   Structure the header as a standalone component with:
        *   `header/` directory containing:
            *   `header.html` - Semantic HTML structure
            *   `header.css` - Self-contained styles (no external dependencies)
            *   `header.js` - Any interactive functionality
    *   Ensure the header is fully responsive (mobile-first approach).
    *   Include BMO branding elements, navigation, and user account controls.
    *   Make it framework-agnostic so it can be integrated into various projects.
    *   Test the component in isolation to ensure it works independently.
    *   **Add Menu Handler Hooks:**  
        *   Implement event hooks in `header.js` so that when a user selects a menu item, the header dispatches a custom event (e.g., `header-menu-select`) with the selected menu item's data.
        *   The parent page or host application should listen for this event and respond accordingly (e.g., load another MFE or update the main content).
        *   **Generic Data Transfer:**  
            *   Use the [CustomEvent](https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent) API for communication between the header MFE and the host/page.
            *   The event detail should include relevant data (e.g., `{ menuKey: 'payments', label: 'Payments' }`).
            *   This approach keeps the header framework-agnostic and decoupled from the host application logic.
        *   **Example Usage:**
            ```js
            // In header.js (inside the header MFE)
            const event = new CustomEvent('header-menu-select', {
              detail: { menuKey: 'payments', label: 'Payments' }
            });
            window.dispatchEvent(event);

            // In the host page (e.g., app.js)
            window.addEventListener('header-menu-select', (e) => {
              // e.detail contains the menu selection data
              // Load the corresponding MFE or update the page
            });
            ```

*   **Task 1.3: Core HTML Structure (`index.html`)**
    *   Create the main `index.html` file.
    *   Define the primary page landmarks using semantic HTML: `<header>`, `<main>`, `<footer>`.
    *   Inside `<main>`, scaffold the three columns:
        *   `<nav class="left-nav">` for the payment navigation.
        *   `<section class="main-content">` for the dynamic content.
        *   `<aside class="right-support">` for the support tools.

*   **Task 1.4: CSS Foundation & Layout**
    *   Create a `css/main.css` file.
    *   **Layout Decision:** Use **CSS Grid** for the main 3-column layout. It's perfect for this type of page-level structure.
    *   Define the grid in `main.css`:
        ```css
        main {
          display: grid;
          grid-template-columns: 240px 1fr 280px; /* Example values */
          gap: 24px;
        }
        ```
    *   Set up CSS Custom Properties (variables) for the theme (colors, fonts, spacing) to align with Material 3 and BMO branding.
        ```css
        :root {
          --bmo-blue: #0079c1;
          --primary-text: #1a1a1a;
          --surface-container: #f3f4f6;
          --spacing-md: 16px;
        }
        ```

*   **Task 1.5: Stub Data Structure (`js/data.js`)**
    *   Create a `js/data.js` file to hold all our mock content. This decouples content from the presentation.
    *   Define a global object, e.g., `APP_DATA`.
    *   Structure the data by payment type.
        ```javascript
        const APP_DATA = {
          payments: {
            overview: { title: "Payments Overview", ... },
            ach: { title: "ACH Payments", description: "Automated Clearing House for direct deposits and payments.", ... },
            eft: { title: "EFT Payments", description: "Electronic Funds Transfer for Canadian transactions.", ... },
            wires: { title: "Wire Transfers", description: "Send domestic and international wire payments.", ... }
          },
          support: { ... }
        };
        ```

---

### **Phase 2: Component Development (Milestone 2)**

Now we build the reusable "partials" or "blocks" for each column. Each task here represents a distinct UI component.

*   **Task 2.1: Left Column: Navigation Component**
    *   Create a partial `_nav.html` (conceptually).
    *   Build the static HTML for the navigation list.
    *   Style the list items, including hover states and a distinct `.is-active` class for the selected item.
    *   Use icons (e.g., from Material Symbols) for each payment type.

*   **Task 2.2: Right Column: Support Tools Components**
    *   Create a partial `_support.html`.
    *   **Component: Help/FAQ:** Design a collapsible accordion section. A user can click a question to reveal the answer.
    *   **Component: Chat Widget:** A simple, fixed-position stub that looks like a "Chat with an Expert" button.
    *   **Component: Quick Links:** A simple list of links (e.g., "View fee schedule," "Contact support").

*   **Task 2.3: Center Column: Core Content Components**
    *   **Component: Page Header:** A simple component with `<h1>` for the title and `<p>` for the description, populated from `data.js`.
    *   **Component: Quick Actions:** A set of prominent buttons for primary tasks (e.g., "Create New Payment," "View History," "Manage Templates"). Use **Flexbox** to lay these out.
    *   **Component: Data Table/List:** A styled table for "Recent Activity." Include columns for Date, Recipient, Amount, and Status.
    *   **Component: Info Cards:** Versatile cards for alerts, summaries, or stats (e.g., "2 payments require approval").

---

### **Phase 3: Integration & Interactivity (Milestone 3)**

This is where we bring the static components to life with JavaScript.

*   **Task 3.1: Create `app.js` for Core Logic**
    *   Link `js/app.js` to `index.html`.
    *   Write an `init()` function that runs on page load.

*   **Task 3.2: Dynamic Navigation Loading**
    *   On `init()`, write a function to read the keys from `APP_DATA.payments` and dynamically generate the navigation items in the left column. This makes adding new payment types easy.

*   **Task 3.3: Content Switching Logic**
    *   Add event listeners to the navigation links.
    *   When a link is clicked:
        1.  Prevent the default link behavior.
        2.  Get the target payment type (e.g., from a `data-payment="ach"` attribute).
        3.  Remove `.is-active` from the current nav item and add it to the clicked one.
        4.  Call a `renderContent(paymentType)` function.
        5.  This function will fetch the data from `APP_DATA.payments[paymentType]`, build the HTML for the center column using the components from Phase 2, and inject it into the `<section class="main-content">`.

*   **Task 3.4: UI Interactivity**
    *   Implement the JavaScript for the FAQ accordion (toggling a class to show/hide answers).
    *   If any content components have tabs (e.g., a table with "Pending" and "Completed" views), implement the JS to toggle tab content visibility.

---

### **Phase 4: Refinement & Responsive Design (Milestone 4)**

The final polish to make it a high-quality prototype.

*   **Task 4.1: Responsive Breakpoints**
    *   **Tablet View (`~<1024px`):** The 3-column layout might become too crowded.
        *   **Decision:** Collapse the right support column (`right-support`) to be stacked underneath the `main-content`, or hide it behind a "Support" button. The left navigation could shrink to an icon-only rail.
    *   **Mobile View (`~<768px`):** The layout must become single-column.
        *   **Decision:** The left navigation (`left-nav`) collapses into a "hamburger" menu. The main content (`main-content`) takes the full width. The support column (`right-support`) is either at the bottom of the page or accessible via the hamburger menu.

*   **Task 4.2: UI Polish**
    *   Add subtle CSS transitions for hover effects and content fading in/out to make the experience feel smoother.
    *   Ensure consistent spacing and alignment across all components.

*   **Task 4.3: Accessibility (A11y) Review**
    *   Check for semantic HTML usage.
    *   Add `aria` attributes where content is dynamic (e.g., `aria-live` for the main content area).
    *   Ensure sufficient color contrast.

*   **Task 4.4: Future Enhancements Ideation (for the hackathon presentation)**
    *   **Search:** A universal search bar in the header to find transactions or payment types.
    *   **Dashboard View:** A personalized "Overview" page with summary widgets from each payment type.
    *   **Real MFE Integration:** Discuss how this prototype's partials could be implemented as true Micro Frontends, each with its own repo and deployment pipeline.
    *   **Personalization:** Allow users to reorder or hide payment types in their navigation.

---

### **Next Steps: From Plan to GitHub**

1.  **Create Milestones in GitHub:** Create four milestones named:
    *   `M1: Foundation & Scaffolding`
    *   `M2: Component Development`
    *   `M3: Integration & Interactivity`
    *   `M4: Refinement & Responsive Design`

2.  **Create Issues from this Plan:** For each "Task" listed above (e.g., "Task 1.1," "Task 2.3"), create a new GitHub Issue.
    *   **Title:** Use the task name (e.g., `[M1] Implement 3-Column Layout with CSS Grid`).
    *   **Description:** Copy the details from the plan into the issue description.
    *   **Labels:** Use labels like `enhancement`, `css`, `javascript`, `html`, `planning`.
    *   **Assign to Milestone:** Assign each issue to its corresponding milestone.

Now we have a clear, actionable backlog. We can start by picking up the first issue from **Milestone 1** and creating a feature branch for it.

What do you think of this plan? We can adjust any part of it before creating the issues.
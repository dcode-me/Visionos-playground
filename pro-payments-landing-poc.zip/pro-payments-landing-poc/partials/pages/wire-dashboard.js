// Wire Payments Dashboard JavaScript

class WireDashboard {
  constructor() {
    this.layoutManager = document.querySelector('.layout-manager');
    this.dashboardLayout = document.querySelector('.dashboard-layout');
    this.sidebar = document.querySelector('.dashboard-sidebar');
    this.mainContent = document.querySelector('.dashboard-main');
    this.table = document.querySelector('.wire-transactions-table');
    this.importModal = document.querySelector('.import-modal');
    
    this.state = {
      secondaryNavVisible: true,
      helpMinimized: false,
      importModalOpen: false,
      utilityPanelOpen: false,
      utilityPanelType: null, // 'import', 'wire-details', or null
      utilityPanelData: null, // wire data when showing details
      rightPanelWidth: 320
    };
    
    this.init();
  }
  
  init() {
    this.initializeState();
    this.bindEvents();
    this.updateLayout();
    this.calculateTableColumns();
  }
  
  initializeState() {
    if (this.layoutManager) {
      this.state = {
        secondaryNavVisible: this.layoutManager.dataset.secondaryNavVisible === 'true',
        helpMinimized: this.layoutManager.dataset.helpMinimized === 'true',
        importModalOpen: this.layoutManager.dataset.importModalOpen === 'true',
        utilityPanelOpen: this.layoutManager.dataset.utilityPanelOpen === 'true',
        utilityPanelType: this.layoutManager.dataset.utilityPanelType || null,
        utilityPanelData: null, // Not persisted in DOM
        rightPanelWidth: parseInt(this.layoutManager.dataset.rightPanelWidth) || 320
      };
    }
  }
  
  bindEvents() {
    // Quick Action Buttons
    this.bindQuickActions();
    
    // Help Panel Minimize
    this.bindHelpPanelToggle();
    
    // Import Modal
    this.bindImportModal();
    
    // Table Row Clicks
    this.bindTableRowClicks();
    
    // Resize Handle
    this.bindResizeHandle();
    
    // Window Resize
    window.addEventListener('resize', () => {
      this.calculateTableColumns();
      this.updateLayout();
    });
    
    // Secondary Navigation Toggle Integration
    this.bindSecondaryToggle();
  }
  
  bindQuickActions() {
    const quickActions = document.querySelectorAll('.action-btn');
    quickActions.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const action = e.currentTarget.dataset.action;
        this.handleQuickAction(action);
      });
    });
  }
  
  handleQuickAction(action) {
    switch (action) {
      case 'create-wire':
        console.log('Create new wire payment');
        // Navigate to create wire form
        break;
      case 'import-file':
        this.openUtilityPanel('import');
        break;
      case 'generate-reports':
        console.log('Generate wire reports');
        // Navigate to reports page
        break;
    }
  }
  
  bindHelpPanelToggle() {
    const minimizeBtn = document.getElementById('help-minimize-btn');
    console.log('Looking for help-minimize-btn:', minimizeBtn);
    
    if (minimizeBtn) {
      console.log('Help minimize button found, adding click listener');
      minimizeBtn.addEventListener('click', (e) => {
        console.log('Help minimize button clicked!');
        this.toggleHelpPanel();
      });
    } else {
      console.warn('Help minimize button not found!');
    }
  }
  
  toggleHelpPanel() {
    this.state.helpMinimized = !this.state.helpMinimized;
    
    // Update button state
    const minimizeBtn = document.getElementById('help-minimize-btn');
    const minimizeIcon = minimizeBtn?.querySelector('.material-symbols-outlined');
    
    if (minimizeBtn && minimizeIcon) {
      if (this.state.helpMinimized) {
        minimizeIcon.textContent = 'add';
        minimizeBtn.title = 'Expand';
      } else {
        minimizeIcon.textContent = 'remove';
        minimizeBtn.title = 'Minimize';
      }
    }
    
    this.updateLayout();
    this.calculateTableColumns();
  }
  
  bindImportModal() {
    const closeBtn = document.getElementById('import-modal-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        this.closeImportModal();
      });
    }
    
    // Modal tabs
    const modalTabs = document.querySelectorAll('.modal-tab');
    modalTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        this.switchModalTab(e.currentTarget.dataset.tab);
      });
    });
    
    // File upload
    const fileInput = document.getElementById('file-input');
    const uploadPrompt = document.querySelector('.file-upload-prompt');
    
    if (uploadPrompt && fileInput) {
      uploadPrompt.addEventListener('click', () => {
        fileInput.click();
      });
      
      fileInput.addEventListener('change', (e) => {
        this.handleFileUpload(e.target.files[0]);
      });
    }
  }
  
  bindTableRowClicks() {
    // Get all table rows except header
    const tableRows = this.table?.querySelectorAll('.table-row:not(.table-row--header)');
    
    if (!tableRows) return;
    
    tableRows.forEach(row => {
      row.addEventListener('click', (e) => {
        // Don't trigger if clicking on action buttons
        if (e.target.closest('.table-action-btn')) return;
        
        this.selectWireRow(row);
      });
    });
  }
  
  selectWireRow(selectedRow) {
    // Remove active class from all rows
    const allRows = this.table.querySelectorAll('.table-row:not(.table-row--header)');
    allRows.forEach(row => row.classList.remove('table-row--active'));
    
    // Add active class to selected row
    selectedRow.classList.add('table-row--active');
    
    // Get wire data from the row
    const wireData = this.extractWireDataFromRow(selectedRow);
    
    // Open utility panel with wire details
    this.openUtilityPanel('wire-details', wireData);
  }
  
  extractWireDataFromRow(row) {
    const cells = row.querySelectorAll('.table-cell');
    
    return {
      id: cells[0]?.textContent.trim() || '',
      beneficiary: cells[1]?.textContent.trim() || '',
      amount: cells[2]?.textContent.trim() || '',
      status: cells[3]?.querySelector('.status-badge')?.textContent.trim() || '',
      date: cells[4]?.textContent.trim() || '',
      template: cells[5]?.textContent.trim() || '',
      currency: cells[6]?.textContent.trim() || '',
      // Add more mock data for details
      beneficiaryBank: 'Royal Bank of Canada',
      accountNumber: '****-****-****-2847',
      routingNumber: '003-12345',
      wireType: 'Outgoing Wire',
      purpose: 'Business Payment',
      fees: '$15.00',
      exchangeRate: '1.00',
      instructions: 'Payment for services rendered'
    };
  }
  
  openImportModal() {
    this.state.importModalOpen = true;
    this.updateLayout();
    this.calculateTableColumns();
    
    if (this.importModal) {
      this.importModal.classList.add('import-modal--open');
    }
  }
  
  closeImportModal() {
    this.state.importModalOpen = false;
    this.updateLayout();
    this.calculateTableColumns();
    
    if (this.importModal) {
      this.importModal.classList.remove('import-modal--open');
    }
  }
  
  switchModalTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.modal-tab').forEach(tab => {
      tab.classList.remove('modal-tab--active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('modal-tab--active');
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.remove('tab-content--active');
    });
    document.querySelector(`[data-tab="${tabName}"].tab-content`).classList.add('tab-content--active');
  }
  
  handleFileUpload(file) {
    if (file) {
      console.log('File uploaded:', file.name);
      // Handle file validation and processing
      this.validateFile(file);
    }
  }
  
  validateFile(file) {
    // Simulate file validation
    setTimeout(() => {
      this.updateImportSummary({
        uploadDate: new Date().toLocaleString(),
        recordsSubmitted: Math.floor(Math.random() * 50) + 10,
        validRecords: Math.floor(Math.random() * 40) + 5
      });
    }, 1000);
  }
  
  updateImportSummary(data) {
    const summaryStats = document.querySelectorAll('.summary-stat .stat-value');
    if (summaryStats.length >= 3) {
      summaryStats[0].textContent = data.uploadDate;
      summaryStats[1].textContent = data.recordsSubmitted;
      summaryStats[2].textContent = data.validRecords;
    }
  }
  
  // Utility Panel Methods (replaces right panel content instead of modal)
  openUtilityPanel(type, data = null) {
    // Hide secondary nav if it's visible to make more room
    if (this.state.secondaryNavVisible) {
      this.hideSecondaryNav();
    }
    
    this.state.utilityPanelOpen = true;
    this.state.utilityPanelType = type;
    this.state.utilityPanelData = data; // Store wire data
    this.state.helpMinimized = false; // Ensure right panel is expanded for utility
    
    this.updateLayout();
    this.calculateTableColumns();
    this.replaceRightPanelContent(type, data);
    
    console.log(`Utility panel opened: ${type} - layout: main=1fr, utility=1fr, hiding template/investigation sections`);
  }
  
  closeUtilityPanel() {
    this.state.utilityPanelOpen = false;
    this.state.utilityPanelType = null;
    this.state.utilityPanelData = null;
    
    // Clear active row highlighting
    const allRows = this.table?.querySelectorAll('.table-row:not(.table-row--header)');
    allRows?.forEach(row => row.classList.remove('table-row--active'));
    
    this.updateLayout();
    this.calculateTableColumns();
    this.restoreRightPanelContent();
    
    console.log('Utility panel closed');
  }
  
  hideSecondaryNav() {
    const secondaryPane = document.querySelector('.sidenav__secondary');
    const primaryNav = document.querySelector('.sidenav__primary');
    const toggleBtn = document.getElementById('secondary-toggle');
    
    if (!secondaryPane) return;
    
    // Only hide if it's currently visible
    if (secondaryPane.classList.contains('sidenav__secondary--visible') && 
        !secondaryPane.classList.contains('sidenav__secondary--hidden')) {
      
      // Apply the same logic as toggleSecondary function
      // Set global variable (it's defined in script.js)
      if (typeof isSecondaryHidden !== 'undefined') {
        isSecondaryHidden = true;
      }
      
      // Hide the secondary pane
      secondaryPane.classList.add('sidenav__secondary--hidden');
      secondaryPane.classList.remove('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      
      if (primaryNav) {
        primaryNav.classList.remove('sidenav__primary--has-secondary');
      }
      
      // Update toggle button
      if (toggleBtn) {
        toggleBtn.style.display = 'flex';
        toggleBtn.classList.add('secondary-toggle--hidden');
        toggleBtn.title = 'Show secondary navigation';
      }
      
      // Dispatch event for wire dashboard and other listeners
      document.dispatchEvent(new CustomEvent('secondaryNavToggled', {
        detail: { 
          visible: false,
          hidden: true 
        }
      }));
      
      console.log('Secondary nav hidden by utility panel');
    }
  }
  
  replaceRightPanelContent(type, data = null) {
    const rightPanel = document.getElementById('right-panel');
    if (!rightPanel) return;
    
    switch (type) {
      case 'import':
        rightPanel.innerHTML = this.getImportUtilityHTML();
        this.bindUtilityPanelEvents();
        break;
      case 'wire-details':
        rightPanel.innerHTML = this.getWireDetailsHTML(data);
        this.bindWireDetailsEvents();
        break;
      default:
        console.warn(`Unknown utility panel type: ${type}`);
    }
  }
  
  restoreRightPanelContent() {
    const rightPanel = document.getElementById('right-panel');
    if (!rightPanel) return;
    
    // Restore original help panel content
    rightPanel.innerHTML = this.getHelpPanelHTML();
    this.bindHelpPanelToggle(); // Re-bind help panel events
  }
  
  getImportUtilityHTML() {
    return `
      <div class="utility-panel import-utility" id="import-utility">
        <div class="utility-header">
          <div class="utility-tabs">
            <button class="utility-tab utility-tab--active" data-tab="wire-payments">Wire Payments</button>
            <button class="utility-tab" data-tab="bank-to-bank">Bank to Bank Wire</button>
            <button class="utility-tab" data-tab="templates">Payments from templates</button>
          </div>
          <button class="utility-close-btn" id="utility-close-btn">
            <span class="material-symbols-outlined">close</span>
          </button>
        </div>
        
        <div class="utility-body">
          <div class="utility-content utility-content--active" data-tab="wire-payments">
            <div class="import-section">
              <h3>Import Wire Payment File</h3>
              <div class="import-warning">
                <span class="material-symbols-outlined">warning</span>
                <span>A maximum of 100 wires can be imported per file.</span>
              </div>
              
              <div class="import-form">
                <div class="form-group">
                  <label for="utility-import-map">Select Import Map Name</label>
                  <select id="utility-import-map" class="form-select">
                    <option>Select Import Map</option>
                    <option>Standard Wire Map</option>
                    <option>International Wire Map</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="utility-import-location">Select Location of Import File</label>
                  <div class="file-upload-area">
                    <input type="file" id="utility-file-input" class="file-input" accept=".csv,.xlsx,.xls">
                    <div class="file-upload-prompt" id="utility-file-prompt">
                      <span class="material-symbols-outlined">cloud_upload</span>
                      <span>Select a file</span>
                    </div>
                    <button class="validate-btn" id="utility-validate-btn">Validate File</button>
                  </div>
                </div>
              </div>
              
              <div class="import-summary">
                <h4>File Content Summary</h4>
                <div class="summary-stats">
                  <div class="summary-stat">
                    <div class="stat-label">Upload Date & Time</div>
                    <div class="stat-value">-</div>
                  </div>
                  <div class="summary-stat">
                    <div class="stat-label">Records Submitted for Review</div>
                    <div class="stat-value">-</div>
                  </div>
                  <div class="summary-stat">
                    <div class="stat-label">Valid Records</div>
                    <div class="stat-value">-</div>
                  </div>
                </div>
              </div>
              
              <div class="import-details">
                <h4>Failed Records and Details</h4>
                <div class="details-placeholder">
                  <div class="detail-item">
                    <div class="detail-label">Record Number</div>
                    <div class="detail-label">Reason for Failure</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  getWireDetailsHTML(wireData) {
    if (!wireData) return '';
    
    const statusColor = wireData.status.toLowerCase() === 'processed' ? 'processed' : 
                       wireData.status.toLowerCase() === 'pending' ? 'pending' : 'error';
    
    return `
      <div class="utility-panel wire-details-utility" id="wire-details-utility">
        <div class="utility-header">
          <div class="utility-tabs">
            <button class="utility-tab utility-tab--active" data-tab="details">Wire Details</button>
            <button class="utility-tab" data-tab="history">History</button>
            <button class="utility-tab" data-tab="documents">Documents</button>
          </div>
          <button class="utility-close-btn" id="utility-close-btn">
            <span class="material-symbols-outlined">close</span>
          </button>
        </div>
        <div class="utility-body">
          <div class="utility-content utility-content--active" data-tab="details">
            <div class="wire-summary">
              <h3>Wire Transfer #${wireData.id}</h3>
              <div class="status-badge status-badge--${statusColor}">${wireData.status}</div>
            </div>
            
            <div class="wire-section">
              <h4>Transfer Details</h4>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">Amount:</span>
                  <span class="detail-value">${wireData.amount}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Currency:</span>
                  <span class="detail-value">${wireData.currency}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Date:</span>
                  <span class="detail-value">${wireData.date}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Wire Type:</span>
                  <span class="detail-value">${wireData.wireType}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Template:</span>
                  <span class="detail-value">${wireData.template}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Fees:</span>
                  <span class="detail-value">${wireData.fees}</span>
                </div>
              </div>
            </div>
            
            <div class="wire-section">
              <h4>Beneficiary Information</h4>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">Name:</span>
                  <span class="detail-value">${wireData.beneficiary}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Bank:</span>
                  <span class="detail-value">${wireData.beneficiaryBank}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Account:</span>
                  <span class="detail-value">${wireData.accountNumber}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Routing:</span>
                  <span class="detail-value">${wireData.routingNumber}</span>
                </div>
              </div>
            </div>
            
            <div class="wire-section">
              <h4>Additional Information</h4>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">Purpose:</span>
                  <span class="detail-value">${wireData.purpose}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Exchange Rate:</span>
                  <span class="detail-value">${wireData.exchangeRate}</span>
                </div>
                <div class="detail-item detail-item--full">
                  <span class="detail-label">Instructions:</span>
                  <span class="detail-value">${wireData.instructions}</span>
                </div>
              </div>
            </div>
            
            <div class="wire-actions">
              <button class="action-btn action-btn--primary">Edit Wire</button>
              <button class="action-btn action-btn--secondary">Duplicate</button>
              <button class="action-btn action-btn--secondary">Print</button>
            </div>
          </div>
          
          <div class="utility-content" data-tab="history">
            <div class="wire-section">
              <h4>Transaction History</h4>
              <div class="history-timeline">
                <div class="history-item">
                  <div class="history-date">Today, 10:15 AM</div>
                  <div class="history-action">Wire processed successfully</div>
                </div>
                <div class="history-item">
                  <div class="history-date">Today, 09:30 AM</div>
                  <div class="history-action">Wire submitted for processing</div>
                </div>
                <div class="history-item">
                  <div class="history-date">Today, 09:15 AM</div>
                  <div class="history-action">Wire created</div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="utility-content" data-tab="documents">
            <div class="wire-section">
              <h4>Related Documents</h4>
              <div class="documents-list">
                <div class="document-item">
                  <span class="material-symbols-outlined">description</span>
                  <span>Wire Transfer Receipt</span>
                  <button class="document-download">Download</button>
                </div>
                <div class="document-item">
                  <span class="material-symbols-outlined">receipt</span>
                  <span>Fee Statement</span>
                  <button class="document-download">Download</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  getHelpPanelHTML() {
    // Return the original help panel HTML
    return `
      <div class="dashboard-sidebar" id="dashboard-sidebar">
        <div class="sidebar-panel" id="help-panel">
          <div class="panel-header">
            <h3>Help & Resources</h3>
            <button class="panel-minimize-btn" id="help-minimize-btn" title="Minimize">
              <span class="material-symbols-outlined">remove</span>
            </button>
          </div>
          <div class="panel-content">
            <div class="help-section">
              <h4>Quick Links</h4>
              <div class="help-links">
                <a href="#" class="help-link">
                  <span class="help-link__icon">article</span>
                  <span class="help-link__text">Wire Transfer Guide</span>
                </a>
                <a href="#" class="help-link">
                  <span class="help-link__icon">play_circle</span>
                  <span class="help-link__text">Video Tutorials</span>
                </a>
                <a href="#" class="help-link">
                  <span class="help-link__icon">schedule</span>
                  <span class="help-link__text">Wire Cut-off Times</span>
                </a>
              </div>
            </div>
            
            <div class="help-section">
              <h4>Need Assistance?</h4>
              <div class="support-info">
                <p>Contact your dedicated support team</p>
                <div class="support-contact">
                  <span class="material-symbols-outlined">phone</span>
                  <span class="support-phone">1-800-555-0123</span>
                </div>
              </div>
              <button class="chat-support-btn">
                <span class="material-symbols-outlined">chat</span>
                <span>Chat with Support</span>
              </button>
            </div>

            <div class="help-section">
              <h4>Latest Updates</h4>
              <div class="updates-list">
                <div class="update-item update-item--feature">
                  <div class="update-title">New Feature</div>
                  <div class="update-description">Global Pay now supports 5 new currencies</div>
                </div>
                <div class="update-item update-item--maintenance">
                  <div class="update-title">Scheduled Maintenance</div>
                  <div class="update-description">July 15, 2023 from 2-4 AM EST</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  bindUtilityPanelEvents() {
    // Close button
    const closeBtn = document.getElementById('utility-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        this.closeUtilityPanel();
      });
    }
    
    // Utility tabs
    const utilityTabs = document.querySelectorAll('.utility-tab');
    utilityTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        this.switchUtilityTab(e.currentTarget.dataset.tab);
      });
    });
    
    // File upload
    const fileInput = document.getElementById('utility-file-input');
    const uploadPrompt = document.getElementById('utility-file-prompt');
    
    if (uploadPrompt && fileInput) {
      uploadPrompt.addEventListener('click', () => {
        fileInput.click();
      });
      
      fileInput.addEventListener('change', (e) => {
        this.handleFileUpload(e.target.files[0]);
      });
    }
    
    // Validate button
    const validateBtn = document.getElementById('utility-validate-btn');
    if (validateBtn) {
      validateBtn.addEventListener('click', () => {
        const fileInput = document.getElementById('utility-file-input');
        if (fileInput && fileInput.files.length > 0) {
          this.validateFile(fileInput.files[0]);
        }
      });
    }
  }
  
  switchUtilityTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.utility-tab').forEach(tab => {
      tab.classList.remove('utility-tab--active');
    });
    document.querySelector(`[data-tab="${tabName}"].utility-tab`).classList.add('utility-tab--active');
    
    // Update tab content
    document.querySelectorAll('.utility-content').forEach(content => {
      content.classList.remove('utility-content--active');
    });
    document.querySelector(`[data-tab="${tabName}"].utility-content`).classList.add('utility-content--active');
    
    console.log(`Switched to utility tab: ${tabName}`);
  }
  
  bindWireDetailsEvents() {
    // Close button
    const closeBtn = document.getElementById('utility-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        this.closeUtilityPanel();
      });
    }
    
    // Tab switching
    const tabs = document.querySelectorAll('.utility-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        this.switchUtilityTab(tab.dataset.tab);
      });
    });
    
    // Wire action buttons
    const actionButtons = document.querySelectorAll('.wire-actions .action-btn');
    actionButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        console.log('Wire action:', btn.textContent);
      });
    });
    
    // Document download buttons
    const downloadButtons = document.querySelectorAll('.document-download');
    downloadButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        console.log('Download document:', btn.previousElementSibling.textContent);
      });
    });
  }
  
  bindResizeHandle() {
    const resizeHandle = document.getElementById('sidebar-resize-handle');
    if (!resizeHandle) return;
    
    let isResizing = false;
    let startX = 0;
    let startWidth = 0;
    
    resizeHandle.addEventListener('mousedown', (e) => {
      isResizing = true;
      startX = e.clientX;
      startWidth = this.state.rightPanelWidth;
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isResizing) return;
      
      const deltaX = startX - e.clientX;
      const newWidth = Math.max(280, Math.min(600, startWidth + deltaX));
      
      this.state.rightPanelWidth = newWidth;
      this.updateLayout();
      this.calculateTableColumns();
    });
    
    document.addEventListener('mouseup', () => {
      if (isResizing) {
        isResizing = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
      }
    });
  }
  
  bindSecondaryToggle() {
    const secondaryPane = document.querySelector('.sidenav__secondary');
    
    // Initialize secondary nav state based on current DOM state
    if (secondaryPane) {
      this.state.secondaryNavVisible = secondaryPane.classList.contains('sidenav__secondary--visible') && 
                                       !secondaryPane.classList.contains('sidenav__secondary--hidden');
      console.log('Initial secondary nav state:', this.state.secondaryNavVisible);
    }
    
    // Listen for secondary navigation toggle events
    document.addEventListener('secondaryNavToggled', (e) => {
      this.state.secondaryNavVisible = e.detail.visible;
      console.log('Secondary nav toggled via event, visible:', this.state.secondaryNavVisible);
      this.updateLayout();
      this.calculateTableColumns();
    });
    
    // Fallback: Watch for class changes on secondary nav (in case events don't work)
    if (secondaryPane) {
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            const isVisible = secondaryPane.classList.contains('sidenav__secondary--visible') && 
                             !secondaryPane.classList.contains('sidenav__secondary--hidden');
            
            if (isVisible !== this.state.secondaryNavVisible) {
              this.state.secondaryNavVisible = isVisible;
              console.log('Secondary nav state changed via mutation observer, visible:', this.state.secondaryNavVisible);
              this.updateLayout();
              this.calculateTableColumns();
            }
          }
        });
      });
      
      observer.observe(secondaryPane, { 
        attributes: true, 
        attributeFilter: ['class'] 
      });
    }
  }
  
  updateLayout() {
    const dashboardContainer = document.querySelector('#main-content.wire-dashboard');
    
    if (!dashboardContainer) {
      console.warn('Dashboard container not found');
      return;
    }
    
    // Update data attributes to trigger CSS layout changes
    dashboardContainer.setAttribute('data-help-minimized', this.state.helpMinimized);
    dashboardContainer.setAttribute('data-utility-panel-open', this.state.utilityPanelOpen);
    if (this.state.utilityPanelType) {
      dashboardContainer.setAttribute('data-utility-panel-type', this.state.utilityPanelType);
    } else {
      dashboardContainer.removeAttribute('data-utility-panel-type');
    }
    
    console.log('Layout updated - help minimized:', this.state.helpMinimized, 'utility panel:', this.state.utilityPanelOpen);
    
    // Update layout data attributes if dashboardLayout exists
    if (this.dashboardLayout) {
      this.dashboardLayout.dataset.secondaryNavHidden = !this.state.secondaryNavVisible;
      this.dashboardLayout.dataset.helpMinimized = this.state.helpMinimized;
      this.dashboardLayout.dataset.importModalOpen = this.state.importModalOpen;
      this.dashboardLayout.dataset.utilityPanelOpen = this.state.utilityPanelOpen;
    }
    
    // Update sidebar width
    if (this.sidebar) {
      this.sidebar.style.width = `${this.state.rightPanelWidth}px`;
    }
    
    // Update import modal width when open (legacy modal support)
    if (this.importModal && this.state.importModalOpen) {
      this.importModal.style.width = `${Math.max(400, this.state.rightPanelWidth)}px`;
    }
    
    // Update layout manager state
    if (this.layoutManager) {
      this.layoutManager.dataset.secondaryNavVisible = this.state.secondaryNavVisible;
      this.layoutManager.dataset.helpMinimized = this.state.helpMinimized;
      this.layoutManager.dataset.importModalOpen = this.state.importModalOpen;
      this.layoutManager.dataset.utilityPanelOpen = this.state.utilityPanelOpen;
      this.layoutManager.dataset.utilityPanelType = this.state.utilityPanelType || '';
      this.layoutManager.dataset.rightPanelWidth = this.state.rightPanelWidth;
    }
  }
  
  calculateTableColumns() {
    if (!this.table) return;

    const mainContentWidth = this.mainContent ? this.mainContent.offsetWidth : window.innerWidth;
    let availableWidth = mainContentWidth;

    // Subtract space for secondary navigation when visible (~320px)
    if (this.state.secondaryNavVisible) {
      availableWidth -= 320; // secondary nav width
    }

    // Subtract space for right panel when NOT minimized
    if (!this.state.helpMinimized) {
      availableWidth -= this.state.rightPanelWidth + 32; // including gap
    }

    // Subtract space for import modal when open (legacy)
    if (this.state.importModalOpen) {
      availableWidth -= Math.max(400, this.state.rightPanelWidth);
    }

    console.log('Table column calculation:', {
      mainContentWidth,
      secondaryNavVisible: this.state.secondaryNavVisible,
      helpMinimized: this.state.helpMinimized,
      importModalOpen: this.state.importModalOpen,
      utilityPanelOpen: this.state.utilityPanelOpen,
      availableWidth
    });

    // Show/hide columns based on available width
    const templateCells = this.table.querySelectorAll('.table-cell--template');
    const currencyCells = this.table.querySelectorAll('.table-cell--currency');
    const actionCells = this.table.querySelectorAll('.table-cell--action');

    // Hide template and action columns when utility panel or import modal is open
    const hideColumnsForUtility = this.state.importModalOpen || this.state.utilityPanelOpen;
    
    // Show template column when there's enough space AND no utility panel
    const showTemplate = availableWidth >= 1000 && !hideColumnsForUtility;
    templateCells.forEach(cell => {
      cell.style.display = showTemplate ? '' : 'none';
    });

    // Show wire currency column when there's enough space AND no utility panel
    const showCurrency = availableWidth >= 1200 && !hideColumnsForUtility;
    currencyCells.forEach(cell => {
      cell.style.display = showCurrency ? '' : 'none';
    });

    // Action column is always shown (unless explicitly hidden for utility)
    const showAction = !hideColumnsForUtility;
    actionCells.forEach(cell => {
      cell.style.display = showAction ? '' : 'none';
    });

    // Update grid template columns
    // Base: funding-account (1fr), beneficiary (1.5fr), amount (1fr), status (1fr), date (1fr), action (1fr)
    let gridColumns = '1fr 1.5fr 1fr 1fr 1fr';

    // Insert template before action if shown
    if (showTemplate) {
      gridColumns += ' 1fr'; // template
    }
    
    // Insert currency before action if shown
    if (showCurrency) {
      gridColumns += ' 1fr'; // currency
    }
    
    // Always add action as last column (if shown)
    if (showAction) {
      gridColumns += ' 1fr'; // action
    }

    const totalColumns = 5 + (showTemplate ? 1 : 0) + (showCurrency ? 1 : 0) + (showAction ? 1 : 0);
    console.log('Showing columns:', totalColumns, { showTemplate, showCurrency, showAction, hideColumnsForUtility });

    const tableRows = this.table.querySelectorAll('.table-row');
    tableRows.forEach(row => {
      row.style.gridTemplateColumns = gridColumns;
    });
  }
  
  // Public methods for external access
  getSecondaryNavVisible() {
    return this.state.secondaryNavVisible;
  }
  
  setSecondaryNavVisible(visible) {
    this.state.secondaryNavVisible = visible;
    this.updateLayout();
    this.calculateTableColumns();
  }
  
  getState() {
    return { ...this.state };
  }
}

// Activity Summary Controls
class ActivitySummary {
  constructor() {
    this.periodSelect = document.getElementById('activity-period');
    this.filterBtn = document.querySelector('.filter-btn');
    this.summaryCards = document.querySelectorAll('.summary-card');
    
    this.init();
  }
  
  init() {
    this.bindEvents();
  }
  
  bindEvents() {
    if (this.periodSelect) {
      this.periodSelect.addEventListener('change', (e) => {
        this.updateActivityPeriod(e.target.value);
      });
    }
    
    if (this.filterBtn) {
      this.filterBtn.addEventListener('click', () => {
        this.showFilterOptions();
      });
    }
  }
  
  updateActivityPeriod(period) {
    console.log('Update activity period:', period);
    // Simulate data update
    this.updateSummaryCards(period);
  }
  
  updateSummaryCards(period) {
    // Simulate different data based on period
    const data = {
      today: { submitted: 12, processed: 8, pending: 3, errors: 1 },
      week: { submitted: 45, processed: 38, pending: 5, errors: 2 },
      month: { submitted: 180, processed: 165, pending: 12, errors: 3 }
    };
    
    const periodData = data[period] || data.today;
    
    this.summaryCards.forEach((card, index) => {
      const valueElement = card.querySelector('.card-value');
      if (valueElement) {
        const values = [periodData.submitted, periodData.processed, periodData.pending, periodData.errors];
        valueElement.textContent = values[index] || 0;
      }
    });
  }
  
  showFilterOptions() {
    console.log('Show filter options');
    // Could show a dropdown or modal with additional filters
  }
}

// Transaction Table Controls
class TransactionTable {
  constructor() {
    this.table = document.querySelector('.wire-transactions-table');
    this.tableRows = document.querySelectorAll('.table-row:not(.table-row--header)');
    this.viewAllBtn = document.querySelector('.view-all-btn');
    
    this.init();
  }
  
  init() {
    this.bindEvents();
  }
  
  bindEvents() {
    // Action buttons
    const actionBtns = document.querySelectorAll('.table-action-btn');
    actionBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.handleTableAction(e.currentTarget.dataset.action, e.currentTarget);
      });
    });
    
    // View all button
    if (this.viewAllBtn) {
      this.viewAllBtn.addEventListener('click', () => {
        this.showAllTransactions();
      });
    }
    
    // Row hover effects
    this.tableRows.forEach(row => {
      row.addEventListener('mouseenter', () => {
        row.style.backgroundColor = '#f9fafb';
      });
      
      row.addEventListener('mouseleave', () => {
        row.style.backgroundColor = '';
      });
    });
  }
  
  handleTableAction(action, button) {
    const row = button.closest('.table-row');
    const beneficiary = row.querySelector('[data-label="Beneficiary"]').textContent;
    
    switch (action) {
      case 'view':
        console.log('View transaction for:', beneficiary);
        this.viewTransaction(row);
        break;
      case 'approve':
        console.log('Approve transaction for:', beneficiary);
        this.approveTransaction(row);
        break;
      case 'fix':
        console.log('Fix transaction for:', beneficiary);
        this.fixTransaction(row);
        break;
    }
  }
  
  viewTransaction(row) {
    // Navigate to transaction detail view
    console.log('Navigate to transaction details');
  }
  
  approveTransaction(row) {
    // Handle transaction approval
    const statusCell = row.querySelector('.status-badge');
    if (statusCell) {
      statusCell.className = 'status-badge status-badge--processed';
      statusCell.textContent = 'Processed';
    }
    
    const actionBtn = row.querySelector('.table-action-btn');
    if (actionBtn) {
      actionBtn.textContent = 'View';
      actionBtn.dataset.action = 'view';
    }
  }
  
  fixTransaction(row) {
    // Navigate to fix transaction form
    console.log('Navigate to fix transaction form');
  }
  
  showAllTransactions() {
    console.log('Navigate to all transactions view');
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  initializeWireDashboard();
});

// Manual initialization function
function initializeWireDashboard() {
  console.log('Attempting to initialize wire dashboard...');
  
  const helpBtn = document.getElementById('help-minimize-btn');
  const dashboardMain = document.querySelector('.dashboard-main');
  const wireDashboardContainer = document.querySelector('#main-content.wire-dashboard');
  
  console.log('Element check:', {
    helpBtn: !!helpBtn,
    dashboardMain: !!dashboardMain,
    wireDashboardContainer: !!wireDashboardContainer
  });
  
  // Only initialize if we're on the wire dashboard page
  if (helpBtn || dashboardMain || wireDashboardContainer) {
    console.log('Initializing wire dashboard components...');
    
    try {
      window.wireDashboard = new WireDashboard();
      window.activitySummary = new ActivitySummary();
      window.transactionTable = new TransactionTable();
      
      console.log('Wire Payments Dashboard initialized successfully');
    } catch (error) {
      console.error('Error initializing wire dashboard:', error);
    }
  } else {
    console.log('Wire dashboard elements not found, skipping initialization');
  }
}

// Export initialization function for manual triggering
if (typeof window !== 'undefined') {
  window.initializeWireDashboard = initializeWireDashboard;
}

// Export for external access
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { WireDashboard, ActivitySummary, TransactionTable };
} 
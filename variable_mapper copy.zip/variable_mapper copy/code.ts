figma.showUI(__html__, { width: 800, height: 600 });

let currentTextNode: TextNode | null = null;

// Function to handle selection changes
function handleSelectionChange() {
	const selection = figma.currentPage.selection;
	if (selection.length === 1 && selection[0].type === "TEXT") {
		currentTextNode = selection[0] as TextNode;
		updateCurrentMapping();
	} else {
		currentTextNode = null;
		figma.ui.postMessage({
			type: "update-current-mapping",
			data: {
				mapping: null,
				message:
					"Please select a single text node to view or apply variable mappings.",
			},
		});
	}
}

// Update current mapping in the UI
async function updateCurrentMapping() {
  if (!currentTextNode) {
    notifyUI("No text node is selected.");
    return;
  }

  const boundVariable = currentTextNode.boundVariables?.characters;
  if (!boundVariable) {
    notifyUI("No variable is bound to this text node.");
    return;
  }

  const variable = await figma.variables.getVariableByIdAsync(boundVariable.id);
  if (!variable || variable.resolvedType !== "STRING") {
    notifyUI("The bound variable is not of type STRING.");
    return;
  }

  const collection = await figma.variables.getVariableCollectionByIdAsync(
    variable.variableCollectionId
  );
  if (!collection || collection.modes.length === 0) {
    notifyUI("The variable's collection has no modes or is invalid.");
    return;
  }

  const defaultModeId = collection.modes[0].modeId;
  figma.ui.postMessage({
    type: "update-current-mapping",
    data: {
      mapping: {
        colllectionName: collection.name,
        id: variable.id,
        name: variable.name,
        value: variable.valuesByMode[defaultModeId],
      },
      message: "Variable mapping updated successfully.",
    },
  });
}

function notifyUI(message: string) {
  figma.ui.postMessage({
    type: "update-current-mapping",
    data: { mapping: null, message },
  });
}

// Fetch collections and send to UI
async function fetchCollections() {
	const collections = await figma.variables.getLocalVariableCollectionsAsync();
	figma.ui.postMessage({
		type: "update-collections",
		data: { collections: collections.map((c) => ({ id: c.id, name: c.name })) },
	});
}

// Fetch variables for a collection and send to UI
async function fetchVariables(collectionId: string) {
	const collection = await figma.variables.getVariableCollectionByIdAsync(
		collectionId
	);

	if (collection) {
		const defaultModeId = collection.modes[0].modeId;

		// Fetch all variables in the collection
		const variables = await Promise.all(
			collection.variableIds.map((id) =>
				figma.variables.getVariableByIdAsync(id)
			)
		);

    // Get the bound variable ID from the selected text node
    const boundVariableId = currentTextNode?.boundVariables?.characters?.id;

		// Filter variables to include only those of type 'STRING'
		const stringVariables = variables.filter(
			(variable) => variable?.resolvedType === "STRING"
		);

		// Send the filtered variables to the UI
		figma.ui.postMessage({
			type: "update-variables",
			data: {
				variables: stringVariables.map((variable) => ({
					id: variable!.id,
					name: variable!.name,
					value: String(variable!.valuesByMode[defaultModeId]), // Convert value to string
					isMapped: variable!.id === boundVariableId,
				})),
			},
		});
	}
}

// Apply variable to the selected text node
async function applyVariable(variableId: string) {
  if (!currentTextNode) {
    // Notify the user if no valid text node is selected
    figma.ui.postMessage({
      type: "toast",
      data: { message: "No valid text node is selected. Please select a text node.", success: false },
    });
    return;
  }

  const variable = await figma.variables.getVariableByIdAsync(variableId);
  if (variable && variable.resolvedType === "STRING") {
    // Bind the variable to the text node
    currentTextNode.setBoundVariable("characters", variable);

    // Notify the user via a toast message and indicate success
    figma.ui.postMessage({
      type: "toast",
      data: { message: "Variable successfully bound to the text node!", success: true },
    });
  } else {
    // Notify the user if the variable is not of type STRING or does not exist
    figma.ui.postMessage({
      type: "toast",
      data: { message: "Variable is not of type STRING or does not exist.", success: false },
    });
  }
}

// Handle messages from the UI
figma.ui.onmessage = async (msg) => {
  if (msg.type === "fetch-variables") {
    await fetchVariables(msg.collectionId);
  } else if (msg.type === "apply-variable") {
    await applyVariable(msg.variableId);
  } else if (msg.type === "refresh-ui") {
    // Re-trigger the UI to load the current state of the selected node
    handleSelectionChange();
  }
};

// Listen for selection changes
figma.on("selectionchange", handleSelectionChange);

// Initial setup
fetchCollections();
handleSelectionChange();

# BMO Marketplace Icons

This directory contains individual SVG icons extracted from the BMO Marketplace Icons design system.

## Folder Structure

### `/primary/`
Main icon set for the BMO Marketplace:
- `self-service.svg` - Self-Service icon (Accounts & Services)
- `app-integration.svg` - App Integration icon
- `partner-offers.svg` - Partner Offers icon
- `api.svg` - API icon

### `/alternatives/`
Alternative designs for Self-Service icon:
- `self-service-alt-c.svg` - Alternative C (With Labels & Submit)
- `self-service-alt-d.svg` - Alternative D (Two Column Form)

### `/scaled/`
Scaled versions of the Self-Service icon:
- `self-service-24px.svg` - 24×24 pixel version
- `self-service-32px.svg` - 32×32 pixel version
- `self-service-48px.svg` - 48×48 pixel version
- `self-service-64px.svg` - 64×64 pixel version

## Color Specifications

All icons use the BMO color palette:
- **Primary**: `#0075be` (BMO Blue 600)
- **Secondary**: `#929ba9` (Neutral 400)
- **Accent**: `#c7e4fc` (Blue 200)
- **Background**: `#ffffff` (White)

## Usage

Each SVG is optimized with appropriate viewBox settings and can be scaled to any size while maintaining crisp edges. The icons are designed to work well at various sizes from 24px to 64px and beyond.

## Source

These icons were extracted from the BMO Marketplace Icons Final Design System specification.

import { Injectable, signal, computed, effect } from '@angular/core';

export type Language = 'en' | 'fr';

interface TranslationData {
  [key: string]: any;
}

// Import the default language directly to ensure it's always available
import enTranslations from '../../../assets/i18n/en.json';

@Injectable({
  providedIn: 'root'
})
export class TranslationService {
  private currentLanguage = signal<Language>('en');
  private isLoading = signal<boolean>(false);
  private translations = signal<{ en: TranslationData; fr: TranslationData }>({
    en: enTranslations, // Default language always available
    fr: {} // Will be loaded on demand
  });

  // Computed signal for current translations
  public currentTranslations = computed(() => {
    const lang = this.currentLanguage();
    return this.translations()[lang];
  });

  // Public signals for component access
  public language = this.currentLanguage.asReadonly();
  public loading = this.isLoading.asReadonly();

  // Store text element references for future GSAP animations
  private textElementRefs = new Map<string, HTMLElement>();

  constructor() {
    // Load saved language preference (check if running in browser)
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      const savedLang = localStorage.getItem('preferredLanguage') as Language;
      if (savedLang && (savedLang === 'en' || savedLang === 'fr')) {
        this.currentLanguage.set(savedLang);
      }
    }

    // Load French translations if needed
    if (this.currentLanguage() === 'fr') {
      this.loadFrenchTranslations();
    }

    // Save language preference and load translations when it changes
    effect(() => {
      const lang = this.currentLanguage();
      
      // Save preference
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        localStorage.setItem('preferredLanguage', lang);
      }
      
      // Load French translations if switching to French
      if (lang === 'fr' && Object.keys(this.translations().fr).length === 0) {
        this.loadFrenchTranslations();
      }
    });
  }

  /**
   * Load French translations on demand
   */
  private async loadFrenchTranslations(): Promise<void> {
    // Only fetch in browser environment
    if (typeof window === 'undefined') {
      return; // French will be loaded on client-side hydration
    }
    
    this.isLoading.set(true);
    
    try {
      const response = await fetch('/assets/i18n/fr.json');

      if (!response.ok) {
        throw new Error('Failed to load French translations');
      }

      const frData = await response.json();
      
      this.translations.update(current => ({
        ...current,
        fr: frData
      }));
      
      console.log('French translations loaded successfully', frData);
      
    } catch (error) {
      console.error('Failed to load French translations:', error);
      // Fall back to English if French fails to load
      if (this.currentLanguage() === 'fr') {
        console.warn('Falling back to English due to French translation load failure');
        this.currentLanguage.set('en');
      }
    } finally {
      this.isLoading.set(false);
    }
  }

  /**
   * Get a translation by key path
   * @param key Dot-notation path (e.g., 'header.buttons.signIn')
   * @param params Optional parameters for interpolation
   * @returns Translated string or the key if not found
   */
  get(key: string, params?: Record<string, any>): string {
    const keys = key.split('.');
    let value: any = this.currentTranslations();

    for (const k of keys) {
      value = value?.[k];
      if (value === undefined) {
        // If key not found in current language, try default language (English)
        if (this.currentLanguage() !== 'en') {
          value = this.getFromLanguage(key, 'en');
          if (value) {
            // Only warn if French translations are actually loaded but key is missing
            if (Object.keys(this.translations().fr).length > 0) {
              console.warn(`Translation key "${key}" not found in ${this.currentLanguage()}, using English`);
            }
            return this.interpolate(value, params);
          }
        }
        
        // In development, warn about missing keys
        if (typeof window !== 'undefined' && window.location.hostname === 'localhost') {
          console.warn(`Translation key not found: ${key}`);
        }
        
        // Return the key itself as last resort (better UX than empty string)
        return key;
      }
    }

    return this.interpolate(typeof value === 'string' ? value : key, params);
  }

  /**
   * Get translation from specific language
   */
  private getFromLanguage(key: string, language: Language): string | undefined {
    const keys = key.split('.');
    let value: any = this.translations()[language];

    for (const k of keys) {
      value = value?.[k];
      if (value === undefined) {
        return undefined;
      }
    }

    return typeof value === 'string' ? value : undefined;
  }

  /**
   * Simple string interpolation for parameters
   */
  private interpolate(text: string, params?: Record<string, any>): string {
    if (!params) return text;
    
    return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      return params[key] !== undefined ? params[key] : match;
    });
  }

  /**
   * Switch language
   */
  setLanguage(language: Language): void {
    if (language === 'en' || language === 'fr') {
      this.currentLanguage.set(language);
    }
  }

  /**
   * Toggle between languages
   */
  toggleLanguage(): void {
    const newLang = this.currentLanguage() === 'en' ? 'fr' : 'en';
    this.currentLanguage.set(newLang);
  }

  /**
   * Get current language
   */
  getCurrentLanguage(): Language {
    return this.currentLanguage();
  }

  /**
   * Check if current language is English
   */
  isEnglish(): boolean {
    return this.currentLanguage() === 'en';
  }

  /**
   * Check if current language is French
   */
  isFrench(): boolean {
    return this.currentLanguage() === 'fr';
  }

  /**
   * Register a text element for animation
   */
  registerTextElement(key: string, element: HTMLElement): void {
    this.textElementRefs.set(key, element);
  }

  /**
   * Get registered text elements for animation
   */
  getTextElements(): Map<string, HTMLElement> {
    return this.textElementRefs;
  }

  /**
   * Alias for get() method - used by TranslatePipe
   * @param key Dot-notation path (e.g., 'header.buttons.signIn')
   * @param params Optional parameters for interpolation
   * @returns Translated string or the key if not found
   */
  translate(key: string, params?: Record<string, any>): string {
    return this.get(key, params);
  }
}
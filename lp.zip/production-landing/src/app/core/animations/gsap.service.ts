import { Injectable, OnDestroy } from '@angular/core';
import type { GSAPTween, GSAPTimeline, ScrollTriggerInstance } from './gsap.types';

/**
 * GSAP Animation Service
 * Provides access to GSAP and manages ScrollTrigger instances
 */
@Injectable({
  providedIn: 'root'
})
export class GsapService implements OnDestroy {
  private scrollTriggers: ScrollTriggerInstance[] = [];
  private tweens: GSAPTween[] = [];
  private timelines: GSAPTimeline[] = [];
  private gsapReady = false;
  private readyCallbacks: (() => void)[] = [];

  constructor() {
    this.initializeGSAP();
  }

  /**
   * Initialize GSAP and register plugins
   */
  private initializeGSAP(): void {
    // Don't initialize during SSR
    if (typeof window === 'undefined') {
      return;
    }

    // Check if GSAP is already loaded
    if (window.gsap) {
      this.registerPlugins();
    } else {
      // Wait for GSAP to load
      this.waitForGSAPToLoad();
    }
  }

  /**
   * Wait for GSAP to be available
   */
  private waitForGSAPToLoad(): void {
    let attempts = 0;
    const maxAttempts = 50; // 5 seconds max wait
    
    const checkInterval = setInterval(() => {
      attempts++;
      
      if (window.gsap) {
        clearInterval(checkInterval);
        this.registerPlugins();
      } else if (attempts >= maxAttempts) {
        clearInterval(checkInterval);
        console.error('GSAP failed to load after 5 seconds');
      }
    }, 100); // Check every 100ms
  }

  /**
   * Register GSAP plugins
   */
  private registerPlugins(): void {
    window.gsap.registerPlugin(window.ScrollTrigger, window.TextPlugin);
    window.gsap.defaults({ ease: 'power2.inOut' });
    console.log('GSAP initialized with ScrollTrigger and TextPlugin');
    
    // Mark as ready and execute callbacks
    this.gsapReady = true;
    this.readyCallbacks.forEach(callback => callback());
    this.readyCallbacks = [];
  }

  /**
   * Wait for GSAP to be ready
   */
  whenReady(callback: () => void): void {
    if (this.gsapReady) {
      callback();
    } else {
      this.readyCallbacks.push(callback);
    }
  }
  
  /**
   * Async version of whenReady for use with await
   * Public method for components to wait for GSAP initialization
   */
  public async waitForGSAP(): Promise<void> {
    return new Promise((resolve) => {
      this.whenReady(() => resolve());
    });
  }

  /**
   * Check if GSAP is ready
   */
  isReady(): boolean {
    return this.gsapReady;
  }

  /**
   * Get GSAP instance
   */
  get gsap() {
    if (typeof window !== 'undefined' && window.gsap) {
      return window.gsap;
    }
    throw new Error('GSAP is not available');
  }

  /**
   * Get ScrollTrigger instance
   */
  get ScrollTrigger() {
    if (typeof window !== 'undefined' && window.ScrollTrigger) {
      return window.ScrollTrigger;
    }
    throw new Error('ScrollTrigger is not available');
  }

  /**
   * Create and track a ScrollTrigger instance
   */
  createScrollTrigger(config: any): ScrollTriggerInstance {
    const trigger = this.ScrollTrigger.create(config);
    this.scrollTriggers.push(trigger);
    return trigger;
  }

  /**
   * Create and track a tween
   */
  to(target: any, vars: any): GSAPTween {
    const tween = this.gsap.to(target, vars);
    this.tweens.push(tween);
    return tween;
  }

  /**
   * Create and track a from tween
   */
  from(target: any, vars: any): GSAPTween {
    const tween = this.gsap.from(target, vars);
    this.tweens.push(tween);
    return tween;
  }

  /**
   * Create and track a fromTo tween
   */
  fromTo(target: any, fromVars: any, toVars: any): GSAPTween {
    const tween = this.gsap.fromTo(target, fromVars, toVars);
    this.tweens.push(tween);
    return tween;
  }

  /**
   * Create and track a timeline
   */
  timeline(vars?: any): GSAPTimeline {
    const timeline = this.gsap.timeline(vars);
    this.timelines.push(timeline);
    return timeline;
  }

  /**
   * Kill all tweens for a specific target
   */
  killTweensOf(target: any): void {
    this.gsap.killTweensOf(target);
  }

  /**
   * Refresh all ScrollTriggers
   */
  refreshScrollTriggers(): void {
    this.ScrollTrigger.refresh();
  }

  /**
   * Clean up specific ScrollTrigger
   */
  killScrollTrigger(trigger: ScrollTriggerInstance): void {
    trigger.kill();
    const index = this.scrollTriggers.indexOf(trigger);
    if (index > -1) {
      this.scrollTriggers.splice(index, 1);
    }
  }

  /**
   * Initialize smooth scroll for anchor links
   */
  initSmoothScroll(container?: string): void {
    if (!this.gsapReady) return;
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e: Event) => {
        e.preventDefault();
        const href = (anchor as HTMLAnchorElement).getAttribute('href');
        if (!href) return;
        
        const target = document.querySelector(href);
        if (target) {
          this.gsap.to(window, {
            duration: 1,
            scrollTo: {
              y: target,
              offsetY: 80 // Account for sticky header
            },
            ease: 'power2.inOut'
          });
        }
      });
    });
  }
  
  /**
   * Clean up all animations and ScrollTriggers
   */
  cleanupAll(): void {
    // Kill all ScrollTriggers
    this.scrollTriggers.forEach(trigger => trigger.kill());
    this.scrollTriggers = [];

    // Kill all tweens
    this.tweens.forEach(tween => tween.kill());
    this.tweens = [];

    // Kill all timelines
    this.timelines.forEach(timeline => timeline.kill());
    this.timelines = [];
  }
  
  /**
   * Shorthand for cleanup
   */
  cleanup(): void {
    this.cleanupAll();
  }

  /**
   * Clean up on service destroy
   */
  ngOnDestroy(): void {
    this.cleanupAll();
  }
}
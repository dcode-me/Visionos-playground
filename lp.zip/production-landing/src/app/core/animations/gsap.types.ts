/**
 * GSAP TypeScript Declarations
 * Provides type definitions for GSAP loaded via CDN
 */

// Declare GSAP as a global variable
declare global {
  interface Window {
    gsap: typeof gsap;
    ScrollTrigger: typeof ScrollTrigger;
    TextPlugin: typeof TextPlugin;
  }

  const gsap: GSAP;
  const ScrollTrigger: ScrollTriggerStatic;
  const TextPlugin: any;
}

// Basic GSAP types
interface GSAP {
  to(target: any, vars: GSAPTweenVars): GSAPTween;
  from(target: any, vars: GSAPTweenVars): GSAPTween;
  fromTo(target: any, fromVars: GSAPTweenVars, toVars: GSAPTweenVars): GSAPTween;
  set(target: any, vars: object): GSAPTween;
  timeline(vars?: GSAPTimelineVars): GSAPTimeline;
  registerPlugin(...plugins: any[]): void;
  killTweensOf(target: any): void;
  getProperty(target: any, property: string): any;
  quickSetter(target: any, property: string, unit?: string): (value: number) => void;
  defaults(vars: Partial<GSAPTweenVars>): void;
  utils: GSAPUtils;
}

interface GSAPTween {
  play(): GSAPTween;
  pause(): GSAPTween;
  resume(): GSAPTween;
  reverse(): GSAPTween;
  restart(includeDelay?: boolean): GSAPTween;
  kill(): void;
  progress(value?: number): number | GSAPTween;
  duration(value?: number): number | GSAPTween;
  time(value?: number): number | GSAPTween;
  then(callback: () => void): Promise<void>;
}

interface GSAPTimeline extends GSAPTween {
  to(target: any, vars: GSAPTweenVars, position?: string | number): GSAPTimeline;
  from(target: any, vars: GSAPTweenVars, position?: string | number): GSAPTimeline;
  fromTo(target: any, fromVars: GSAPTweenVars, toVars: GSAPTweenVars, position?: string | number): GSAPTimeline;
  set(target: any, vars: object, position?: string | number): GSAPTimeline;
  add(child: GSAPTween | GSAPTimeline | Function | string, position?: string | number): GSAPTimeline;
  clear(): GSAPTimeline;
  getChildren(): (GSAPTween | GSAPTimeline)[];
}

interface GSAPTweenVars {
  duration?: number;
  delay?: number;
  ease?: string | Function;
  repeat?: number;
  yoyo?: boolean;
  stagger?: number | object;
  onStart?: Function;
  onUpdate?: Function;
  onComplete?: Function;
  onReverseComplete?: Function;
  scrollTrigger?: ScrollTriggerConfig;
  [key: string]: any;
}

interface GSAPTimelineVars extends GSAPTweenVars {
  paused?: boolean;
  defaults?: GSAPTweenVars;
  onRepeat?: Function;
}

interface GSAPUtils {
  toArray(value: any): any[];
  selector(scope?: any): (selector: string) => any;
  shuffle(array: any[]): any[];
  distribute(config: object): Function;
  random(min: number, max: number, snapIncrement?: number): number;
  wrap(value1: any, value2?: any): Function;
  wrapYoyo(value1: any, value2?: any): Function;
  normalize(value: number, min: number, max: number): number;
  clamp(min: number, max: number, value: number): number;
  splitColor(color: string): number[];
  interpolate(start: any, end: any, progress: number): any;
}

// ScrollTrigger types
interface ScrollTriggerStatic {
  create(config: ScrollTriggerConfig): ScrollTriggerInstance;
  refresh(): void;
  update(): void;
  getAll(): ScrollTriggerInstance[];
  getById(id: string): ScrollTriggerInstance | undefined;
  killAll(): void;
  kill(revert?: boolean): void;
  enable(): void;
  disable(): void;
  batch(targets: any, config: ScrollTriggerBatchConfig): ScrollTriggerInstance[];
  defaults(config: Partial<ScrollTriggerConfig>): void;
  scrollerProxy(element: any, config?: object): void;
  clearScrollMemory(): void;
  maxRefreshDelay(delay: number): void;
}

interface ScrollTriggerInstance {
  kill(revert?: boolean): void;
  enable(): void;
  disable(): void;
  refresh(): void;
  update(): void;
  progress: number;
  direction: number;
  isActive: boolean;
}

interface ScrollTriggerConfig {
  trigger?: string | Element;
  start?: string | number | Function;
  end?: string | number | Function;
  endTrigger?: string | Element;
  pin?: boolean | string | Element;
  pinnedContainer?: string | Element;
  pinSpacing?: boolean | string;
  pinReparent?: boolean;
  pinSpacer?: Element;
  scroller?: string | Element;
  scrub?: boolean | number;
  snap?: number | object | Function;
  animation?: GSAPTween | GSAPTimeline;
  horizontal?: boolean;
  anticipatePin?: number;
  fastScrollEnd?: boolean;
  preventOverlaps?: boolean | string;
  once?: boolean;
  id?: string;
  markers?: boolean | object;
  toggleClass?: string | object;
  toggleActions?: string;
  onEnter?: Function;
  onLeave?: Function;
  onEnterBack?: Function;
  onLeaveBack?: Function;
  onToggle?: Function;
  onUpdate?: Function;
  onRefresh?: Function;
  onRefreshInit?: Function;
  onSnapComplete?: Function;
  onScrubComplete?: Function;
  refreshPriority?: number;
  invalidateOnRefresh?: boolean;
}

interface ScrollTriggerBatchConfig extends ScrollTriggerConfig {
  interval?: number;
  batchMax?: number | Function;
}

export type {
  GSAP,
  GSAPTween,
  GSAPTimeline,
  GSAPTweenVars,
  GSAPTimelineVars,
  ScrollTriggerConfig,
  ScrollTriggerInstance,
  ScrollTriggerStatic
};
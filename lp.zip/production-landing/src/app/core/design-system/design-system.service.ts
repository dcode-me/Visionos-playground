import { Injectable } from '@angular/core';
import { DESIGN_TOKENS, DesignTokens } from './tokens/design-tokens';

/**
 * Design System Service
 * Provides programmatic access to design tokens for GSAP animations and dynamic styling
 */
@Injectable({
  providedIn: 'root'
})
export class DesignSystemService {
  private tokens: DesignTokens = DESIGN_TOKENS;

  /**
   * Get a color value by path
   * @param path - Dot notation path (e.g., 'brand.50', 'neutral.100')
   * @returns Hex color value
   */
  getColor(path: string): string {
    const parts = path.split('.');
    let value: any = this.tokens.colors;
    
    for (const part of parts) {
      value = value[part];
      if (!value) {
        console.warn(`Color token not found: ${path}`);
        return '#000000';
      }
    }
    
    return typeof value === 'string' ? value : value.hex || '#000000';
  }

  /**
   * Get a spacing value
   * @param size - Size key (e.g., 's', 'm', 'xl')
   * @returns Numeric pixel value (without 'px')
   */
  getSpacing(size: string): number {
    const spacing = this.tokens.spacing[size];
    if (!spacing) {
      console.warn(`Spacing token not found: ${size}`);
      return 0;
    }
    return spacing.numeric;
  }

  /**
   * Get a sizing value
   * @param size - Size key (e.g., 's', 'm', 'xl')
   * @returns Numeric pixel value (without 'px')
   */
  getSize(size: string): number {
    const sizing = this.tokens.sizing[size];
    if (!sizing) {
      console.warn(`Sizing token not found: ${size}`);
      return 0;
    }
    return sizing.numeric;
  }

  /**
   * Get a shadow value formatted for CSS/GSAP
   * @param type - Shadow type ('small', 'medium', 'large')
   * @returns CSS shadow string
   */
  getShadow(type: 'small' | 'medium' | 'large'): string {
    const shadows = this.tokens.shadows[type];
    if (!shadows) {
      console.warn(`Shadow token not found: ${type}`);
      return 'none';
    }
    
    return shadows
      .map(s => `${s.x}px ${s.y}px ${s.blur}px ${s.spread}px ${s.color}`)
      .join(', ');
  }

  /**
   * Get a border radius value
   * @param size - Radius size ('s', 'm', 'lrg', 'xl', 'round')
   * @returns Numeric pixel value
   */
  getBorderRadius(size: string): number {
    const radius = this.tokens.borderRadius[size as keyof typeof this.tokens.borderRadius];
    if (radius === undefined) {
      console.warn(`Border radius token not found: ${size}`);
      return 0;
    }
    return radius;
  }

  /**
   * Get typography properties
   * @param type - Typography type (e.g., 'headings.xl-medium', 'paragraphs.md-regular')
   * @returns Typography properties object
   */
  getTypography(type: string) {
    const [category, variant] = type.split('.');
    const typography = this.tokens.typography[category as keyof typeof this.tokens.typography];
    
    if (!typography || !typography[variant]) {
      console.warn(`Typography token not found: ${type}`);
      return null;
    }
    
    return typography[variant];
  }

  /**
   * Get an overlay color
   * @param type - Overlay type ('default', 'light', 'dark', 'subtle', 'heavy')
   * @returns RGBA color string
   */
  getOverlay(type: keyof typeof this.tokens.overlay = 'default'): string {
    return this.tokens.overlay[type] || this.tokens.overlay.default;
  }

  /**
   * Add opacity to a hex color
   * @param hexColor - Hex color value
   * @param opacity - Opacity value (0-1)
   * @returns RGBA color string
   */
  addOpacity(hexColor: string, opacity: number): string {
    const hex = hexColor.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
  }

  /**
   * Get all tokens (for debugging or advanced use)
   * @returns Complete design tokens object
   */
  getAllTokens(): DesignTokens {
    return this.tokens;
  }
}
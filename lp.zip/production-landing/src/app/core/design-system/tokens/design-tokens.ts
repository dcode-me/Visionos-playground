// BMO Design System - TypeScript Token Definitions

export interface ColorToken {
  hex: string;
  rgb: string;
  name?: string;
}

export interface ColorScale {
  '00'?: ColorToken | string;
  '10'?: ColorToken | string;
  '20'?: ColorToken | string;
  '30'?: ColorToken | string;
  '40'?: ColorToken | string;
  '50'?: ColorToken | string;
  '60'?: ColorToken | string;
  '70'?: ColorToken | string;
  '80'?: ColorToken | string;
  '90'?: ColorToken | string;
  '100'?: ColorToken | string;
  [key: string]: ColorToken | string | undefined;
}

export interface TypographyToken {
  family: string;
  weight: number;
  size: string;
  lineHeight: string;
  letterSpacing: string;
}

export interface SpacingToken {
  value: string;
  numeric: number;
}

export interface ShadowToken {
  x: number;
  y: number;
  blur: number;
  spread: number;
  color: string;
}

export interface DesignTokens {
  colors: {
    brand: ColorScale;
    neutral: ColorScale;
    positive: ColorScale;
    warning: ColorScale;
    negative: ColorScale;
    bmoLogo: {
      blue: string;
      red: string;
    };
    effect: {
      black: string;
      white: string;
    };
    dataviz: {
      primary: { [key: string]: string };
      primaryNode: { [key: string]: string };
      secondary: { [key: string]: string };
      secondaryNode: { [key: string]: string };
    };
  };
  typography: {
    headings: { [key: string]: TypographyToken };
    paragraphs: { [key: string]: TypographyToken };
  };
  spacing: { [key: string]: SpacingToken };
  sizing: { [key: string]: SpacingToken };
  shadows: {
    small: ShadowToken[];
    medium: ShadowToken[];
    large: ShadowToken[];
  };
  borderRadius: {
    s: number;
    m: number;
    lrg: number;
    xl: number;
    round: number;
  };
  overlay: {
    default: string;
    light: string;
    dark: string;
    subtle: string;
    heavy: string;
  };
}

// Design tokens constant
export const DESIGN_TOKENS: DesignTokens = {
  colors: {
    brand: {
      '00': '#F2F8FC',
      '10': '#E6F1F9',
      '20': '#C1E7FF',
      '30': '#73C3EB',
      '40': '#3391CB',
      '50': '#0075BE',
      '60': '#005E98',
      '70': '#005587',
      '80': '#002F4C',
      '90': '#002339',
      '100': '#001928'
    },
    neutral: {
      '00': '#FAFAFA',
      '10': '#F5F6F7',
      '20': '#EFF0F1',
      '30': '#D9DCDE',
      '40': '#C1C4C8',
      '50': '#838991',
      '60': '#646C76',
      '70': '#50565E',
      '80': '#32363B',
      '90': '#1E2023',
      '100': '#141618'
    },
    positive: {
      '00': '#EEF8F0',
      '10': '#CFEED6',
      '20': '#B0F1BE',
      '30': '#59E176',
      '40': '#00B826',
      '50': '#0F9B2C',
      '60': '#0C8024',
      '70': '#0A691E',
      '80': '#074A15',
      '90': '#05330E',
      '100': '#03240A'
    },
    warning: {
      '00': '#FFFEF3',
      '10': '#FFF5D6',
      '20': '#FFE6B5',
      '30': '#FFC369',
      '40': '#FF9233',
      '50': '#E86C00',
      '60': '#A34C00',
      '70': '#662F00',
      '80': '#4D2400',
      '90': '#3D1C00',
      '100': '#291300'
    },
    negative: {
      '00': '#FDF4F4',
      '10': '#FADEDE',
      '20': '#EDA6A6',
      '30': '#E37A7A',
      '40': '#D63737',
      '50': '#D11212',
      '60': '#A71A1A',
      '70': '#7D1414',
      '80': '#691111',
      '90': '#4D0C0C',
      '100': '#360909'
    },
    bmoLogo: {
      blue: '#0079C1',
      red: '#ED1C24'
    },
    effect: {
      black: '#000000',
      white: '#FFFFFF'
    },
    dataviz: {
      primary: {
        '25': '#B1E5FE',
        '35': '#00A9FB',
        '50': '#0075BE',
        '65': '#005789',
        '75': '#003758'
      },
      primaryNode: {
        '25': '#7395A5',
        '35': '#006EA3',
        '50': '#004068',
        '65': '#00304B',
        '75': '#001E30'
      },
      secondary: {
        '01': '#974BB7',
        '02': '#8988E1',
        '03': '#39D4B9',
        '04': '#CEE226',
        '05': '#FAA451'
      },
      secondaryNode: {
        '01': '#623177',
        '02': '#595992',
        '03': '#258A78',
        '04': '#869319',
        '05': '#A36B35'
      }
    }
  },
  typography: {
    headings: {
      '2xl-regular': {
        family: 'Heebo',
        weight: 200,
        size: '40px',
        lineHeight: '44px',
        letterSpacing: '0px'
      },
      '2xl-medium': {
        family: 'Heebo',
        weight: 500,
        size: '40px',
        lineHeight: '44px',
        letterSpacing: '0px'
      },
      'xl-regular': {
        family: 'Heebo',
        weight: 200,
        size: '36px',
        lineHeight: '40px',
        letterSpacing: '0px'
      },
      'xl-medium': {
        family: 'Heebo',
        weight: 500,
        size: '36px',
        lineHeight: '40px',
        letterSpacing: '0px'
      },
      'lg-regular': {
        family: 'Heebo',
        weight: 200,
        size: '32px',
        lineHeight: '36px',
        letterSpacing: '0px'
      },
      'lg-medium': {
        family: 'Heebo',
        weight: 500,
        size: '32px',
        lineHeight: '36px',
        letterSpacing: '0px'
      },
      'md-regular': {
        family: 'Heebo',
        weight: 200,
        size: '28px',
        lineHeight: '32px',
        letterSpacing: '0px'
      },
      'md-medium': {
        family: 'Heebo',
        weight: 500,
        size: '28px',
        lineHeight: '32px',
        letterSpacing: '0px'
      },
      'sm-regular': {
        family: 'Heebo',
        weight: 200,
        size: '24px',
        lineHeight: '28px',
        letterSpacing: '0px'
      },
      'sm-medium': {
        family: 'Heebo',
        weight: 500,
        size: '24px',
        lineHeight: '28px',
        letterSpacing: '0px'
      },
      'xs-regular': {
        family: 'Heebo',
        weight: 200,
        size: '20px',
        lineHeight: '24px',
        letterSpacing: '0px'
      },
      'xs-medium': {
        family: 'Heebo',
        weight: 500,
        size: '20px',
        lineHeight: '24px',
        letterSpacing: '0px'
      }
    },
    paragraphs: {
      'lg-regular': {
        family: 'Heebo',
        weight: 200,
        size: '18px',
        lineHeight: '28px',
        letterSpacing: '0px'
      },
      'lg-medium': {
        family: 'Heebo',
        weight: 500,
        size: '18px',
        lineHeight: '28px',
        letterSpacing: '0px'
      },
      'md-regular': {
        family: 'Heebo',
        weight: 200,
        size: '16px',
        lineHeight: '24px',
        letterSpacing: '0px'
      },
      'md-medium': {
        family: 'Heebo',
        weight: 500,
        size: '16px',
        lineHeight: '24px',
        letterSpacing: '0px'
      },
      'sm-regular': {
        family: 'Heebo',
        weight: 200,
        size: '14px',
        lineHeight: '20px',
        letterSpacing: '0px'
      },
      'sm-medium': {
        family: 'Heebo',
        weight: 500,
        size: '14px',
        lineHeight: '20px',
        letterSpacing: '0px'
      },
      'xs-regular': {
        family: 'Heebo',
        weight: 200,
        size: '12px',
        lineHeight: '20px',
        letterSpacing: '0px'
      },
      'xs-medium': {
        family: 'Heebo',
        weight: 500,
        size: '12px',
        lineHeight: '20px',
        letterSpacing: '0px'
      }
    }
  },
  spacing: {
    '3xs': { value: '4px', numeric: 4 },
    '2xs': { value: '8px', numeric: 8 },
    'xs': { value: '12px', numeric: 12 },
    's': { value: '16px', numeric: 16 },
    'm': { value: '24px', numeric: 24 },
    'lrg': { value: '32px', numeric: 32 },
    'xl': { value: '40px', numeric: 40 },
    '2xl': { value: '48px', numeric: 48 },
    '3xl': { value: '56px', numeric: 56 }
  },
  sizing: {
    '3xs': { value: '4px', numeric: 4 },
    '2xs': { value: '8px', numeric: 8 },
    'xs': { value: '12px', numeric: 12 },
    's': { value: '16px', numeric: 16 },
    'm': { value: '24px', numeric: 24 },
    'lrg': { value: '32px', numeric: 32 },
    'xl': { value: '40px', numeric: 40 },
    '2xl': { value: '48px', numeric: 48 },
    '3xl': { value: '56px', numeric: 56 }
  },
  shadows: {
    small: [
      { x: 0, y: 2, blur: 8, spread: -2, color: 'rgba(0, 0, 0, 0.06)' },
      { x: 0, y: 4, blur: 8, spread: -2, color: 'rgba(0, 0, 0, 0.10)' }
    ],
    medium: [
      { x: 0, y: 4, blur: 6, spread: -2, color: 'rgba(0, 0, 0, 0.03)' },
      { x: 0, y: 12, blur: 16, spread: -4, color: 'rgba(0, 0, 0, 0.08)' }
    ],
    large: [
      { x: 0, y: 8, blur: 8, spread: -4, color: 'rgba(0, 0, 0, 0.03)' },
      { x: 0, y: 20, blur: 24, spread: -4, color: 'rgba(0, 0, 0, 0.08)' }
    ]
  },
  borderRadius: {
    s: 4,
    m: 8,
    lrg: 12,
    xl: 16,
    round: 200
  },
  overlay: {
    default: 'rgba(20, 22, 24, 0.5)',
    light: 'rgba(255, 255, 255, 0.9)',
    dark: 'rgba(0, 0, 0, 0.7)',
    subtle: 'rgba(20, 22, 24, 0.3)',
    heavy: 'rgba(20, 22, 24, 0.8)'
  }
};
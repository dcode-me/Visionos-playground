import { Component, OnInit, OnDestroy, inject, HostListener, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslationService } from '../../../../core/services/translation.service';

@Component({
  selector: 'app-sticky-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sticky-header.component.html',
  styleUrls: ['./sticky-header.component.scss']
})
export class StickyHeaderComponent implements OnInit, OnDestroy {
  protected translationService = inject(TranslationService);

  // Reactive signals
  isScrolled = signal(false);
  showAllButtons = signal(true); // Start with all buttons visible (will change after Hero implementation)
  currentLanguage = this.translationService.language;

  // Button hover states
  hoveredButton = signal<string | null>(null);

  constructor() {
    // React to language changes
    effect(() => {
      // Future: Trigger GSAP text animation here when language changes
      this.currentLanguage(); // Track signal for reactivity
    });
  }

  ngOnInit(): void {
    // Check initial scroll position
    this.checkScroll();
  }

  ngOnDestroy(): void {
    // Clean up if any animations are added in the future
  }

  @HostListener('window:scroll', [])
  onWindowScroll(): void {
    this.checkScroll();
  }

  private checkScroll(): void {
    if (typeof window === 'undefined') return;
    const scrollPosition = window.scrollY || document.documentElement.scrollTop;
    this.isScrolled.set(scrollPosition > 50);
    
    // TODO: After Hero implementation, check if scrolled past hero CTAs
    // For now, all buttons are always visible
  }


  // Language toggle
  toggleLanguage(): void {
    this.translationService.toggleLanguage();
  }

  isEnglish(): boolean {
    return this.translationService.isEnglish();
  }

  isFrench(): boolean {
    return this.translationService.isFrench();
  }

  // Button interactions
  onButtonHover(buttonName: string): void {
    this.hoveredButton.set(buttonName);
  }

  onButtonLeave(): void {
    this.hoveredButton.set(null);
  }

  isButtonHovered(buttonName: string): boolean {
    return this.hoveredButton() === buttonName;
  }

  // Button click handlers
  onSubmitProduct(): void {
    // TODO: Implement scroll to form or open modal
  }

  onNewToBMO(): void {
    // TODO: Implement navigation or scroll
  }

  onSignIn(): void {
    // TODO: Implement sign in logic
  }
}
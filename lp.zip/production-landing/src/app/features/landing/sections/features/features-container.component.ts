import { Component, OnInit, OnDestroy, AfterViewInit, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureCardComponent, FeatureData } from './components/feature-card/feature-card.component';
import { GsapService } from '../../../../core/animations/gsap.service';
import { TranslationService } from '../../../../core/services/translation.service';

@Component({
  selector: 'app-features-container',
  standalone: true,
  imports: [CommonModule, FeatureCardComponent],
  templateUrl: './features-container.component.html',
  styleUrls: ['./features-container.component.scss']
})
export class FeaturesContainerComponent implements OnInit, AfterViewInit, OnDestroy {
  private gsapService = inject(GsapService);
  private translationService = inject(TranslationService);
  private scrollTriggers: any[] = [];

  // Reactive computed signals for translations
  sectionHeadline = computed(() => this.translationService.get('features.headline'));

  features = computed<FeatureData[]>(() => [
    {
      id: 'erp',
      type: 'erp',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.erp.title'),
      description: this.translationService.get('features.erp.description'),
      backgroundColor: 'gray',
      additionalItems: {
        items: [
          { label: this.translationService.get('features.erp.featured.xero'), icon: 'assets/icons/xero.svg' },
          { label: this.translationService.get('features.erp.featured.bmoSync'), icon: 'assets/icons/bmo.svg' }
        ]
      }
    },
    {
      id: 'api',
      type: 'api',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.api.title'),
      description: this.translationService.get('features.api.description'),
      backgroundColor: 'white',
      additionalItems: {
        title: this.translationService.get('features.api.availableTitle'),
        items: [
          { label: this.translationService.get('features.api.types.accountReporting') },
          { label: this.translationService.get('features.api.types.payments') },
          { label: this.translationService.get('features.api.types.pushNotifications') }
        ]
      }
    },
    {
      id: 'accounts',
      type: 'accounts',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.accounts.title'),
      description: this.translationService.get('features.accounts.description'),
      backgroundColor: 'gray',
      additionalItems: {
        title: this.translationService.get('features.accounts.availableTitle'),
        items: [
          { label: this.translationService.get('features.accounts.types.deposit') },
          { label: this.translationService.get('features.accounts.types.termInvestment') },
          { label: this.translationService.get('features.accounts.types.usCertificateDeposit') }
        ]
      }
    },
    {
      id: 'partners',
      type: 'partners',
      icon: 'assets/icons/app-integration.svg',
      title: this.translationService.get('features.partnerOffers.title'),
      description: this.translationService.get('features.partnerOffers.description'),
      backgroundColor: 'white'
    }
  ]);

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.initializeAnimations();
  }
  
  private async initializeAnimations(): Promise<void> {
    await this.gsapService.waitForGSAP();
    
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion) {
      return;
    }
    
    this.gsapService.from('.features-container__headline', {
      y: 30,
      opacity: 0,
      duration: 1,
      ease: 'power2.out',
      scrollTrigger: {
        trigger: '.features-container__headline',
        start: 'top 80%',
        once: true
      }
    });
    
    const featureCards = this.gsapService.gsap.utils.toArray('.feature-card');
    featureCards.forEach((card: any, index: number) => {
      const scrollTrigger = this.gsapService.createScrollTrigger({
        trigger: card,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          this.gsapService.from(card, {
            y: 50,
            opacity: 0,
            duration: 0.8,
            delay: index * 0.1,
            ease: 'power2.out'
          });
        }
      });
      this.scrollTriggers.push(scrollTrigger);
      
      const additionalItems = card.querySelectorAll('.feature-card__additional-item');
      if (additionalItems.length > 0) {
        const itemTrigger = this.gsapService.createScrollTrigger({
          trigger: card.querySelector('.feature-card__additional'),
          start: 'top 80%',
          once: true,
          onEnter: () => {
            this.gsapService.from(additionalItems, {
              x: -20,
              opacity: 0,
              duration: 0.6,
              stagger: 0.1,
              ease: 'power2.out'
            });
          }
        });
        this.scrollTriggers.push(itemTrigger);
      }
    });
    
    const placeholders = this.gsapService.gsap.utils.toArray('.animation-placeholder');
    placeholders.forEach((placeholder: any) => {
      const placeholderTrigger = this.gsapService.createScrollTrigger({
        trigger: placeholder,
        start: 'top 75%',
        once: true,
        onEnter: () => {
          this.gsapService.from(placeholder, {
            scale: 0.95,
            opacity: 0,
            duration: 1,
            ease: 'power2.out'
          });
        }
      });
      this.scrollTriggers.push(placeholderTrigger);
    });
  }

  ngOnDestroy(): void {
    this.scrollTriggers.forEach(trigger => trigger?.kill());
    this.scrollTriggers = [];
  }
}
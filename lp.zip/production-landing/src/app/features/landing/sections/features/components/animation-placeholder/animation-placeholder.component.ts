import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-animation-placeholder',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './animation-placeholder.component.html',
  styleUrls: ['./animation-placeholder.component.scss']
})
export class AnimationPlaceholderComponent {
  @Input() animationType!: 'erp' | 'api' | 'accounts';
  
  isAnimationReady = true;
  animationId: string = '';
}
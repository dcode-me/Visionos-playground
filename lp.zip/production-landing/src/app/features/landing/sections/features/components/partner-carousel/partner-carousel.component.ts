import { Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CatalogueDataService, Product } from '../../../../../landing/sections/hero-experience/services/catalogue-data.service';

@Component({
  selector: 'app-partner-carousel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './partner-carousel.component.html',
  styleUrls: ['./partner-carousel.component.scss']
})
export class PartnerCarouselComponent {
  private catalogueDataService = inject(CatalogueDataService);
  
  // Display partners duplicated for carousel animation - single optimized computed signal
  displayPartners = computed(() => {
    const partners = this.catalogueDataService.getProductsByCategory('partner-offers');
    // Duplicate partners for seamless carousel scrolling
    return [...partners, ...partners];
  });
  
  onPartnerClick(partner: Product, event?: Event): void {
    if (event) {
      event.preventDefault();
    }
    
    if (partner.url) {
      window.open(partner.url, '_blank', 'noopener,noreferrer');
    }
  }
  
  getPartnerUrl(partner: Product): string | undefined {
    return partner.url;
  }
}
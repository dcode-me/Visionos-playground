import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, inject, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy, Output, EventEmitter, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CatalogueDataService, Product } from '../../services/catalogue-data.service';
import { TranslationService } from '../../../../../../core/services/translation.service';
import { TranslatePipe } from '../../../../../../shared/pipes/translate.pipe';

declare var gsap: any;

// Category interface for type safety
interface Category {
  key: string;
  label: string;
  icon?: string;
}

@Component({
  selector: 'app-catalogue-carousel',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslatePipe],
  templateUrl: './catalogue-carousel.component.html',
  styleUrls: ['./catalogue-carousel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CatalogueCarouselComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('carouselElement') carouselElement!: ElementRef;
  @ViewChild('carouselTrack') carouselTrack!: ElementRef;
  @ViewChild('inlineSearchInput') inlineSearchInput!: ElementRef;
  @ViewChild('segmentedControl') segmentedControlRef!: ElementRef;
  
  @Output() productClick = new EventEmitter<Product>();
  
  protected catalogueDataService = inject(CatalogueDataService);
  protected translationService = inject(TranslationService);
  private cdr = inject(ChangeDetectorRef);
  
  // State
  currentCategory = 'app-integrations';
  searchQuery = '';
  isSearching = false;
  isInlineSearchExpanded = false;
  isLoading = false;
  products: Product[] = [];
  filteredProducts: Product[] = [];
  categories: Category[] = [];
  
  // Width preservation for segmented control
  segmentedControlWidth: number | null = null;
  private resizeObserver: ResizeObserver | null = null;
  
  // Navigation state
  canScrollPrev = false;
  canScrollNext = true;
  
  
  // Animation
  private animationDuration = 0.6;
  private searchDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private observer: IntersectionObserver | null = null;
  private reducedMotion = false;
  
  constructor() {
    // React to product data changes
    effect(() => {
      // Get categories from service (it's a computed signal, call it to get the value)
      this.categories = this.catalogueDataService.categories();
      
      // Load products
      this.products = this.catalogueDataService.getAllProducts();
      this.filteredProducts = [...this.products];
      
      // Trigger change detection since we're using OnPush
      this.cdr.markForCheck();
      
      // Re-observe cards after products change
      setTimeout(() => {
        this.reobserveCards();
        this.updateNavigationButtons();
      }, 100);
    });
  }
  
  ngOnInit(): void {
    // Check motion preference (only on client)
    if (typeof window !== 'undefined') {
      this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    
    // Initial load - in case products are already loaded
    const isLoading = this.catalogueDataService.isLoading();
    if (!isLoading) {
      this.categories = this.catalogueDataService.categories();
      this.products = this.catalogueDataService.getAllProducts();
      this.filteredProducts = [...this.products];
    }
  }
  
  ngAfterViewInit(): void {
    // Only run on client side
    if (typeof window === 'undefined') return;
    
    // Use requestAnimationFrame for accurate DOM measurements
    requestAnimationFrame(() => {
      // Capture the natural width of the segmented control after render
      if (this.segmentedControlRef) {
        this.captureSegmentedControlWidth();
        this.setupResizeObserver();
      }
      
      // Initialize visibility tracking for auto-tab sync
      if (!this.reducedMotion && typeof IntersectionObserver !== 'undefined') {
        this.initVisibilityTracking();
      }
      
      // Setup scroll listener for navigation buttons
      if (this.carouselTrack) {
        this.carouselTrack.nativeElement.addEventListener('scroll', () => {
          this.updateNavigationButtons();
        });
      }
      
      // Initial button state
      this.updateNavigationButtons();
    });
  }
  
  ngOnDestroy(): void {
    if (this.observer) {
      this.observer.disconnect();
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
  }
  
  // Tab handling
  onTabClick(category: string): void {
    if (category !== this.currentCategory) {
      this.scrollToCategory(category);
    }
  }
  
  scrollToCategory(category: string): void {
    if (this.isSearching) {
      this.clearSearch();
    }
    
    this.currentCategory = category;
    
    const targetCard = this.carouselElement.nativeElement.querySelector(
      `.carousel__card[data-category="${category}"]`
    );
    
    if (targetCard && this.carouselTrack) {
      const scrollPosition = targetCard.offsetLeft - this.carouselTrack.nativeElement.offsetLeft;
      this.scrollToPosition(scrollPosition);
    }
  }
  
  // Search handling
  onSearchInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.searchQuery = input.value;
    
    // Debounce search
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
    
    this.searchDebounceTimer = setTimeout(() => {
      this.handleSearch();
    }, 300);
  }
  
  handleSearch(): void {
    const query = this.searchQuery.trim().toLowerCase();
    
    if (query) {
      this.isSearching = true;
      this.filteredProducts = this.products.filter(product => {
        const searchableText = [
          product.title,
          product.description,
          ...(product.keywords || [])
        ].join(' ').toLowerCase();
        
        return searchableText.includes(query);
      });
      
      // Re-observe cards after search results change
      this.reobserveCards();
      // Trigger change detection for OnPush strategy
      this.cdr.markForCheck();
    } else {
      this.clearSearch();
    }
  }
  
  clearSearch(): void {
    this.searchQuery = '';
    this.isSearching = false;
    this.filteredProducts = [...this.products];
    
    // Critical: Re-observe cards after restoring products
    this.reobserveCards();
    // Trigger change detection for OnPush strategy
    this.cdr.markForCheck();
  }
  
  // Inline search methods
  expandInlineSearch(): void {
    // Ensure we have captured the width before expanding
    if (!this.segmentedControlWidth && this.segmentedControlRef) {
      this.captureSegmentedControlWidth();
    }
    this.isInlineSearchExpanded = true;
    // Focus input after animation completes
    setTimeout(() => {
      if (this.inlineSearchInput) {
        this.inlineSearchInput.nativeElement.focus();
      }
    }, 300);
  }
  
  collapseInlineSearch(): void {
    this.isInlineSearchExpanded = false;
    // Always clear search when closing
    this.searchQuery = '';
    this.clearSearch(); // This will call reobserveCards
  }
  
  onInlineSearchBlur(event: FocusEvent): void {
    // Don't collapse if clicking within the search field or close button
    const relatedTarget = event.relatedTarget as HTMLElement;
    if (relatedTarget?.closest('.ds-search-expanded')) {
      return;
    }
    
    // Delay to allow for click events to register
    setTimeout(() => {
      if (this.isInlineSearchExpanded && !this.searchQuery) {
        this.collapseInlineSearch();
      }
    }, 200);
  }
  
  onInlineSearchInput(event: Event): void {
    // Reuse existing search logic
    this.onSearchInput(event);
  }
  
  // Navigation - simplified with fixed card width
  navigatePrev(): void {
    if (!this.canScrollPrev || !this.carouselTrack) return;
    
    const track = this.carouselTrack.nativeElement;
    const cardWidth = 448; // Fixed card width from CSS
    const gap = 32; // DSM spacing-lrg from CSS (matches .carousel__track-inner gap)
    
    track.scrollBy({
      left: -(cardWidth + gap),
      behavior: 'smooth'
    });
  }
  
  navigateNext(): void {
    if (!this.canScrollNext || !this.carouselTrack) return;
    
    const track = this.carouselTrack.nativeElement;
    const cardWidth = 448; // Fixed card width from CSS
    const gap = 32; // DSM spacing-lrg from CSS (matches .carousel__track-inner gap)
    
    track.scrollBy({
      left: cardWidth + gap,
      behavior: 'smooth'
    });
  }
  
  private scrollToPosition(position: number): void {
    if (!this.carouselTrack) return;
    
    if (typeof gsap !== 'undefined' && !this.reducedMotion) {
      gsap.to(this.carouselTrack.nativeElement, {
        scrollLeft: position,
        duration: this.animationDuration,
        ease: 'power2.inOut'
      });
    } else {
      this.carouselTrack.nativeElement.scrollTo({
        left: position,
        behavior: 'smooth'
      });
    }
  }
  
  private updateNavigationButtons(): void {
    if (!this.carouselTrack) return;
    
    // Disable both buttons if no products to display
    if (this.getDisplayProducts().length === 0) {
      if (this.canScrollPrev || this.canScrollNext) {
        this.canScrollPrev = false;
        this.canScrollNext = false;
        this.cdr.markForCheck();
      }
      return;
    }
    
    const track = this.carouselTrack.nativeElement;
    const scrollLeft = track.scrollLeft;
    
    // Get spacer width to account for in calculations
    const spacer = track.querySelector('.carousel__spacer--left');
    const spacerWidth = spacer ? spacer.offsetWidth : 0;
    
    // Calculate actual content scroll area (excluding spacers)
    const contentWidth = track.scrollWidth - (spacerWidth * 2); // Subtract both spacers
    const maxScroll = contentWidth - track.clientWidth + (spacerWidth * 2);
    
    // Check if we can scroll (accounting for spacers)
    // Can go left if we've scrolled past the left spacer area
    const prevState = scrollLeft > spacerWidth + 1;
    // Can go right if we haven't reached the end of actual content
    const nextState = scrollLeft < maxScroll - spacerWidth - 1;
    
    if (this.canScrollPrev !== prevState || this.canScrollNext !== nextState) {
      this.canScrollPrev = prevState;
      this.canScrollNext = nextState;
      this.cdr.markForCheck();
    }
  }
  
  // Visibility tracking for tab sync
  private initVisibilityTracking(): void {
    if (!this.carouselTrack || typeof IntersectionObserver === 'undefined') return;
    
    const options = {
      root: this.carouselTrack.nativeElement,
      rootMargin: '0px',
      threshold: 0.5
    };
    
    this.observer = new IntersectionObserver((entries) => {
      if (this.isSearching) return;
      
      const visibleEntries = entries.filter(entry => entry.isIntersecting);
      if (visibleEntries.length === 0) return;
      
      // Find most visible category
      const categoryVisibility: { [key: string]: number } = {};
      
      visibleEntries.forEach(entry => {
        const category = (entry.target as HTMLElement).dataset['category'];
        if (category) {
          categoryVisibility[category] = (categoryVisibility[category] || 0) + entry.intersectionRatio;
        }
      });
      
      let mostVisibleCategory = this.currentCategory;
      let highestRatio = 0;
      
      Object.entries(categoryVisibility).forEach(([category, ratio]) => {
        if (ratio > highestRatio) {
          highestRatio = ratio;
          mostVisibleCategory = category;
        }
      });
      
      if (mostVisibleCategory !== this.currentCategory) {
        this.currentCategory = mostVisibleCategory;
        this.cdr.markForCheck();
      }
    }, options);
    
    // Observe all cards initially
    this.reobserveCards();
  }
  
  // Re-observe cards when product list changes (after search/filter)
  private reobserveCards(): void {
    if (!this.observer || !this.carouselElement) return;
    
    // Disconnect all existing observations
    this.observer.disconnect();
    
    // Wait for DOM to update with new cards
    setTimeout(() => {
      const cards = this.carouselElement?.nativeElement.querySelectorAll('.carousel__card');
      
      cards?.forEach((card: Element) => {
        this.observer?.observe(card);
      });
    }, 100); // Small delay to ensure DOM has updated
  }
  
  // Get products for display
  getDisplayProducts(): Product[] {
    if (this.isSearching && this.searchQuery) {
      return this.filteredProducts;
    }
    return this.products;
  }
  
  // Get icon for product
  getProductIcon(product: Product): string {
    return this.catalogueDataService.getProductIcon(product);
  }
  
  // Get inline SVG for category icon (for tabs)
  getCategoryIcon(category: string): string {
    // These will be inline SVGs in the template
    return category;
  }
  
  // Track by function for performance
  trackByProductId(_index: number, product: Product): string {
    return product.id;
  }
  
  
  trackByCategoryKey(_index: number, category: Category): string {
    return category.key;
  }
  
  // Width preservation methods
  private captureSegmentedControlWidth(): void {
    if (!this.segmentedControlRef) return;
    
    const element = this.segmentedControlRef.nativeElement;
    const computedWidth = element.getBoundingClientRect().width;
    
    // Only capture if we have a valid width and not already expanded
    if (computedWidth > 0 && !this.isInlineSearchExpanded) {
      this.segmentedControlWidth = computedWidth;
    }
  }
  
  private setupResizeObserver(): void {
    if (!this.segmentedControlRef || typeof ResizeObserver === 'undefined') return;
    
    this.resizeObserver = new ResizeObserver((entries) => {
      // Only recapture width when not expanded
      if (!this.isInlineSearchExpanded) {
        for (const entry of entries) {
          const width = entry.contentRect.width;
          if (width > 0) {
            this.segmentedControlWidth = width;
          }
        }
      }
    });
    
    this.resizeObserver.observe(this.segmentedControlRef.nativeElement);
  }
  
  // Get the width style for the segmented control
  getSegmentedControlWidth(): string | null {
    // Apply fixed width only when search is expanded
    if (this.isInlineSearchExpanded && this.segmentedControlWidth) {
      return `${this.segmentedControlWidth}px`;
    }
    return null;
  }
  
  // Handle card click
  onCardClick(eventOrProduct: Event | Product, product?: Product): void {
    // Handle both signatures: (product) and (event, product)
    if (eventOrProduct instanceof Event) {
      // Called with (event, product) from keydown.space
      eventOrProduct.preventDefault(); // Prevent page scroll on space
      if (product) {
        this.handleProductClick(product);
      }
    } else {
      // Called with (product) from click or keydown.enter
      this.handleProductClick(eventOrProduct);
    }
  }
  
  private handleProductClick(product: Product): void {
    this.productClick.emit(product);
    
    // Navigate to product URL if available
    if (product.url) {
      window.open(product.url, '_blank', 'noopener,noreferrer');
    }
  }
}
import { Injectable, signal, computed, inject, effect } from '@angular/core';
import { TranslationService, Language } from '../../../../../core/services/translation.service';

export interface Product {
  id: string;
  title: string;
  name?: string;
  description: string;
  url?: string;
  category: string;
  categoryLabel: string;
  iconName?: string;
  keywords: string[];
  tags?: string[];
  partnerCategory?: string;
}

export interface Category {
  key: string;
  label: string;
  products?: Product[];
}

interface ProductData {
  categories: Category[];
  products: Product[];
}

@Injectable({
  providedIn: 'root'
})
export class CatalogueDataService {
  private translationService = inject(TranslationService);
  
  // Signal for current category filter
  private currentCategory = signal<string>('app-integrations');
  
  // Signal for search query
  private searchQuery = signal<string>('');
  
  // Signal for loading state
  private isLoadingProducts = signal<boolean>(false);
  
  // Signal for product data
  private productData = signal<ProductData>({
    categories: [],
    products: []
  });
  
  // Categories configuration - computed from loaded data
  readonly categories = computed<Category[]>(() => {
    const data = this.productData();
    if (!data.categories || data.categories.length === 0) {
      // Return default categories while loading
      return [
        { key: 'app-integrations', label: 'App Integrations' },
        { key: 'apis', label: 'APIs' },
        { key: 'accounts', label: 'Accounts' },
        { key: 'partner-offers', label: 'Partner offers' }
      ];
    }
    
    // Enrich categories with their products
    return data.categories.map(cat => ({
      ...cat,
      products: data.products.filter(p => p.category === cat.key)
    }));
  });
  
  // Public observables
  currentCategoryKey = this.currentCategory.asReadonly();
  searchQueryValue = this.searchQuery.asReadonly();
  isLoading = this.isLoadingProducts.asReadonly();
  
  // Computed filtered products
  filteredProducts = computed(() => {
    const query = this.searchQuery().toLowerCase();
    const data = this.productData();
    
    if (!data.products) return [];
    
    let filtered = data.products;
    
    // Filter by search query if exists
    if (query) {
      filtered = filtered.filter(product => {
        const searchableText = [
          product.title,
          product.description,
          ...product.keywords
        ].join(' ').toLowerCase();
        
        return searchableText.includes(query);
      });
    }
    
    return filtered;
  });
  
  constructor() {
    // Load products for initial language
    this.loadProducts(this.translationService.getCurrentLanguage());
    
    // React to language changes
    effect(() => {
      const currentLang = this.translationService.language();
      this.loadProducts(currentLang);
    });
  }
  
  /**
   * Load products from JSON file based on language
   */
  private async loadProducts(language: Language): Promise<void> {
    // Only fetch in browser environment
    if (typeof window === 'undefined') {
      return;
    }
    
    this.isLoadingProducts.set(true);
    
    try {
      const url = `/assets/data/products-${language}.json`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Failed to load products for language: ${language}, status: ${response.status}`);
      }
      
      const data: ProductData = await response.json();
      
      // Ensure each product has a name property (fallback to title)
      const productsWithNames = data.products.map(product => ({
        ...product,
        name: product.name || product.title
      }));
      
      this.productData.set({
        categories: data.categories,
        products: productsWithNames
      });
      
    } catch (error) {
      console.error(`Failed to load products for ${language}:`, error);
      
      // Fall back to empty data
      this.productData.set({
        categories: [],
        products: []
      });
    } finally {
      this.isLoadingProducts.set(false);
    }
  }
  
  // Get products by category
  getProductsByCategory(category: string): Product[] {
    if (this.searchQuery()) {
      return this.filteredProducts();
    }
    const data = this.productData();
    return data.products.filter(p => p.category === category);
  }
  
  // Get all products (for initial render)
  getAllProducts(): Product[] {
    return this.productData().products;
  }
  
  // Set current category
  setCategory(category: string): void {
    this.currentCategory.set(category);
    // Clear search when changing category
    if (this.searchQuery()) {
      this.searchQuery.set('');
    }
  }
  
  // Set search query
  setSearchQuery(query: string): void {
    this.searchQuery.set(query);
  }
  
  // Clear search
  clearSearch(): void {
    this.searchQuery.set('');
  }
  
  // Get category by key
  getCategoryByKey(key: string): Category | undefined {
    return this.categories().find(c => c.key === key);
  }
  
  getProductByTitle(title: string): Product | undefined {
    const data = this.productData();
    return data.products.find(p => 
      p.title.toLowerCase() === title.toLowerCase() || 
      p.name?.toLowerCase() === title.toLowerCase()
    );
  }
  
  // Get icon path for product
  getProductIcon(product: Product): string {
    // Specific product icons
    const productIconMap: { [key: string]: string } = {
      'bmo-sync': '/assets/icons/bmo.svg',
      'xero': '/assets/icons/xero.svg',
      'adp': '/assets/icons/adp.svg',
      'moneris': '/assets/icons/moneris.svg'
    };
    
    // Check if product has specific icon
    if (productIconMap[product.id]) {
      return productIconMap[product.id];
    }
    
    // Third-party partner offers temporarily use xero icon
    if (product.category === 'partner-offers') {
      return '/assets/icons/xero.svg';
    }
    
    // Category-based icons as fallback
    const categoryIconMap: { [key: string]: string } = {
      'app-integrations': '/assets/icons/app-integration.svg',
      'accounts': '/assets/icons/accounts.svg',
      'apis': '/assets/icons/api.svg'
    };
    
    return categoryIconMap[product.category] || '/assets/icons/default.svg';
  }
}
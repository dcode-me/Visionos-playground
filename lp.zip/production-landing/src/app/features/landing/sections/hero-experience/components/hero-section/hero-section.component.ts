import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeroContentComponent } from './components/hero-content/hero-content.component';
import { HeroIllustrationComponent } from './components/hero-illustration/hero-illustration.component';
import { GsapService } from '../../../../../../core/animations/gsap.service';

@Component({
  selector: 'app-hero-section',
  standalone: true,
  imports: [CommonModule, HeroContentComponent, HeroIllustrationComponent],
  templateUrl: './hero-section.component.html',
  styleUrls: ['./hero-section.component.scss']
})
export class HeroSectionComponent implements OnInit {
  private gsapService = inject(GsapService);

  ngOnInit(): void {
    this.initializeEntryAnimations();
  }

  private async initializeEntryAnimations(): Promise<void> {
    await this.gsapService.waitForGSAP();

    // Wait for next tick to ensure DOM is ready
    setTimeout(() => {
      // Staggered entry animation for hero content
      const timeline = this.gsapService.gsap.timeline({
        defaults: {
          duration: 0.8,
          ease: 'power2.out'
        }
      });

      // Check if elements exist before animating
      const contentElement = document.querySelector('.hero-section__content');
      const illustrationElement = document.querySelector('.hero-section__illustration');

      if (contentElement) {
        timeline.from(contentElement, {
          opacity: 0,
          y: 30,
          duration: 1
        });
      }

      if (illustrationElement) {
        timeline.from(illustrationElement, {
          opacity: 0,
          scale: 0.95,
          duration: 1
        }, '-=0.5');
      }
    }, 0);
  }
}
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hero-illustration',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hero-illustration.component.html',
  styleUrls: ['./hero-illustration.component.scss']
})
export class HeroIllustrationComponent {
  // Placeholder component for future isometric tile illustration
  // Will be implemented with interactive SVG tiles representing product categories
}
import { Component, OnInit, OnDestroy, AfterViewInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeroSectionComponent } from './components/hero-section/hero-section.component';
import { CatalogueCarouselComponent } from './components/catalogue-carousel/catalogue-carousel.component';
import { GsapService } from '../../../../core/animations/gsap.service';

@Component({
  selector: 'app-hero-experience',
  standalone: true,
  imports: [CommonModule, HeroSectionComponent, CatalogueCarouselComponent],
  templateUrl: './hero-experience.component.html',
  styleUrls: ['./hero-experience.component.scss']
})
export class HeroExperienceComponent implements OnInit, AfterViewInit, OnDestroy {
  private gsapService = inject(GsapService);
  private scrollTrigger: any;

  ngOnInit(): void {
    // Component initialization
  }

  ngAfterViewInit(): void {
    this.initializeAnimations();
  }

  ngOnDestroy(): void {
    this.cleanupAnimations();
  }

  private async initializeAnimations(): Promise<void> {
    await this.gsapService.waitForGSAP();

    // Initialize smooth scroll for the entire experience
    this.gsapService.initSmoothScroll('.hero-experience__content');

    // Create background fade animation
    this.scrollTrigger = this.gsapService.createScrollTrigger({
      trigger: '.catalogue-section',
      start: 'top 80%',
      end: 'top 20%',
      scrub: true,
      animation: this.gsapService.gsap.to('.hero-experience__background', {
        opacity: 0.1,
        scale: 1.05,
        duration: 1
      })
    });

    // Hero to catalogue transition animation
    const timeline = this.gsapService.gsap.timeline({
      scrollTrigger: {
        trigger: '.hero-section',
        start: 'bottom 90%',
        end: 'bottom 10%',
        scrub: 1
      }
    });

    timeline.to('.hero-section', {
      opacity: 0.8,
      y: -20,
      duration: 0.5
    });
  }

  private cleanupAnimations(): void {
    if (this.scrollTrigger) {
      this.scrollTrigger.kill();
    }
    this.gsapService.cleanup();
  }
}
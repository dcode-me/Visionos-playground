import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslatePipe } from '../../../../../../../../shared/pipes/translate.pipe';

@Component({
  selector: 'app-hero-content',
  standalone: true,
  imports: [CommonModule, TranslatePipe],
  templateUrl: './hero-content.component.html',
  styleUrls: ['./hero-content.component.scss']
})
export class HeroContentComponent {
  // Button hover states
  isPrimaryHovered = signal(false);
  isSecondaryHovered = signal(false);
  
  // CTA actions
  onPrimaryCtaClick(): void {
    // TODO: Implement navigation to sign in
  }
  
  onSecondaryCtaClick(): void {
    // TODO: Implement navigation to contact
  }
  
  // Hover handlers
  onPrimaryHover(isHovered: boolean): void {
    this.isPrimaryHovered.set(isHovered);
  }
  
  onSecondaryHover(isHovered: boolean): void {
    this.isSecondaryHovered.set(isHovered);
  }
}
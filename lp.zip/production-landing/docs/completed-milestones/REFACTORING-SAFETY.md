# Refactoring Safety Checklist

## Current Working Features (Must Preserve)

### ✅ Core Carousel Functionality
1. **Product Display**
   - Shows all products in horizontal scroll
   - Cards have proper styling with shadows
   - Category colors on top border
   - Product icons display correctly

2. **Navigation**
   - Left/right arrow buttons work
   - Arrows disable at start/end
   - Smooth scroll animation
   - Proper card alignment

3. **Tab Navigation**
   - 4 category tabs display
   - Active tab highlighted
   - Tab click scrolls to category
   - Auto-sync when scrolling

4. **Inline Search**
   - Search button expands inline
   - Tabs collapse during search
   - X button closes search
   - Search filters products
   - "No results" message displays
   - Clearing search restores products

5. **Safari Compatibility**
   - Cards align properly at end
   - No scroll-snap issues
   - Spacers work correctly

6. **Responsive Design**
   - Edge-to-edge scrolling
   - Proper container alignment
   - Mobile responsive

## Critical Code Sections (Handle with Care)

### 1. IntersectionObserver Setup (Lines 328-391)
```typescript
private initVisibilityTracking(): void
private reobserveCards(): void
```
**Critical**: Must call `reobserveCards()` after search changes

### 2. Spacer Implementation (HTML)
```html
<div class="carousel__spacer carousel__spacer--left"></div>
<!-- Products here -->
<div class="carousel__spacer carousel__spacer--right"></div>
```
**Critical**: Spacers must be direct children of .carousel__track

### 3. Scroll-Snap CSS
```scss
.carousel__track {
  > * {
    scroll-snap-align: start;
  }
}
.carousel__spacer {
  scroll-snap-align: none !important;
}
```
**Critical**: This hierarchy fixes Safari

### 4. Width Preservation Logic (Lines 405-445)
```typescript
private captureSegmentedControlWidth(): void
private setupResizeObserver(): void
getSegmentedControlWidth(): string | null
```
**Critical**: Prevents layout shift during search expansion

## Testing Matrix After Each Milestone

| Feature | Desktop Chrome | Desktop Safari | Mobile |
|---------|---------------|----------------|---------|
| Load | ✓ | ✓ | ✓ |
| Scroll | ✓ | ✓ | ✓ |
| Arrows | ✓ | ✓ | N/A |
| Tabs | ✓ | ✓ | ✓ |
| Search | ✓ | ✓ | ✓ |
| Tab Sync | ✓ | ✓ | ✓ |

## Red Flags (Stop if you see these)

1. **Build Errors**
   - Missing imports
   - TypeScript errors
   - Module not found

2. **Runtime Errors**
   - Cannot read property of undefined
   - ViewChild errors
   - Observer not defined

3. **Visual Breaks**
   - Cards not aligned
   - Search not expanding
   - Tabs not switching
   - Arrows always disabled

4. **Safari Specific**
   - Cards bunched at end
   - Scroll snapping to wrong position
   - Spacers not working

## Rollback Commands

```bash
# If current milestone fails
git status                    # Check what changed
git diff                      # See exact changes
git checkout -- <filename>    # Undo specific file
git reset --hard HEAD         # Nuclear option: undo all

# If multiple milestones fail
git log --oneline -5          # See recent commits
git reset --hard <commit-id>  # Go back to specific milestone
```

## File Backup Commands (Before Starting)

```bash
# Create safety backup
cp -r src/app/features/landing/sections/hero-experience ~/Desktop/hero-experience-backup

# Verify backup
ls -la ~/Desktop/hero-experience-backup
```

## Known Working State Indicators

### Console Output (Expected)
```
✔ Building...
Application bundle generation complete
  ➜  Local:   http://localhost:4200/
```

### Browser Console (Should be clean)
- No red errors
- No yellow warnings about missing elements
- No TypeScript errors

### Visual Check
- Grid background visible
- Cards in neat row
- Smooth scrolling
- Search expands/collapses smoothly

## Emergency Contacts
- Last known good commit: `844bf45`
- Safe branch: `main`
- Refactor branch: `refactor/catalogue-carousel-cleanup`

## Remember
1. Test after EVERY change
2. Commit only working code
3. Small changes are safer
4. Keep dev tools open
5. Watch the terminal for errors
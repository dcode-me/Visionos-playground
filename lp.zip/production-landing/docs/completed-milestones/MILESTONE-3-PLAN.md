# Milestone 3: Remove Unused Components - Detailed Plan

## Overview
Remove the unused `catalogue-header` component that's not imported or used anywhere in the application.

## Current State Analysis

### Component Location
`/src/app/features/landing/sections/hero-experience/components/catalogue-section/components/catalogue-header/`

### Files to Delete
1. `catalogue-header.component.ts` (81 lines)
2. `catalogue-header.component.html` (size unknown)
3. `catalogue-header.component.scss` (size unknown)

### Component Details
- **Selector**: `app-catalogue-header`
- **Purpose**: Alternative header implementation with categories and search
- **Features**: Category tabs, expandable search, signals-based state
- **Dependencies**: TranslationService, CatalogueDataService
- **Outputs**: categoryChange, searchChange events

## Verification Checks

### Import Search Results
```bash
grep -r "catalogue-header\|CatalogueHeaderComponent" src/
```
**Result**: Only found in its own 3 files - NOT imported anywhere

### Parent Component Check
- `catalogue-section.component.ts` - Does NOT import catalogue-header
- `catalogue-carousel.component.ts` - Does NOT import catalogue-header
- No references in any other components

### Template Usage Check
```bash
grep -r "<app-catalogue-header" src/
```
**Result**: Only in its own template file

## Changes Required

### 1. Delete Component Folder
```bash
rm -rf src/app/features/landing/sections/hero-experience/components/catalogue-section/components/catalogue-header
```

### 2. Files Being Removed
- `catalogue-header.component.ts` - Complete component logic
- `catalogue-header.component.html` - Component template
- `catalogue-header.component.scss` - Component styles

## Impact Analysis

### No Impact Expected On
✅ Catalogue carousel functionality (separate component)
✅ Current header/navigation in carousel
✅ Search functionality (carousel has its own)
✅ Category switching (carousel has its own)
✅ Build process (component not imported)
✅ Application routing
✅ Other components

### Benefits
- Removes ~150+ lines of unused code
- Eliminates confusion about which header to use
- Simplifies component structure
- Reduces maintenance burden

## Risk Assessment
- **Risk Level**: VERY LOW
- **Why**: Component is completely isolated and unused
- **Mitigation**: Can be restored from git history if needed

## Testing Requirements

After deletion:
1. ✅ Build succeeds
2. ✅ No TypeScript errors
3. ✅ Catalogue carousel still works
4. ✅ Search functionality intact
5. ✅ Category tabs work
6. ✅ No console errors

## Commit Message
```
refactor(milestone-3): remove unused catalogue-header component

- Delete entire catalogue-header folder
- Component was not imported or used anywhere
- Reduces codebase by ~150+ lines
```

## Rollback Plan
If issues arise:
```bash
git reset --hard HEAD~1
git push --force-with-lease origin refactor/catalogue-carousel-cleanup
```

## Final Checklist Before Execution
- [x] Component not imported anywhere
- [x] Component not used in any templates
- [x] No services depend on it
- [x] No other components extend it
- [x] Safe to delete entire folder
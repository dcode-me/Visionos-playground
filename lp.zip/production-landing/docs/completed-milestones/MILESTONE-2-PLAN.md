# Milestone 2: Remove Unused Search Toggle - Detailed Plan

## Overview
Remove the standalone search implementation since `useInlineSearch` is permanently set to `true`. The inline search is the only implementation being used.

## Current State Analysis

### TypeScript File (catalogue-carousel.component.ts)
1. **Line 31**: `useInlineSearch = true;` - Toggle variable (always true, never changes)
2. **Line 20**: `@ViewChild('searchInput') searchInput!: ElementRef;` - ViewChild for standalone search
3. **Line 37**: `isSearchExpanded = false;` - State for standalone search expansion
4. **Line 77**: Conditional check `if (this.useInlineSearch && this.segmentedControlRef)`
5. **Lines 172-174**: `onSearchFocus()` method - only used by standalone search
6. **Lines 176-186**: `onSearchBlur()` method - only used by standalone search  
7. **Lines 198-203**: `collapseSearch()` method - references both searches
8. **Line 192**: `collapseSearch()` call in `clearSearch()`
9. **Lines 200-202**: References to `searchInput` ViewChild

### HTML Template (catalogue-carousel.component.html)
1. **Line 12**: `@if (useInlineSearch) {` - Conditional block start
2. **Lines 13-73**: Inline search implementation (KEEP)
3. **Line 74**: `} @else {` - Else block start
4. **Lines 75-124**: Standalone search implementation (REMOVE)
5. **Line 125**: `}` - End of conditional

### SCSS Styles (catalogue-carousel.component.scss)
1. **Lines 300-311**: `.carousel__search` block (REMOVE)
2. **Lines 312-323**: `.carousel__search-results` block (CHECK if used)
3. **Lines 324-347**: `.search-field` block (REMOVE)
4. **Lines 348-355**: `.search-icon` styles (REMOVE)
5. **Lines 356-373**: `.search-input` styles (REMOVE)
6. **Lines 374-399**: `.close-btn` styles (REMOVE)
7. **Line 704**: `.carousel__search` in media query (REMOVE)
8. **Line 752**: `.search-input` in media query (REMOVE)

## Changes Required

### 1. TypeScript Changes
```typescript
// REMOVE:
- Line 20: @ViewChild('searchInput') searchInput!: ElementRef;
- Line 31: useInlineSearch = true;
- Line 37: isSearchExpanded = false;  ✅ SAFE - only used by standalone
- Lines 172-174: onSearchFocus() method
- Lines 176-186: onSearchBlur() method
- Lines 198-203: collapseSearch() method entirely

// MODIFY:
- Line 77: Remove conditional, keep just the body
- Line 192: Remove the collapseSearch() call (not needed for inline)
```

**Note:** `isInlineSearchExpanded` is SEPARATE and stays - it's used by inline search

### 2. HTML Template Changes
```html
// REMOVE:
- Line 12: @if condition
- Lines 74-125: Entire @else block including closing brace

// KEEP:
- Lines 13-73: Inline search implementation (remove indentation)
```

### 3. SCSS Changes
```scss
// REMOVE these complete blocks:
- .carousel__search (lines 300-311)
- .search-field (lines 324-347)  
- .search-icon (lines 348-355)
- .search-input (lines 356-373)
- .close-btn (lines 374-399)

// REMOVE from media queries:
- .carousel__search reference (line 704)
- .search-input reference (line 752)

// CHECK:
- .carousel__search-results - verify if used elsewhere
```

## Impact Analysis

### Methods That Will Be Affected
1. `clearSearch()` - needs to call `collapseInlineSearch()` instead
2. `collapseSearch()` - can be removed entirely
3. `ngAfterViewInit()` - simplify line 77 condition

### No Impact Expected On
✅ Inline search functionality (primary implementation)
✅ Tab navigation
✅ Product filtering
✅ Carousel navigation
✅ Category switching
✅ Search query handling

## Testing Requirements

After implementation:
1. ✅ Inline search expands when clicked
2. ✅ Search filters products correctly
3. ✅ Clear button works
4. ✅ Search collapses when empty and loses focus
5. ✅ Tabs hide during search
6. ✅ No TypeScript errors
7. ✅ No console errors
8. ✅ Build succeeds
9. ✅ Mobile responsive works

## Risk Assessment
- **Risk Level**: LOW-MEDIUM
- **Why**: Removing unused code that's never executed (always takes the @if path)
- **Mitigation**: The inline search is fully functional and tested

## File Size Impact
Estimated reduction:
- HTML: ~50 lines removed
- TypeScript: ~30 lines removed  
- SCSS: ~100 lines removed
- Total: ~180 lines of unused code removed

## Commit Message
```
refactor(milestone-2): remove standalone search, keep inline only

- Remove useInlineSearch toggle (always true)
- Remove standalone search HTML template code
- Remove unused ViewChild and methods
- Clean up related SCSS styles
- Simplify conditional logic
```

## Rollback Plan
If issues arise:
```bash
git reset --hard HEAD~1
git push --force-with-lease origin refactor/catalogue-carousel-cleanup
```

## Final Checklist Before Execution
- [ ] All standalone search code identified
- [ ] No dependencies on removed code
- [ ] Inline search remains intact
- [ ] CSS classes mapped correctly
- [ ] Build will succeed after changes
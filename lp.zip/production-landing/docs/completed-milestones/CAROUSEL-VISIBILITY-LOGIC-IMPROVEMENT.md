# Carousel Visibility Logic - Future Improvement

## Current Implementation Issue

### Location
File: `src/app/features/landing/sections/hero-experience/components/catalogue-carousel/catalogue-carousel.component.ts`
Method: `initVisibilityTracking()` (lines 304-346)

### Current Flawed Logic (lines 319-337)

```typescript
// Find most visible category
const categoryVisibility: { [key: string]: number } = {};

visibleEntries.forEach(entry => {
  const category = (entry.target as HTMLElement).dataset['category'];
  if (category) {
    categoryVisibility[category] = (categoryVisibility[category] || 0) + entry.intersectionRatio;
  }
});

// Picks category with highest sum
let mostVisibleCategory = this.currentCategory;
let highestRatio = 0;

Object.entries(categoryVisibility).forEach(([category, ratio]) => {
  if (ratio > highestRatio) {
    highestRatio = ratio;
    mostVisibleCategory = category;
  }
});
```

## The Problem

The current logic **sums up all visibility ratios per category** instead of identifying **which single card is most prominent**.

### Example Scenarios

#### Scenario 1: Works Correctly
```
[---------- Viewport ----------]
[Xero 30%][BMO 80%][QB 80%][API1 20%]
   ^app      ^app     ^app     ^api
```

**Current logic calculates:**
- app-integration: 0.3 + 0.8 + 0.8 = **1.9 total**
- api: 0.2 = **0.2 total**
- Result: Highlights "app-integration" ✓ CORRECT

#### Scenario 2: Potentially Incorrect
```
[---------- Viewport ----------]
     [Xero 10%][BMO 20%][API1 90%][API2 30%]
        ^app      ^app     ^api      ^api
```

**Current logic calculates:**
- app-integration: 0.1 + 0.2 = **0.3 total**
- api: 0.9 + 0.3 = **1.2 total**
- Result: Highlights "api" ✓ Happens to be correct

#### Scenario 3: Definitely Incorrect
```
[---------- Viewport ----------]
[App1 25%][App2 25%][App3 25%][App4 25%][App5 25%] | [API1 95%]
   ^app      ^app      ^app      ^app      ^app     |   ^api
```

**Current logic calculates:**
- app-integration: 5 × 0.25 = **1.25 total**
- api: 0.95 = **0.95 total**
- Result: Highlights "app-integration" ❌ WRONG!
- Expected: Should highlight "api" since API1 is 95% visible

## What Users Expect

Users expect the tab to highlight based on:
1. **The leftmost highly visible card** (for LTR reading direction)
2. **Or the single most prominent card** in the center of viewport
3. **Not the sum of all partial visibilities**

## Proposed Better Implementation

### Option 1: Single Most Visible Card
```typescript
// Find the single most visible card
let mostVisibleCard: Element | null = null;
let highestRatio = 0.4; // Minimum threshold to be considered "visible"

visibleEntries.forEach(entry => {
  if (entry.intersectionRatio > highestRatio) {
    highestRatio = entry.intersectionRatio;
    mostVisibleCard = entry.target;
  }
});

if (mostVisibleCard) {
  const category = (mostVisibleCard as HTMLElement).dataset['category'];
  if (category && category !== this.currentCategory) {
    this.currentCategory = category;
    this.cdr.markForCheck();
  }
}
```

### Option 2: Leftmost Visible Card (Reading Order)
```typescript
// Find the leftmost card that's sufficiently visible
let selectedCard: Element | null = null;
let leftmostPosition = Infinity;
const MIN_VISIBILITY = 0.3; // 30% minimum to be considered

visibleEntries
  .filter(entry => entry.intersectionRatio >= MIN_VISIBILITY)
  .forEach(entry => {
    const rect = entry.target.getBoundingClientRect();
    if (rect.left < leftmostPosition) {
      leftmostPosition = rect.left;
      selectedCard = entry.target;
    }
  });

if (selectedCard) {
  const category = (selectedCard as HTMLElement).dataset['category'];
  if (category && category !== this.currentCategory) {
    this.currentCategory = category;
    this.cdr.markForCheck();
  }
}
```

### Option 3: Center-Weighted Visibility
```typescript
// Find card closest to viewport center with good visibility
const viewportCenter = this.carouselTrack.nativeElement.getBoundingClientRect().width / 2;
let centerCard: Element | null = null;
let bestScore = 0;

visibleEntries.forEach(entry => {
  const rect = entry.target.getBoundingClientRect();
  const cardCenter = rect.left + (rect.width / 2);
  const distanceFromCenter = Math.abs(viewportCenter - cardCenter);
  
  // Score based on visibility and proximity to center
  const score = entry.intersectionRatio * (1 - distanceFromCenter / viewportCenter);
  
  if (score > bestScore) {
    bestScore = score;
    centerCard = entry.target;
  }
});

if (centerCard) {
  const category = (centerCard as HTMLElement).dataset['category'];
  if (category && category !== this.currentCategory) {
    this.currentCategory = category;
    this.cdr.markForCheck();
  }
}
```

## Why Current Implementation "Works"

Despite the flawed logic, it works acceptably because:

1. **Limited Cards Visible**: Usually only 2-3 cards are visible at once
2. **Category Grouping**: Cards are naturally grouped by category in the data
3. **Typical Scrolling**: Users tend to scroll to show one category predominantly
4. **Wide Cards**: Cards are 448px wide, limiting how many can be partially visible

## When It Fails

The current logic produces unexpected results when:
- Multiple categories are partially visible at boundaries
- Many cards have small partial visibility
- User scrolls to exact boundary between categories
- Viewport is very wide (desktop ultra-wide monitors)

## Recommendation

### Short Term (Current)
Keep current implementation with `markForCheck()` fix - it's functional enough.

### Medium Term
Implement **Option 1** (Single Most Visible) as it's:
- Simple to understand
- Predictable behavior
- Minimal performance impact
- Easy to test

### Long Term
Consider **Option 3** (Center-Weighted) for best UX:
- Most intuitive for users
- Focuses on what user is likely looking at
- Smooth transitions between categories
- Better for wide viewports

## Testing Considerations

When implementing improved logic, test:
1. Normal scrolling between categories
2. Boundary positions (50/50 visibility)
3. Fast scrolling/swiping
4. Different viewport sizes
5. Search results with mixed categories
6. Arrow navigation vs manual scrolling
7. Tab clicking to scroll to category

## Performance Notes

- Current summing logic: O(n) where n = visible cards
- Proposed single-card logic: O(n) but simpler operations
- No significant performance difference expected
- IntersectionObserver already throttles updates

## Related Files

- `catalogue-carousel.component.ts`: Implementation
- `catalogue-carousel.component.html`: Template with data-category attributes
- `catalogue-carousel.component.scss`: Card widths and spacing

## Change History

- **Milestone 5**: Added OnPush change detection, exposed visibility update issue
- **Quick Fix**: Added `markForCheck()` to trigger updates
- **Future**: Implement improved visibility detection logic

## Notes

- The 448px card width and 32px gap are hardcoded in navigation methods
- Consider making these configurable or reading from CSS
- IntersectionObserver threshold is 0.5 (50% visibility to trigger)
- Consider adjusting threshold based on chosen algorithm
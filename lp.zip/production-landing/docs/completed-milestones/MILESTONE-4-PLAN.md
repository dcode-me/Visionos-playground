# Milestone 4: Simplify Component Structure - Detailed Plan

## Overview
Flatten the component hierarchy by removing the unnecessary `catalogue-section` wrapper and moving `catalogue-carousel` directly under `hero-experience`.

## Current Structure
```
hero-experience/
├── hero-experience.component.ts (imports CatalogueSectionComponent)
├── hero-experience.component.html (uses <app-catalogue-section>)
└── components/
    ├── hero-section/
    └── catalogue-section/ (WRAPPER - TO BE REMOVED)
        ├── catalogue-section.component.ts
        ├── catalogue-section.component.html
        ├── catalogue-section.component.scss (HAS GRADIENT STYLES)
        └── components/
            └── catalogue-carousel/ (TO BE MOVED UP)
```

## Target Structure
```
hero-experience/
├── hero-experience.component.ts (will import CatalogueCarouselComponent)
├── hero-experience.component.html (will use <app-catalogue-carousel>)
└── components/
    ├── hero-section/
    └── catalogue-carousel/ (MOVED HERE)
```

## Important Discovery
The `catalogue-section.component.scss` contains the gradient background styling that needs to be preserved!

## Changes Required

### 1. Move Gradient Styles
**FROM**: `catalogue-section.component.scss`
- Gradient background (lines 12-21)
- Section padding and positioning (lines 6-10)

**TO**: `hero-experience.component.scss` or `catalogue-carousel.component.scss`
- Need to decide best location for these styles

### 2. Move Carousel Component
```bash
# Move from deep nesting to direct child
mv src/.../catalogue-section/components/catalogue-carousel src/.../hero-experience/components/
```

### 3. Update Import Paths
**hero-experience.component.ts**:
```typescript
// REMOVE:
import { CatalogueSectionComponent } from './components/catalogue-section/catalogue-section.component';

// ADD:
import { CatalogueCarouselComponent } from './components/catalogue-carousel/catalogue-carousel.component';

// UPDATE imports array:
imports: [CommonModule, HeroSectionComponent, CatalogueCarouselComponent]
```

### 4. Update Template
**hero-experience.component.html**:
```html
<!-- REPLACE: -->
<app-catalogue-section></app-catalogue-section>

<!-- WITH: -->
<section class="catalogue-section" role="region" aria-label="Product Catalogue">
  <app-catalogue-carousel></app-catalogue-carousel>
</section>
```

### 5. Update Service Imports
**catalogue-carousel.component.ts**:
```typescript
// UPDATE path (remove one level):
import { CatalogueDataService } from '../../../services/catalogue-data.service';
// Instead of: '../../../../services/catalogue-data.service'
```

### 6. Delete Wrapper Component
```bash
rm -rf src/.../hero-experience/components/catalogue-section
```

## File Impact Analysis

### Files to Modify:
1. `hero-experience.component.ts` - Update imports
2. `hero-experience.component.html` - Update template
3. `hero-experience.component.scss` - Add gradient styles
4. `catalogue-carousel.component.ts` - Update service import paths

### Files to Move:
1. `catalogue-carousel/` folder (3 files inside)

### Files to Delete:
1. `catalogue-section.component.ts`
2. `catalogue-section.component.html`
3. `catalogue-section.component.scss`

## Risk Assessment
- **Risk Level**: MEDIUM
- **Why**: Moving files and updating paths could break imports
- **Critical**: Must preserve gradient background styles
- **Mitigation**: Test thoroughly after each step

## Testing Requirements
1. ✅ Build succeeds
2. ✅ Carousel displays correctly
3. ✅ Gradient background visible
4. ✅ All carousel features work
5. ✅ No console errors
6. ✅ Service imports work

## Step-by-Step Execution Plan

### Step 1: Copy Gradient Styles
- Copy gradient styles from catalogue-section.scss
- Add to hero-experience.scss with proper class wrapper

### Step 2: Move Carousel Component
- Move entire catalogue-carousel folder up two levels
- Verify folder structure

### Step 3: Update Imports
- Update hero-experience.component.ts imports
- Update catalogue-carousel.component.ts service paths

### Step 4: Update Template
- Replace <app-catalogue-section> with direct carousel usage
- Add section wrapper with gradient class

### Step 5: Test Build
- Run build to catch any import errors
- Fix any path issues

### Step 6: Delete Old Wrapper
- Remove catalogue-section folder completely

## Commit Message
```
refactor(milestone-4): flatten component structure, remove wrapper

- Move catalogue-carousel directly under hero-experience
- Remove unnecessary catalogue-section wrapper component
- Preserve gradient styles in hero-experience
- Update all import paths
- Reduces nesting by one level
```

## Rollback Plan
```bash
git reset --hard HEAD~1
git push --force-with-lease origin refactor/catalogue-carousel-cleanup
```

## Final Checklist
- [ ] Gradient styles preserved
- [ ] All imports updated
- [ ] Paths corrected
- [ ] Build succeeds
- [ ] Visual appearance unchanged
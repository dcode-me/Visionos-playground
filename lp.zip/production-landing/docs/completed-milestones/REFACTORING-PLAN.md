# Catalogue Carousel Refactoring Plan

## GitHub Strategy

### Branch Protection Strategy
```bash
# 1. First, commit current working state to main
git add .
git commit -m "feat: complete catalogue carousel with all fixes"

# 2. Create refactoring branch
git checkout -b refactor/catalogue-carousel-cleanup

# 3. After each milestone, commit
git add .
git commit -m "refactor(milestone-X): [description]"

# 4. After all milestones complete
git checkout main
git merge refactor/catalogue-carousel-cleanup
```

## Refactoring Milestones

### Milestone 1: Debug Log Removal (Low Risk)
**Time: 5 minutes | Risk: None | Testing: Quick smoke test**

#### Files to Modify:
1. `catalogue-carousel.component.ts`
   - Remove all console.log statements (15 total)
   - Keep functionality intact
   
2. `hero-content.component.ts`
   - Remove console.log statements (2 total)

#### Test Checklist:
- [ ] Carousel loads properly
- [ ] Search works
- [ ] Tab switching works
- [ ] Navigation arrows work

**Commit**: `refactor(milestone-1): remove debug logs`

---

### Milestone 2: Remove Unused Search Toggle (Low Risk)
**Time: 10 minutes | Risk: Low | Testing: Search functionality**

#### Changes:
1. `catalogue-carousel.component.ts`
   - Remove `useInlineSearch` variable
   - Remove `@ViewChild('searchInput')` 
   - Clean up related logic

2. `catalogue-carousel.component.html`
   - Remove @else block (lines 74-124)
   - Keep only inline search implementation

3. `catalogue-carousel.component.scss`
   - Remove `.carousel__search` styles
   - Remove `.search-field` styles
   - Keep only `.ds-search` styles

#### Test Checklist:
- [ ] Inline search expands/collapses
- [ ] Search filtering works
- [ ] Clear search works
- [ ] Tab hiding during search works

**Commit**: `refactor(milestone-2): remove standalone search, keep inline only`

---

### Milestone 3: Remove Unused Components (Medium Risk)
**Time: 10 minutes | Risk: Medium | Testing: Full catalogue section**

#### Components to Delete:
1. Delete entire folder: `components/catalogue-section/components/catalogue-header/`
   - `catalogue-header.component.ts`
   - `catalogue-header.component.html`
   - `catalogue-header.component.scss`

#### Test Checklist:
- [aine ] No build errors
- [ ] Catalogue section displays correctly
- [ ] No missing imports errors

**Commit**: `refactor(milestone-3): remove unused catalogue-header component`

---

### Milestone 4: Simplify Component Structure (Medium Risk)
**Time: 15 minutes | Risk: Medium | Testing: Full app navigation**

#### Changes:
1. **Move catalogue-carousel up one level**:
   ```
   FROM: hero-experience/components/catalogue-section/components/catalogue-carousel/
   TO:   hero-experience/components/catalogue-carousel/
   ```

2. **Update imports in**:
   - `catalogue-section.component.ts`
   - Update import path for CatalogueCarouselComponent

3. **Move styles from catalogue-section to hero-experience**:
   - Copy gradient background from `catalogue-section.component.scss`
   - Add to `hero-experience.component.scss`
   - Adjust `.hero-experience` to include the gradient

4. **Update hero-experience.component.ts**:
   - Import `CatalogueCarouselComponent` directly
   - Remove `CatalogueSectionComponent` import

5. **Update hero-experience.component.html**:
   - Replace `<app-catalogue-section>` with `<app-catalogue-carousel>`

6. **Delete catalogue-section component**:
   - Delete entire `components/catalogue-section/` folder (except the moved carousel)

#### Test Checklist:
- [ ] Build succeeds
- [ ] Catalogue displays with gradient background
- [ ] All carousel features work
- [ ] No console errors

**Commit**: `refactor(milestone-4): flatten component structure, remove wrapper`

---

### Milestone 5: Clean Unused ViewChild & Optimize (Low Risk)
**Time: 5 minutes | Risk: Low | Testing: Performance check**

#### Changes:
1. `catalogue-carousel.component.ts`:
   - Remove `@ViewChild('carouselHeader')` (unused)
   - Add `ChangeDetectionStrategy.OnPush`
   - Replace `detectChanges()` with `markForCheck()` where appropriate

#### Test Checklist:
- [ ] Navigation button states update
- [ ] Tab sync still works
- [ ] No performance regression

**Commit**: `refactor(milestone-5): optimize change detection and remove unused refs`

---

### Milestone 6: Type Safety Improvements (Low Risk)
**Time: 10 minutes | Risk: Low | Testing: TypeScript compilation**

#### Changes:
1. Add return types to all methods
2. Replace `any` with proper types:
   - Category interface
   - GSAP type definition

3. Fix the underscore prefix for unused parameters

#### Test Checklist:
- [ ] No TypeScript errors
- [ ] Build succeeds

**Commit**: `refactor(milestone-6): improve type safety`

---

### Milestone 7: Clean Project Root (No Risk)
**Time: 5 minutes | Risk: None | Testing: None needed**

#### Files to Delete:
1. `References/` folder (keep backup elsewhere)
2. `chrome-devtools-mcp/` folder
3. `fullwidth-carousel-extracted.html`
4. `"Geometry Grid Patterns.svg"`

#### Test Checklist:
- [ ] Build still works
- [ ] No missing asset errors

**Commit**: `refactor(milestone-7): clean project root files`

---

### Milestone 8: CSS Consolidation (Low Risk)
**Time: 10 minutes | Risk: Low | Testing: Visual regression**

#### Changes:
1. Consolidate media queries in `catalogue-carousel.component.scss`
2. Group all mobile styles together
3. Remove duplicate styles
4. Ensure all use DSM tokens

#### Test Checklist:
- [ ] Desktop layout intact
- [ ] Mobile layout intact
- [ ] Tablet layout intact

**Commit**: `refactor(milestone-8): consolidate and organize styles`

---

## Final Verification

### Full Test Suite:
- [ ] Start server: `npm start`
- [ ] Test on Chrome, Safari, Firefox
- [ ] Test mobile responsive
- [ ] Test search functionality
- [ ] Test tab navigation
- [ ] Test arrow navigation
- [ ] Test keyboard accessibility
- [ ] Check for console errors
- [ ] Verify no visual regressions

### Final Merge:
```bash
git checkout main
git merge refactor/catalogue-carousel-cleanup
git push origin main
```

## Time Estimate
- Total: ~70 minutes
- Testing: ~20 minutes
- Buffer: ~10 minutes
- **Total with buffer: 1.5 hours**

## Rollback Strategy
If any milestone fails:
```bash
git reset --hard HEAD~1  # Undo last commit
git checkout main        # Return to safe state
```

## Notes
- Each milestone is independent
- Test after EACH milestone
- Commit only after successful test
- Keep browser dev tools open to catch errors early
- Have the app running during all changes
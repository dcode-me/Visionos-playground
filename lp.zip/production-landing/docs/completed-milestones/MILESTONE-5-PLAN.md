# Milestone 5: Clean Unused ViewChild & Optimize Change Detection - Detailed Plan

## Overview
Remove unused ViewChild references and optimize change detection by implementing OnPush strategy where appropriate.

## Current State Analysis

### ViewChild References in catalogue-carousel.component.ts
1. **Line 17**: `@ViewChild('carouselElement')` - USED (line 125, 382)
2. **Line 18**: `@ViewChild('carouselHeader')` - **NOT USED** ❌
3. **Line 19**: `@ViewChild('carouselTrack')` - USED (multiple places)
4. **Line 20**: `@ViewChild('inlineSearchInput')` - USED (line 215)
5. **Line 21**: `@ViewChild('segmentedControl')` - USED (line 77, 423)

### Change Detection Usage
- **Line 27**: `ChangeDetectorRef` injected
- **Line 270**: `detectChanges()` called when no products
- **Line 295**: `detectChanges()` called for navigation buttons

### HTML Template References Check
```html
Line 10: <div class="carousel__header" #carouselHeader>
```
The template reference `#carouselHeader` exists but is never accessed in TypeScript.

## Changes Required

### 1. Remove Unused ViewChild
```typescript
// REMOVE Line 18:
@ViewChild('carouselHeader') carouselHeader!: ElementRef;
```

### 2. Remove Unused Template Reference
```html
// Change line 10 in template FROM:
<div class="carousel__header" #carouselHeader>
// TO:
<div class="carousel__header">
```

### 3. Optimize Change Detection
```typescript
// Add to @Component decorator:
changeDetection: ChangeDetectionStrategy.OnPush

// Replace detectChanges() with markForCheck():
// Line 270: this.cdr.detectChanges() → this.cdr.markForCheck()
// Line 295: this.cdr.detectChanges() → this.cdr.markForCheck()
```

### 4. Import ChangeDetectionStrategy
```typescript
// Update line 1:
import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, inject, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';
```

## Impact Analysis

### What Will Change
1. **Performance**: OnPush strategy will reduce unnecessary change detection cycles
2. **Memory**: One less ViewChild reference
3. **Template**: Cleaner without unused reference

### What Won't Break
✅ All carousel functionality remains intact
✅ Search still works
✅ Navigation buttons update properly
✅ Tab switching works
✅ Scroll tracking works

## Risk Assessment
- **Risk Level**: LOW-MEDIUM
- **Why**: OnPush strategy requires careful handling of state changes
- **Mitigation**: Using markForCheck() ensures UI updates when needed

## Testing Requirements
After implementation:
1. ✅ Build succeeds
2. ✅ Navigation buttons enable/disable correctly
3. ✅ Search results update properly
4. ✅ Tab switching works
5. ✅ Carousel scrolling works
6. ✅ No console errors
7. ✅ Performance improved (fewer change detection cycles)

## Step-by-Step Execution

### Step 1: Update Component Imports
Add ChangeDetectionStrategy to imports

### Step 2: Add OnPush Strategy
Add to @Component decorator

### Step 3: Remove Unused ViewChild
Remove carouselHeader ViewChild declaration

### Step 4: Update Template
Remove #carouselHeader reference

### Step 5: Update Change Detection Calls
Replace detectChanges with markForCheck

### Step 6: Test
Verify all interactive features still work

## Performance Benefits
- **OnPush Strategy**: Component only checks for changes when:
  - Input properties change
  - Event occurs
  - Observable emits
  - markForCheck() is called
- **Result**: Fewer unnecessary renders, better performance

## Commit Message
```
refactor(milestone-5): optimize change detection and remove unused refs

- Remove unused carouselHeader ViewChild
- Add ChangeDetectionStrategy.OnPush for better performance
- Replace detectChanges with markForCheck
- Remove unused template reference
```

## Rollback Plan
```bash
git reset --hard HEAD~1
```

## Final Checklist
- [ ] Unused ViewChild removed
- [ ] Template reference removed
- [ ] OnPush strategy implemented
- [ ] detectChanges replaced with markForCheck
- [ ] All features still work
- [ ] Build succeeds
# Design System Reference Documentation

This directory contains the original BMO Design System specifications that were used to generate the Angular design system implementation.

## Files

- **colors.json** - Complete color palette including brand, neutral, semantic, and data visualization colors
- **typography.json** - Typography scale for headings and paragraphs with Heebo font specifications
- **spacing.json** - Spacing scale from 3xs (4px) to 3xl (56px)
- **baseSizes.json** - Base sizing units for consistent component dimensions
- **shadow.json** - Shadow definitions (small, medium, large) and overlay specifications
- **borderRadius.json** - Border radius scale and focus state definitions

## Usage

These JSON files serve as the source of truth for the design system and were used to generate:

1. SCSS foundation files in `src/app/core/design-system/foundations/`
2. TypeScript token definitions in `src/app/core/design-system/tokens/`
3. The DesignSystemService for runtime access

## Updating the Design System

If you need to update design tokens:

1. Modify the appropriate JSON file in this directory
2. Update the corresponding SCSS foundation file
3. Update the TypeScript token definitions if needed
4. Test the changes across all components

## BMO Brand Guidelines

These tokens follow BMO's brand guidelines and should not be modified without design team approval.
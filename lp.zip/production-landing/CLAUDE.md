# Claude.MD - BMO Marketplace Landing Page

## Project Overview

Production-ready public landing page for BMO Marketplace - a financial services platform showcasing BMO's private banking capabilities. The public page serves as an entry point for potential customers to explore marketplace services before accessing the authenticated private platform.

## Business Context

### Platform Capabilities (Private Version)
- Open additional deposit accounts
- Modify select banking services  
- Connect to third-party tools (Xero, QuickBooks, etc.)
- Explore exclusive partner offers
- Access developer resources and API documentation

### Public Landing Page Purpose
- Showcase marketplace services and capabilities
- Drive user registration and conversion
- Demonstrate API capabilities for developers
- Attract potential partners for collaboration
- Build trust through feature demonstrations

## Product Categories
1. **Self-servicing (Accounts & Services)** - Banking account management
2. **App Integration** - Third-party tool connectivity
3. **Partner Offers** - Exclusive deals and services
4. **API** - Developer resources and documentation

## Technical Stack

### Core Technologies
- **Framework**: Angular 19 (Standalone Components, No Modules)
- **Language**: TypeScript 5.0+ (Strict Mode, No `any` types)
- **Styling**: SASS/SCSS with BEM methodology
- **Animation**: GSAP (GreenSock) via CDN with ScrollTrigger
- **State Management**: Angular Signals + RxJS
- **Build Tool**: Angular CLI with esbuild
- **Image Optimization**: NgOptimizedImage

### Angular-Specific Features
- Standalone Components Architecture (No NgModules)
- Angular Signals for reactive state
- Deferred Views for performance
- Direct service injection with `inject()`
- Lazy loading for heavy components
- New Angular 19 features and optimizations

## Development Principles

### Code Quality Standards
- **Type Safety**: Strict TypeScript with no `any` types
- **Immutability**: Pure functions and immutable data structures
- **Component Composition**: Favor composition over inheritance
- **Meaningful Naming**: Descriptive variable names (e.g., `isUserLoggedIn`, `fetchAccountData`)
- **File Naming**: Kebab-case (e.g., `hero-section.component.ts`)

### Import Order
1. Angular core and common modules
2. RxJS modules
3. Angular-specific modules
4. Core application imports
5. Shared module imports
6. Environment-specific imports
7. Relative path imports

### Coding Standards
- Single quotes for strings
- 2-space indentation
- Template literals for string interpolation
- `const` for constants and immutable variables
- Optional chaining (`?.`) and nullish coalescing (`??`)

## Project Structure

```
src/
├── app/
│   ├── core/
│   │   ├── design-system/
│   │   │   ├── foundations/
│   │   │   │   ├── color/
│   │   │   │   ├── spacing/
│   │   │   │   ├── sizing/
│   │   │   │   ├── typography/
│   │   │   │   ├── shadows/
│   │   │   │   ├── overlay/
│   │   │   │   └── border-radius/
│   │   │   └── tokens/
│   │   ├── layout/
│   │   │   ├── grid/
│   │   │   ├── container/
│   │   │   └── responsive/
│   │   ├── services/
│   │   ├── guards/
│   │   └── interceptors/
│   ├── shared/
│   │   ├── components/
│   │   ├── directives/
│   │   ├── pipes/
│   │   └── animations/
│   ├── features/
│   │   ├── landing/
│   │   │   ├── sections/
│   │   │   │   ├── header/
│   │   │   │   ├── hero/
│   │   │   │   ├── product-catalogue/
│   │   │   │   ├── erf-feature/
│   │   │   │   ├── api-feature/
│   │   │   │   ├── self-serve/
│   │   │   │   ├── partner-offers/
│   │   │   │   ├── cta-section/
│   │   │   │   └── footer/
│   │   │   └── modals/
│   │   │       └── partner-interest/
│   │   └── landing.component.ts
│   ├── styles/
│   │   ├── base/
│   │   ├── utilities/
│   │   └── main.scss
│   └── app.component.ts
├── assets/
│   ├── images/
│   ├── icons/
│   ├── animations/
│   └── data/
│       └── design-tokens.json
├── environments/
└── tests/
    ├── unit/
    ├── integration/
    └── e2e/
```

## Implementation Phases

### Phase 1: Design System Module (DSM)
Implement BMO Design System foundations from provided JSON/documentation

### Phase 2: Layout System
Build CSS Grid-based responsive layout system

### Phase 3: Landing Page Sections with Components
Develop page sections while building reusable components as needed

## Accessibility Requirements

### WCAG AA Compliance
- Semantic HTML structure
- ARIA labels and live regions
- Keyboard navigation support
- Focus management and visible focus indicators
- Color contrast compliance (4.5:1 minimum)
- Screen reader optimization

### Animation Accessibility
- Play/pause controls for all animations
- `prefers-reduced-motion` support
- Keyboard controls for interactive elements
- Alternative content for motion graphics
- Smooth focus transitions
- Animation duration controls

## Animation Strategy

### GSAP Implementation
- **Core Library**: GSAP 3.x loaded via CDN
- **Plugins**: ScrollTrigger, TextPlugin (for language switching)
- **Performance**: Hardware-accelerated transforms only
- **Principles**: Subtle, smooth, engaging, enjoyable
- **Progressive Enhancement**: CSS animations as fallback

### GSAP CDN Setup
```html
<!-- In index.html -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/TextPlugin.min.js"></script>
```

### Animation Use Cases
- Hero illustration interactions (entry, exit, hover)
- Section scroll animations
- Language switching transitions
- Carousel and slider animations
- Search component interactions
- Micro-interactions and feedback

## Performance Targets

### Core Web Vitals
- **LCP** (Largest Contentful Paint): < 2.5s
- **FID** (First Input Delay): < 100ms
- **CLS** (Cumulative Layout Shift): < 0.1
- **TTI** (Time to Interactive): < 3.5s

### Optimization Strategies
- Lazy loading for below-fold content
- Image optimization with NgOptimizedImage
- Code splitting per route
- Tree shaking and dead code elimination
- Preloading critical resources
- CDN deployment for static assets

## Security Considerations

### Implementation
- Content Security Policy (CSP) headers
- XSS protection through Angular sanitization
- HTTPS enforcement
- Secure cookie configuration
- Input validation and sanitization
- Environment variable protection

## Browser Support

### Target Browsers
- Chrome/Edge: Last 2 versions
- Firefox: Last 2 versions
- Safari: Last 2 versions (desktop/mobile)
- iOS Safari: 14+
- Android Chrome: Last 2 versions

---

# Browser MCP Validation Workflow

## Automated Testing Protocol

### Browser MCP Integration
Browser MCP enables automated browser testing for each implemented feature. All components must pass browser validation before being marked complete.

### Validation Workflow
1. **Implementation Phase**
   - Develop component/feature according to specifications
   - Add detailed console logs for debugging
   - Include state change logs
   - Track GSAP animation lifecycle events

2. **Browser MCP Validation**
   - Use Browser MCP to navigate to implemented section
   - Verify visual rendering matches design specs
   - Test all interactive elements
   - Validate accessibility features
   - Check responsive behavior across breakpoints
   - Test GSAP animations and ScrollTrigger events

3. **Logging Requirements**
   - Component mount/unmount logs
   - State changes and data flow
   - API calls and responses
   - GSAP animation start/complete events
   - User interaction tracking
   - Error boundaries and handling

4. **User Confirmation Process**
   - After Browser MCP validates successfully
   - Present validation results to user
   - Request explicit approval to proceed
   - Only after approval: remove debug logs
   - Mark task as completed in TODO.md

### Browser MCP Commands
```bash
# Start Browser MCP server
npx @browsermcp/mcp start

# Connect to running Angular dev server
# Navigate to http://localhost:4200
# Run automated tests for each component
```

### Validation Checklist for Each Component
- [ ] Visual rendering correct
- [ ] All interactions functional
- [ ] GSAP animations smooth (60fps)
- [ ] Accessibility features working
- [ ] Responsive at all breakpoints
- [ ] No console errors
- [ ] Performance metrics met
- [ ] User approval received
- [ ] Debug logs removed
- [ ] Task marked complete

---

# Section-by-Section Implementation Guide

*Note: For each section below, reference implementations and planning details will be requested during development.*

## 1. Sticky Header Component

### Requirements
- [ ] BMO logo and brand identity
- [ ] Navigation menu with smooth scroll
- [ ] Login/Sign Up CTAs
- [ ] Mobile hamburger menu
- [ ] Scroll-based transparency effects
- [ ] GSAP scroll animations
- [ ] Accessibility compliance

### Implementation Notes
*To be filled with reference implementation details*

---

## 2. Hero Section Component

### Requirements
- [ ] Compelling headline and subheadline
- [ ] Primary CTA buttons
- [ ] Interactive illustration with GSAP
- [ ] Trust indicators
- [ ] Responsive layout
- [ ] Entry/exit animations
- [ ] Hover interactions

### Implementation Notes
*To be filled with reference implementation details*

---

## 3. Product Catalogue Component

### Requirements
- [ ] 4 product categories display
- [ ] Category cards/tiles
- [ ] Interactive hover states
- [ ] GSAP scroll animations
- [ ] Responsive grid layout
- [ ] Accessibility navigation

### Implementation Notes
*To be filled with reference implementation details*

---

## 4. ERP Feature Component

### Requirements
- [ ] Feature description
- [ ] Visual demonstration
- [ ] Motion graphics with GSAP
- [ ] Benefits highlight
- [ ] CTA integration

### Implementation Notes
*To be filled with reference implementation details*

---

## 5. API Feature Component

### Requirements
- [ ] Developer-focused content
- [ ] Code examples display
- [ ] API capabilities showcase
- [ ] Interactive demonstrations
- [ ] Documentation links

### Implementation Notes
*To be filled with reference implementation details*

---

## 6. Self-Serve Account Opening Component

### Requirements
- [ ] Process visualization
- [ ] Step-by-step display
- [ ] Benefits listing
- [ ] Interactive elements
- [ ] GSAP animations

### Implementation Notes
*To be filled with reference implementation details*

---

## 7. Partner Offers Component

### Requirements
- [ ] Partner showcase
- [ ] Offer cards/carousel
- [ ] Category filtering
- [ ] GSAP carousel animations
- [ ] CTA for each offer

### Implementation Notes
*To be filled with reference implementation details*

---

## 8. CTA Section Component

### Requirements
- [ ] 3 separate CTAs
- [ ] Strategic placement
- [ ] Compelling copy
- [ ] GSAP hover effects
- [ ] Responsive layout

### Implementation Notes
*To be filled with reference implementation details*

---

## 9. Footer Component

### Requirements
- [ ] Site navigation
- [ ] Legal links
- [ ] Contact information
- [ ] Social media links
- [ ] Accessibility links
- [ ] Language selector

### Implementation Notes
*To be filled with reference implementation details*

---

## 10. Partner Interest Modal

### Requirements
- [ ] Full-page overlay
- [ ] Form validation
- [ ] Multi-step process
- [ ] GSAP transitions
- [ ] Accessibility compliance
- [ ] Success/error states

### Implementation Notes
*To be filled with reference implementation details*

---

---

# Section-by-Section Implementation Guide

*Note: For each section below, reference implementations and planning details will be requested during development.*
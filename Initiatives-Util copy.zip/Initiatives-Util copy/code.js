"use strict";
// Figma Variables JSON Plugin
// Handles importing JSON data as string variables and exporting existing variables as JSON
figma.showUI(__html__, { width: 500, height: 600 });
// Sanitize a single variable path segment
function sanitizeVariableSegment(segment) {
    return segment
        .replace(/[^a-zA-Z0-9-_]/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$|^\s+|\s+$/g, '')
        .substring(0, 50);
}
function buildVariableNameFromPath(path) {
    const parts = path.split('.');
    const sanitized = parts.map(sanitizeVariableSegment).filter(Boolean);
    return sanitized.join('/');
}
// Recursively extract all string values from JSON object
function extractStringValues(obj, prefix = '') {
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        if (typeof value === 'string') {
            const variableName = buildVariableNameFromPath(fullKey);
            result[variableName] = value;
        }
        else if (typeof value === 'object' && value !== null) {
            Object.assign(result, extractStringValues(value, fullKey));
        }
    }
    return result;
}
// Validate that multiple JSONs have the same structure
function validateStructure(modes) {
    if (modes.length <= 1)
        return true;
    const firstStructure = getObjectStructure(modes[0].data);
    for (let i = 1; i < modes.length; i++) {
        const currentStructure = getObjectStructure(modes[i].data);
        if (!compareStructures(firstStructure, currentStructure)) {
            return false;
        }
    }
    return true;
}
// Get the structure of an object (keys and types, but not values)
function getObjectStructure(obj) {
    if (typeof obj !== 'object' || obj === null) {
        return typeof obj;
    }
    if (Array.isArray(obj)) {
        return obj.length > 0 ? [getObjectStructure(obj[0])] : [];
    }
    const structure = {};
    for (const [key, value] of Object.entries(obj)) {
        structure[key] = getObjectStructure(value);
    }
    return structure;
}
// Compare two object structures
function compareStructures(struct1, struct2) {
    if (typeof struct1 !== typeof struct2)
        return false;
    if (typeof struct1 !== 'object' || struct1 === null) {
        return struct1 === struct2;
    }
    if (Array.isArray(struct1) !== Array.isArray(struct2))
        return false;
    if (Array.isArray(struct1)) {
        return struct1.length === struct2.length &&
            struct1.every((item, index) => compareStructures(item, struct2[index]));
    }
    const keys1 = Object.keys(struct1);
    const keys2 = Object.keys(struct2);
    if (keys1.length !== keys2.length)
        return false;
    return keys1.every(key => keys2.includes(key) && compareStructures(struct1[key], struct2[key]));
}
// Create or get collection
async function getOrCreateCollection(name, createNew) {
    if (createNew) {
        return figma.variables.createVariableCollection(name);
    }
    else {
        const collections = await figma.variables.getLocalVariableCollectionsAsync();
        const existing = collections.find(c => c.name === name);
        if (!existing) {
            throw new Error(`Collection "${name}" not found`);
        }
        return existing;
    }
}
// Import variables from JSON modes
async function importVariables(modes, collectionName, createNewCollection) {
    var _a;
    try {
        if (!validateStructure(modes)) {
            throw new Error('All JSON modes must have the same structure');
        }
        const collection = await getOrCreateCollection(collectionName, createNewCollection);
        const variableNames = Object.keys(extractStringValues(modes[0].data));
        const createdVariables = {};
        for (const mode of modes) {
            const stringValues = extractStringValues(mode.data);
            createdVariables[mode.name] = {};
            for (const [varName, value] of Object.entries(stringValues)) {
                const variables = await figma.variables.getLocalVariablesAsync();
                let variable = variables.find(v => v.name === varName && v.variableCollectionId === collection.id);
                if (!variable) {
                    variable = figma.variables.createVariable(varName, collection, 'STRING');
                }
                // Get or create mode
                let modeId = (_a = collection.modes.find(m => m.name === mode.name)) === null || _a === void 0 ? void 0 : _a.modeId;
                if (!modeId) {
                    modeId = collection.addMode(mode.name);
                }
                variable.setValueForMode(modeId, value);
                createdVariables[mode.name][varName] = variable;
            }
        }
        return { success: true, message: `Successfully imported ${variableNames.length} variables` };
    }
    catch (error) {
        return { success: false, message: error.message };
    }
}
// Export collection as JSON
async function exportCollection(collectionId) {
    try {
        const collection = figma.variables.getVariableCollectionById(collectionId);
        if (!collection) {
            throw new Error('Collection not found');
        }
        const variables = await figma.variables.getLocalVariablesAsync();
        const collectionVariables = variables.filter(v => v.variableCollectionId === collectionId);
        const result = {};
        for (const mode of collection.modes) {
            result[mode.name] = {};
        }
        // Build the JSON structure from "/"-grouped variable names
        for (const variable of collectionVariables) {
            const pathParts = variable.name.split('/');
            const finalKey = pathParts[pathParts.length - 1];
            for (const mode of collection.modes) {
                if (!result[mode.name])
                    result[mode.name] = {};
                let nested = result[mode.name];
                for (let i = 0; i < pathParts.length - 1; i++) {
                    const part = pathParts[i];
                    if (!nested[part])
                        nested[part] = {};
                    nested = nested[part];
                }
                // Placeholder value (Figma API does not expose read of variable values here)
                nested[finalKey] = `[${variable.name}]`;
            }
        }
        return { success: true, data: result };
    }
    catch (error) {
        return { success: false, message: error.message };
    }
}
// Get collections list
async function getCollections() {
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    return collections.map(c => ({
        id: c.id,
        name: c.name
    }));
}
// Handle messages from UI
figma.ui.onmessage = async (msg) => {
    switch (msg.type) {
        case 'import':
            const importResult = await importVariables(msg.modes, msg.collectionName, msg.createNewCollection);
            figma.ui.postMessage(Object.assign({ type: 'import-result' }, importResult));
            break;
        case 'export':
            const exportResult = await exportCollection(msg.collectionId);
            figma.ui.postMessage(Object.assign({ type: 'export-result' }, exportResult));
            break;
        case 'get-collections':
            const collections = await getCollections();
            figma.ui.postMessage({ type: 'collections-list', collections });
            break;
        case 'cancel':
            figma.closePlugin();
            break;
    }
};

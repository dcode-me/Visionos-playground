# Figma Variables JSON Plugin

A Figma plugin for importing JSON data as string variables and exporting existing variables as JSON. Supports multiple modes (light/dark themes, responsive breakpoints, etc.) with structure validation.

## Features

### 🚀 Import JSON as Variables
- Parse JSON data and create string variables in Figma
- Support for nested JSON structures (e.g., `colors.primary`, `typography.heading.h1`)
- Automatic variable naming based on JSON structure

### 🎨 Multiple Modes Support
- Import multiple JSONs for different modes (light/dark themes, mobile/desktop, etc.)
- Structure validation ensures all modes have the same JSON structure
- Each mode becomes a separate mode in the Figma variable collection

### 📁 Collection Management
- Create new variable collections or use existing ones
- Select from available collections in the current document
- Automatic collection creation with custom names

### 📤 Export Functionality
- Export existing variable collections as JSON
- Maintains the original nested structure
- Supports all modes in the collection

## Usage

### Importing Variables

1. **Add JSON Data**: Enter your JSON data in the text area
   ```json
   {
     "colors": {
       "primary": "#007bff",
       "secondary": "#6c757d"
     },
     "typography": {
       "heading": {
         "h1": "32px",
         "h2": "24px"
       }
     }
   }
   ```

2. **Add Multiple Modes**: Click "Add Mode" to add additional JSONs for different modes
   - Mode names: `light`, `dark`, `mobile`, `desktop`, etc.
   - Ensure all JSONs have the same structure

3. **Select Collection**: Choose to create a new collection or use an existing one

4. **Import**: Click "Import Variables" to create the variables in Figma

### Exporting Variables

1. **Select Collection**: Choose a collection from the dropdown
2. **Export**: Click "Export as JSON" to get the JSON representation
3. **Copy**: The JSON will be displayed in a textarea for easy copying

## JSON Structure Requirements

### For Import
- All values must be strings (the plugin only creates string variables)
- Nested objects are supported and will create dot-notation variable names
- Arrays are not supported (convert to objects if needed)

### For Multiple Modes
- All JSONs must have identical structure (same keys and nesting)
- Only the string values can differ between modes
- Structure validation prevents import if structures don't match

## Example Use Cases

### Design Tokens
```json
// Light Mode
{
  "colors": {
    "primary": "#007bff",
    "background": "#ffffff",
    "text": "#333333"
  }
}

// Dark Mode
{
  "colors": {
    "primary": "#0056b3",
    "background": "#1a1a1a",
    "text": "#ffffff"
  }
}
```

### Typography System
```json
// Desktop
{
  "typography": {
    "heading": {
      "h1": "48px",
      "h2": "36px",
      "h3": "24px"
    },
    "body": {
      "large": "18px",
      "medium": "16px",
      "small": "14px"
    }
  }
}

// Mobile
{
  "typography": {
    "heading": {
      "h1": "32px",
      "h2": "28px",
      "h3": "20px"
    },
    "body": {
      "large": "16px",
      "medium": "14px",
      "small": "12px"
    }
  }
}
```

## Technical Details

### Variable Naming
- JSON keys are converted to dot-notation: `colors.primary` → variable name
- Nested objects create deeper dot-notation: `typography.heading.h1` → variable name

### Mode Management
- Each mode becomes a separate mode in the Figma variable collection
- Mode names are preserved as entered in the UI
- Variables are created with all modes simultaneously

### Error Handling
- JSON validation with helpful error messages
- Structure validation for multiple modes
- Collection existence validation
- Graceful error recovery

## Development

### Building
```bash
npm install
npx tsc
```

### File Structure
- `code.ts` - Main plugin logic (Figma API)
- `ui.html` - Plugin UI and user interactions
- `manifest.json` - Plugin configuration
- `tsconfig.json` - TypeScript configuration

### Dependencies
- TypeScript for type safety
- Figma Plugin API for variable management

## Limitations

- Only supports string variables (no colors, numbers, or booleans)
- Export functionality shows variable names as placeholders (Figma API limitation)
- Arrays in JSON are not supported
- Maximum nesting depth depends on Figma's variable naming limits

## Future Enhancements

- Support for color, number, and boolean variables
- Better export functionality with actual variable values
- Array support with indexed naming
- Bulk import/export operations
- Variable value editing in the plugin UI

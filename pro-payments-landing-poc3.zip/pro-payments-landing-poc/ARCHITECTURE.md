# BMO PRO Payments Landing POC - Architecture

## Project Structure

This project follows a **modular, partial-based architecture** where individual page components are injected dynamically. This approach simulates Micro Frontend (MFE) principles and ensures clean separation of concerns.

```
pro-payments-landing-poc/
├── index.html                    # Main application shell
├── script.js                     # Core navigation and page loading logic
├── current_navigation.json       # Navigation data structure
├── partials/                     # All reusable components
│   ├── topnav.html              # Top navigation partial
│   ├── topnav.css               # Top navigation styles
│   ├── sidenav.html             # Side navigation partial
│   ├── sidenav.css              # Side navigation styles
│   ├── bmo-logo.svg             # BMO logo asset
│   └── pages/                   # Individual page partials
│       ├── pages.css            # Shared page component styles
│       ├── payments-overview.html # Pay & Receive overview page
│       ├── interac.html         # Interac e-Transfer page
│       └── wire-transfers.html  # Wire transfers page
├── README.md                    # Project documentation
└── ARCHITECTURE.md              # This file
```

## Architecture Principles

### 1. **Partial-Based Components**
- Each UI component is a standalone HTML partial with associated CSS
- Components can be loaded independently and combined dynamically
- No external dependencies - pure vanilla HTML/CSS/JS

### 2. **Page Injection System**
- Pages are loaded as HTML partials via `fetch()` API
- Smooth transitions between page content with fade effects
- Fallback system for unmapped content

### 3. **Modular CSS Architecture**
- Component-specific CSS files (e.g., `sidenav.css`, `topnav.css`)
- Shared page styling in `pages/pages.css`
- BEM-inspired naming convention for clarity

### 4. **Navigation State Management**
- Primary and secondary navigation with hover and click states
- Overview mode with persistent secondary navigation
- Smooth content transitions with dissolved shadows

## Key Components

### Navigation System
- **Primary Navigation**: Main menu items (Dashboard, Accounts, Pay & Receive, etc.)
- **Secondary Navigation**: Contextual sub-menus that appear based on primary selection
- **State Management**: Tracks overview mode vs. normal navigation mode

### Page Partials System
The `loadPagePartial()` function maps navigation selections to specific HTML partials:

```javascript
// Example mapping
const pageMapping = {
  'Account Transfer': 'partials/pages/interac.html',
  'Wire Payment': 'partials/pages/wire-transfers.html'
};
```

### Current Focus: Payments
The current implementation focuses on three key payment pages:

1. **Payments Overview** (`payments-overview.html`)
   - Quick actions for common tasks
   - Recent activity dashboard
   - Payment method selection

2. **Interac e-Transfer** (`interac.html`)
   - Send money functionality
   - Recent transfers table
   - Transfer management options

3. **Wire Transfers** (`wire-transfers.html`)
   - Create wire payments
   - Status tracking dashboard
   - Wire management tools

## Styling System

### Design System
- **Colors**: BMO brand colors (#005587, #c1e7ff, #eff0f0, etc.)
- **Typography**: Heebo font family with consistent hierarchy
- **Components**: Material Design-inspired with BMO customizations

### Component Classes
- `.page-content` - Main page wrapper
- `.content-card` - Reusable content containers
- `.action-button` - Interactive buttons with variants
- `.status-badge` - Status indicators with color coding

## Adding New Pages

To add a new page partial:

1. **Create HTML partial** in `partials/pages/`
   ```html
   <div class="page-content" data-page="new-page">
     <!-- Page content -->
   </div>
   ```

2. **Update page mapping** in `script.js`
   ```javascript
   const pageMapping = {
     'New Page': 'partials/pages/new-page.html'
   };
   ```

3. **Use existing CSS classes** from `pages.css` or add new ones as needed

## Performance Considerations

- **Lazy Loading**: Page partials are loaded only when needed
- **Caching**: Browser naturally caches partial files
- **Minimal JavaScript**: Core logic is lightweight and efficient
- **CSS Scoping**: Component styles are properly scoped to avoid conflicts

## Future Enhancements

- **Real MFE Integration**: Convert partials to true micro frontends
- **API Integration**: Connect to real BMO banking APIs
- **Advanced State Management**: Implement more sophisticated state handling
- **Testing Framework**: Add unit and integration tests
- **Build System**: Introduce bundling and optimization tools

This architecture provides a solid foundation for building complex, modular business banking interfaces while maintaining simplicity and performance. 
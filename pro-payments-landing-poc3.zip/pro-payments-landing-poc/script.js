// Navigation logic for BMO PRO Payments Landing POC

let navigationData = {};
let isOverviewMode = false;
let isMobileView = false;
let isSecondaryHidden = false;

// Utility: Capitalize first letter
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Check if we're in mobile view
function checkMobileView() {
  isMobileView = window.innerWidth <= 768;
  return isMobileView;
}

// Load navigation data and setup
console.log('Script starting...');

fetch('current_navigation.json')
  .then(res => res.json())
  .then(data => {
    navigationData = data;
    console.log('Navigation data loaded:', navigationData);
    setupSidenav();
  })
  .catch(error => {
    console.error('Error loading navigation:', error);
    // Setup sidenav anyway with limited functionality
    setupSidenav();
  });

function setupSidenav() {
  console.log('Setting up sidenav...');
  
  const sidenav = document.querySelector('.sidenav');
  const primaryNav = sidenav.querySelector('.sidenav__primary');
  const primaryItems = sidenav.querySelectorAll('.sidenav__item');
  const secondaryPane = document.getElementById('sidenav-secondary');
  const mainContent = document.getElementById('main-content');
  
  if (!sidenav || !secondaryPane || primaryItems.length === 0) {
    console.error('Sidenav elements not found', { sidenav: !!sidenav, secondaryPane: !!secondaryPane, primaryItems: primaryItems.length });
    return;
  }

  console.log('Found elements:', { sidenav: !!sidenav, secondaryPane: !!secondaryPane, primaryItems: primaryItems.length });

  let hoverTimeout;

  // Helper: Update secondary content
  function updateSecondaryContent(menu, isOverviewMode = false) {
    // Clear existing content
    secondaryPane.innerHTML = '';
    
    // Add menu items
    menu.forEach((item, idx) => {
      const div = document.createElement('div');
      div.className = 'sidenav__secondary-item';
      div.textContent = item.label;
      div.dataset.index = idx;
      if (item.isOverview) {
        div.dataset.overview = 'true';
        if (isOverviewMode) {
          div.classList.add('sidenav__secondary-item--active');
        }
      }
      secondaryPane.appendChild(div);
    });
  }
  
  // Helper: Show/hide toggle button
  function updateToggleButton(show) {
    const toggleBtn = document.getElementById('secondary-toggle');
    console.log('updateToggleButton called:', { show, buttonFound: !!toggleBtn, isSecondaryHidden });
    if (toggleBtn) {
      toggleBtn.style.display = show ? 'flex' : 'none';
      
      // Update button state based on secondary pane visibility
      if (isSecondaryHidden) {
        toggleBtn.classList.add('secondary-toggle--hidden');
        toggleBtn.title = 'Show secondary navigation';
      } else {
        toggleBtn.classList.remove('secondary-toggle--hidden');
        toggleBtn.title = 'Hide secondary navigation';
      }
    } else {
      console.error('Toggle button not found in DOM');
    }
  }

  // Helper: Get secondary menu for a primary
  function getSecondaryMenu(primary) {
    if (primary === 'Dashboard') return null;
    
    let menu = [];
    let navKey = primary;
    
    // Map primary menu labels to navigation data keys
    const keyMapping = {
      'Accounts': 'Account Information',
      'Pay & Receive': 'Pay & Receive',
      'FX & Securities': 'FX & Securities',
      'Administration': 'Administration'
    };
    
    navKey = keyMapping[primary] || primary;
    
    if (!navigationData[navKey]) {
      console.warn(`No navigation data found for: ${navKey}`);
      return null;
    }
    
    // Overview first
    menu.push({ label: primary + ' Overview', isOverview: true });
    
    // Then all first-level keys (sections only, no sub-items)
    Object.keys(navigationData[navKey]).forEach(section => {
      menu.push({ label: section });
    });
    
    return menu;
  }

  // Show secondary pane with normal shadow
  function showSecondary(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      updateToggleButton(false);
      return;
    }
    
    isOverviewMode = false;
    
    // Update content
    updateSecondaryContent(menu);
    
    // Always show if user hasn't explicitly hidden it, or show as overlay if hidden
    if (!isSecondaryHidden) {
      // Mobile behavior - show secondary below primary
      if (checkMobileView()) {
        secondaryPane.classList.add('sidenav__secondary--visible');
        updateToggleButton(true);
        return;
      }
      
      // Desktop behavior - only add classes if not already visible (smooth transition)
      if (!secondaryPane.classList.contains('sidenav__secondary--visible')) {
        secondaryPane.classList.add('sidenav__secondary--visible');
        primaryNav.classList.add('sidenav__primary--has-secondary');
      }
      
      // Remove overview mode styling
      secondaryPane.classList.remove('sidenav__secondary--overview', 'sidenav__secondary--persistent');
      updateToggleButton(true);
    } else {
      // Show as overlay when hidden by user (for hover behavior)
      secondaryPane.classList.add('sidenav__secondary--visible');
      secondaryPane.classList.remove('sidenav__secondary--overview', 'sidenav__secondary--persistent', 'sidenav__secondary--hidden');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      updateToggleButton(true);
    }
  }

  // Show secondary pane on hover (temporary state - no toggle button)
  function showSecondaryOnHover(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      return;
    }
    
    // Update content
    updateSecondaryContent(menu);
    
    // Show secondary without affecting toggle button state
    if (!isSecondaryHidden) {
      // Mobile behavior - show secondary below primary
      if (checkMobileView()) {
        secondaryPane.classList.add('sidenav__secondary--visible');
        return;
      }
      
      // Desktop behavior - only add classes if not already visible (smooth transition)
      if (!secondaryPane.classList.contains('sidenav__secondary--visible')) {
        secondaryPane.classList.add('sidenav__secondary--visible');
        primaryNav.classList.add('sidenav__primary--has-secondary');
      }
      
      // Remove overview mode styling
      secondaryPane.classList.remove('sidenav__secondary--overview', 'sidenav__secondary--persistent');
      // Note: Don't call updateToggleButton(true) for hover states
    } else {
      // Show as overlay when hidden by user (for hover behavior)
      secondaryPane.classList.add('sidenav__secondary--visible');
      secondaryPane.classList.remove('sidenav__secondary--overview', 'sidenav__secondary--persistent', 'sidenav__secondary--hidden');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      // Note: Don't call updateToggleButton(true) for hover states
    }
  }

  // Show secondary in overview mode (dissolved shadow, persistent layout)
  function showSecondaryOverview(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      updateToggleButton(false);
      return;
    }
    
    isOverviewMode = true;
    
    // Update content
    updateSecondaryContent(menu, true);
    
    // Always show if user hasn't explicitly hidden it, or show as overlay if hidden
    if (!isSecondaryHidden) {
      // Show with overview styling - persistent layout
      secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      updateToggleButton(true);
    } else {
      // Show as overlay when hidden by user
      secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      secondaryPane.classList.remove('sidenav__secondary--hidden');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      updateToggleButton(true);
    }
  }

  // Show secondary in overview mode with smooth content transition (for hover)
  function showSecondaryOverviewWithTransition(primary) {
    const menu = getSecondaryMenu(primary);
    if (!menu) {
      updateToggleButton(false);
      return;
    }
    
    // Skip transitions on mobile
    if (checkMobileView()) {
      showSecondaryOverview(primary);
      return;
    }
    
    // Add fade-out effect to current content
    secondaryPane.classList.add('sidenav__secondary--transitioning');
    
    // After fade-out, update content and fade-in
    setTimeout(() => {
      // Update content
      updateSecondaryContent(menu, true);
      
      // Show regardless of hidden state (for hover behavior)
      secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      secondaryPane.classList.remove('sidenav__secondary--hidden');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      
      // Only show toggle button if we're in a persistent overview mode (not just hovering)
      // This function is called during hover transitions, so we should preserve the existing toggle state
      const activeItem = sidenav.querySelector('.sidenav__item--active');
      if (activeItem && activeItem.dataset.menu !== 'Dashboard') {
        updateToggleButton(true);
      }
      
      // Remove transition class to fade-in new content
      secondaryPane.classList.remove('sidenav__secondary--transitioning');
    }, 150);
  }

  // Hide secondary pane
  function hideSecondary() {
    isOverviewMode = false;
    secondaryPane.classList.remove('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
    primaryNav.classList.remove('sidenav__primary--has-secondary');
    updateToggleButton(false);
    
    // Clear content after animation completes
    setTimeout(() => {
      if (!secondaryPane.classList.contains('sidenav__secondary--visible')) {
        secondaryPane.innerHTML = '';
      }
    }, 300);
  }

  // Toggle secondary pane visibility
  function toggleSecondary() {
    isSecondaryHidden = !isSecondaryHidden;
    
    if (isSecondaryHidden) {
      // Hide the secondary pane
      secondaryPane.classList.add('sidenav__secondary--hidden');
      secondaryPane.classList.remove('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      primaryNav.classList.remove('sidenav__primary--has-secondary');
      updateToggleButton(true); // Keep button visible but update state
    } else {
      // Show the secondary pane if we have an active primary menu
      const activeItem = sidenav.querySelector('.sidenav__item--active');
      if (activeItem && activeItem.dataset.menu !== 'Dashboard') {
        secondaryPane.classList.remove('sidenav__secondary--hidden');
        if (isOverviewMode) {
          showSecondaryOverview(activeItem.dataset.menu);
        } else {
          showSecondary(activeItem.dataset.menu);
        }
      } else {
        updateToggleButton(false); // Hide button if no active menu
      }
    }
    
    // Dispatch event for wire dashboard to listen to
    document.dispatchEvent(new CustomEvent('secondaryNavToggled', {
      detail: { 
        visible: !isSecondaryHidden,
        hidden: isSecondaryHidden 
      }
    }));
  }

  // Hover logic for primary nav icons (desktop only)
  primaryItems.forEach(item => {
    const icon = item.querySelector('.sidenav__icon');
    
    if (!icon) {
      console.warn('No icon found for item:', item);
      return;
    }
    
    console.log('Adding hover listeners to:', item.dataset.menu);
    
    // Desktop hover logic
    icon.addEventListener('mouseenter', e => {
      if (checkMobileView()) return; // Skip hover on mobile
      
      clearTimeout(hoverTimeout);
      const menu = item.dataset.menu;
      const activeItem = sidenav.querySelector('.sidenav__item--active');
      const isOnDashboard = activeItem && activeItem.dataset.menu === 'Dashboard';
      
      if (menu === 'Dashboard') {
        // In overview mode, don't hide secondary when hovering Dashboard
        if (!isOverviewMode) {
          hideSecondary();
        }
      } else {
        // If we're in overview mode, smoothly transition to the new menu in overview mode
        if (isOverviewMode) {
          showSecondaryOverviewWithTransition(menu);
        } else {
          // If hovering from dashboard, use hover function (no toggle button)
          // If hovering from active navigation, use regular function (with toggle button)
          if (isOnDashboard) {
            showSecondaryOnHover(menu);
          } else {
            showSecondary(menu);
          }
        }
      }
    });
    
    icon.addEventListener('mouseleave', e => {
      if (checkMobileView()) return; // Skip hover on mobile
      
      hoverTimeout = setTimeout(() => {
        if (!secondaryPane.matches(':hover')) {
          const activeItem = sidenav.querySelector('.sidenav__item--active');
          const isOnDashboard = activeItem && activeItem.dataset.menu === 'Dashboard';
          
          if (isSecondaryHidden) {
            // Hide secondary pane if user has it hidden
            secondaryPane.classList.add('sidenav__secondary--hidden');
            secondaryPane.classList.remove('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
            primaryNav.classList.remove('sidenav__primary--has-secondary');
            updateToggleButton(true);
          } else if (isOverviewMode) {
            // Return to overview mode if we were in overview
            if (activeItem && activeItem.dataset.menu !== 'Dashboard') {
              showSecondaryOverview(activeItem.dataset.menu);
            }
          } else {
            // If we're on dashboard, hide secondary and toggle button
            if (isOnDashboard) {
              hideSecondary();
            } else {
              // If we're on another active menu, keep the secondary and toggle button
              showSecondary(activeItem.dataset.menu);
            }
          }
        }
      }, 150);
    });
  });

  // Keep secondary open on hover (desktop only)
  secondaryPane.addEventListener('mouseenter', () => {
    if (!checkMobileView()) {
      clearTimeout(hoverTimeout);
    }
  });
  
  secondaryPane.addEventListener('mouseleave', () => {
    if (checkMobileView()) return; // Skip hover on mobile
    
    hoverTimeout = setTimeout(() => {
      const activeItem = sidenav.querySelector('.sidenav__item--active');
      const isOnDashboard = activeItem && activeItem.dataset.menu === 'Dashboard';
      
      if (isSecondaryHidden) {
        // Hide secondary pane if user has it hidden
        secondaryPane.classList.add('sidenav__secondary--hidden');
        secondaryPane.classList.remove('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
        primaryNav.classList.remove('sidenav__primary--has-secondary');
        updateToggleButton(true);
      } else if (isOverviewMode) {
        // Return to overview mode
        if (activeItem && activeItem.dataset.menu !== 'Dashboard') {
          showSecondaryOverview(activeItem.dataset.menu);
        }
      } else {
        // If we're on dashboard, hide secondary and toggle button
        if (isOnDashboard) {
          hideSecondary();
        } else {
          // If we're on another active menu, keep the secondary and toggle button
          showSecondary(activeItem.dataset.menu);
        }
      }
    }, 150);
  });

  // Click logic for primary nav (works on all devices)
  primaryItems.forEach(item => {
    item.addEventListener('click', e => {
      primaryItems.forEach(i => i.classList.remove('sidenav__item--active'));
      item.classList.add('sidenav__item--active');
      const menu = item.dataset.menu;
      
      if (menu === 'Dashboard') {
        hideSecondary();
        loadContent('Dashboard', 'Dashboard');
      } else {
        // Show secondary in overview mode and load overview content
        showSecondaryOverview(menu);
        loadContent(menu, menu + ' Overview');
      }
    });
  });

  // Click logic for secondary nav
  secondaryPane.addEventListener('click', e => {
    const target = e.target.closest('.sidenav__secondary-item');
    if (target) {
      selectSecondary(target);
      return;
    }
  });
  
  // Toggle button click handler
  const toggleButton = document.getElementById('secondary-toggle');
  console.log('Toggle button setup:', { buttonFound: !!toggleButton });
  if (toggleButton) {
    toggleButton.addEventListener('click', () => {
      console.log('Toggle button clicked!');
      toggleSecondary();
    });
  }

  function selectSecondary(target) {
    secondaryPane.querySelectorAll('.sidenav__secondary-item').forEach(i => 
      i.classList.remove('sidenav__secondary-item--active')
    );
    target.classList.add('sidenav__secondary-item--active');
    const primary = sidenav.querySelector('.sidenav__item--active').dataset.menu;
    
    if (target.dataset.overview === 'true') {
      // Switch to overview mode - keep secondary visible and persistent
      showSecondaryOverview(primary);
      loadContent(primary, target.textContent);
    } else {
      // For non-overview items, stay in overview mode but keep secondary persistent
      isOverviewMode = true;
      secondaryPane.classList.add('sidenav__secondary--visible', 'sidenav__secondary--overview', 'sidenav__secondary--persistent');
      primaryNav.classList.add('sidenav__primary--has-secondary');
      loadContent(primary, target.textContent);
    }
  }

  // Handle window resize
  window.addEventListener('resize', () => {
    const wasMobile = isMobileView;
    const nowMobile = checkMobileView();
    
    if (wasMobile !== nowMobile) {
      // Layout changed between mobile/desktop - no additional styling needed
      // The CSS Grid layout handles responsive behavior automatically
    }
  });

  // Initial load: Dashboard
  loadContent('Dashboard', 'Dashboard');
  
  console.log('Sidenav setup complete');
}

// Load content into main area with smooth transitions
function loadContent(primary, secondary) {
  const main = document.getElementById('main-content');
  if (!main) return;
  
  // Add loading class for fade out effect
  main.classList.add('main-content--loading');
  
  // After fade out completes, load page partial and fade in
  setTimeout(() => {
    loadPagePartial(primary, secondary);
  }, 200);
}

// Load page partial based on content type
function loadPagePartial(primary, secondary) {
  const main = document.getElementById('main-content');
  const mainPanel = document.getElementById('main-panel');
  const rightPanel = document.getElementById('right-panel');
  if (!main || !mainPanel || !rightPanel) return;
  
  // Map content to page partials
  let pageFile = null;
  
  if (primary === 'Dashboard') {
    // For dashboard, show simple content for now
    mainPanel.innerHTML = `
      <div class="page-content">
        <div class="page-header">
          <h1 class="page-title">Dashboard</h1>
          <p class="page-description">Welcome to BMO PRO Payments. Your business banking dashboard.</p>
        </div>
      </div>
    `;
    rightPanel.innerHTML = '';
    main.classList.remove('main-content--loading');
    return;
  }
  
  // Determine which page partial to load
  if (primary === 'Pay & Receive') {
    if (secondary === 'Pay & Receive Overview') {
      pageFile = 'partials/pages/payments-overview-dashboard.html';
    } else if (secondary === 'Account Transfer') {
      pageFile = 'partials/pages/interac.html';
    } else if (secondary === 'Wire Payment') {
      pageFile = 'partials/pages/wire-payments-dashboard.html';
    } else if (secondary === 'Interac e-Transfer') {
      pageFile = 'partials/pages/wires-new-dashboard.html';
    }
  }
  
  // Map other specific secondary items to their page partials
  const pageMapping = {
    'Account Transfer': 'partials/pages/interac.html'
  };
  
  if (!pageFile && pageMapping[secondary]) {
    pageFile = pageMapping[secondary];
  }
  
  if (pageFile) {
    // Load the page partial
    fetch(pageFile)
      .then(response => response.text())
      .then(html => {
        // For dashboard-style pages, split main and right panel content
        if (pageFile.includes('wire-payments-dashboard.html') || pageFile.includes('wires-new-dashboard.html') || pageFile.includes('payments-overview-dashboard.html')) {
          // Extract content and inject into panels, mark main-content as wire dashboard
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = html;
          const mainContent = tempDiv.querySelector('.dashboard-main');
          const rightContent = tempDiv.querySelector('.dashboard-sidebar');
          
          mainPanel.innerHTML = mainContent ? mainContent.outerHTML : '';
          rightPanel.innerHTML = rightContent ? rightContent.outerHTML : '';
          
          // Mark the main-content as a wire dashboard for CSS targeting
          main.classList.add('wire-dashboard');
          main.setAttribute('data-help-minimized', 'false');
        } else {
          // For simple pages, inject into main panel only and remove wire dashboard class
          mainPanel.innerHTML = html;
          rightPanel.innerHTML = '';
          main.classList.remove('wire-dashboard');
          main.removeAttribute('data-help-minimized');
        }
        main.classList.remove('main-content--loading');
        
        // Add data labels for mobile table responsiveness
        addMobileTableLabels();
        
        // Load page-specific assets
        loadPageAssets(pageFile);
      })
      .catch(error => {
        console.error('Error loading page partial:', error);
        // Fallback to simple content
        mainPanel.innerHTML = `
          <div class="page-content">
            <div class="page-header">
              <h1 class="page-title">${primary}</h1>
              <h2 class="page-subtitle">${secondary}</h2>
              <p class="page-description">This is the ${secondary} page content.</p>
            </div>
          </div>
        `;
        rightPanel.innerHTML = '';
        main.classList.remove('main-content--loading');
      });
  } else {
    // Fallback for unmapped content
    mainPanel.innerHTML = `
      <div class="page-content">
        <div class="page-header">
          <h1 class="page-title">${primary}</h1>
          <h2 class="page-subtitle">${secondary}</h2>
          <p class="page-description">This is the ${secondary} page content.</p>
        </div>
      </div>
    `;
    rightPanel.innerHTML = '';
    main.classList.remove('main-content--loading');
  }
}

// Add data labels to table cells for mobile responsiveness
function addMobileTableLabels() {
  const tables = document.querySelectorAll('.transfers-table, .wire-table, .wire-transactions-table');
  
  tables.forEach(table => {
    const headers = table.querySelectorAll('.table-header .table-cell, .table-row--header .table-cell');
    const rows = table.querySelectorAll('.table-row:not(.table-row--header)');
    
    const headerTexts = Array.from(headers).map(header => header.textContent.trim());
    
    rows.forEach(row => {
      const cells = row.querySelectorAll('.table-cell');
      cells.forEach((cell, index) => {
        if (headerTexts[index]) {
          cell.setAttribute('data-label', headerTexts[index]);
        }
      });
    });
  });
}

// Load page-specific CSS and JavaScript assets
function loadPageAssets(pageFile) {
  if (!pageFile) return;
  
  console.log('Loading page assets for:', pageFile);
  
  // Remove existing page-specific assets
  removePageAssets();
  
  if (pageFile.includes('wire-payments-dashboard.html')) {
    console.log('Loading wire dashboard assets');
    loadWireDashboardAssets();
  } else if (pageFile.includes('wires-new-dashboard.html')) {
    console.log('Loading wires-new dashboard assets');
    loadWiresNewDashboardAssets();
  } else if (pageFile.includes('payments-overview-dashboard.html')) {
    console.log('Loading payments overview dashboard assets');
    loadPaymentsOverviewDashboardAssets();
  } else {
    console.log('No specific assets to load for:', pageFile);
  }
}

// Remove previously loaded page-specific assets
function removePageAssets() {
  const existingPageCSS = document.querySelectorAll('link[data-page-asset]');
  const existingPageJS = document.querySelectorAll('script[data-page-asset]');
  
  console.log('Removing existing page assets:', { css: existingPageCSS.length, js: existingPageJS.length });
  
  // Clean up global variables from previously loaded dashboards
  cleanupGlobalVariables();
  
  existingPageCSS.forEach(link => {
    console.log('Removing CSS asset:', link.href);
    link.remove();
  });
  
  existingPageJS.forEach(script => {
    console.log('Removing JS asset:', script.src);
    script.remove();
  });
}

// Clean up global variables from dashboard scripts
function cleanupGlobalVariables() {
  // Clear wire dashboard globals
  if (window.wireDashboard) {
    delete window.wireDashboard;
  }
  if (window.initializeWireDashboard) {
    delete window.initializeWireDashboard;
  }
  if (window.wireActivitySummary) {
    delete window.wireActivitySummary;
  }
  if (window.wireTransactionTable) {
    delete window.wireTransactionTable;
  }
  
  // Clear payments dashboard globals
  if (window.paymentsDashboard) {
    delete window.paymentsDashboard;
  }
  if (window.initializePaymentsDashboard) {
    delete window.initializePaymentsDashboard;
  }
  
  // Clear shared globals
  if (window.activitySummary) {
    delete window.activitySummary;
  }
  if (window.transactionTable) {
    delete window.transactionTable;
  }
  
  // Clear payments dashboard specific globals
  if (window.paymentsActivitySummary) {
    delete window.paymentsActivitySummary;
  }
  if (window.paymentsTransactionTable) {
    delete window.paymentsTransactionTable;
  }
  
  // Clear interac dashboard specific globals
  if (window.interacDashboard) {
    delete window.interacDashboard;
  }
  if (window.interacActivitySummary) {
    delete window.interacActivitySummary;
  }
  if (window.interacTransactionTable) {
    delete window.interacTransactionTable;
  }
  
  console.log('Global variables cleaned up');
}

// Load wire dashboard specific assets
function loadWireDashboardAssets() {
  // Load CSS
  const cssLink = document.createElement('link');
  cssLink.rel = 'stylesheet';
  cssLink.href = 'partials/pages/wire-dashboard.css';
  cssLink.setAttribute('data-page-asset', 'wire-dashboard');
  document.head.appendChild(cssLink);
  
  // Load JavaScript with proper initialization timing
  const jsScript = document.createElement('script');
  jsScript.src = 'partials/pages/wire-dashboard.js';
  jsScript.setAttribute('data-page-asset', 'wire-dashboard');
  
  // Ensure the script initializes after DOM is ready
  jsScript.onload = function() {
    // Small delay to ensure DOM is fully updated
    setTimeout(() => {
      console.log('Wire dashboard script loaded, checking for initialization...');
      // Try manual initialization if needed
      if (typeof window.initializeWireDashboard === 'function') {
        window.initializeWireDashboard();
      }
    }, 100);
  };
  
  document.head.appendChild(jsScript);
}

// Load payments overview dashboard specific assets
function loadPaymentsOverviewDashboardAssets() {
  // Load CSS
  const cssLink = document.createElement('link');
  cssLink.rel = 'stylesheet';
  cssLink.href = 'partials/pages/payments-overview-dashboard.css';
  cssLink.setAttribute('data-page-asset', 'payments-overview-dashboard');
  document.head.appendChild(cssLink);
  
  // Load JavaScript with proper initialization timing
  const jsScript = document.createElement('script');
  jsScript.src = 'partials/pages/payments-overview-dashboard.js';
  jsScript.setAttribute('data-page-asset', 'payments-overview-dashboard');
  
  // Ensure the script initializes after DOM is ready
  jsScript.onload = function() {
    // Small delay to ensure DOM is fully updated
    setTimeout(() => {
      console.log('Payments overview dashboard script loaded, checking for initialization...');
      // Try manual initialization if needed
      if (typeof window.initializePaymentsDashboard === 'function') {
        window.initializePaymentsDashboard();
      }
    }, 100);
  };
  
  document.head.appendChild(jsScript);
}

// Load wires-new dashboard specific assets
function loadWiresNewDashboardAssets() {
  // Load CSS
  const cssLink = document.createElement('link');
  cssLink.rel = 'stylesheet';
  cssLink.href = 'partials/pages/wires-new-dashboard.css';
  cssLink.setAttribute('data-page-asset', 'wires-new-dashboard');
  document.head.appendChild(cssLink);
  
  // Load JavaScript with proper initialization timing
  const jsScript = document.createElement('script');
  jsScript.src = 'partials/pages/wires-new-dashboard.js';
  jsScript.setAttribute('data-page-asset', 'wires-new-dashboard');
  
  // Ensure the script initializes after DOM is ready
  jsScript.onload = function() {
    // Small delay to ensure DOM is fully updated
    setTimeout(() => {
      console.log('Wires-new dashboard script loaded, checking for initialization...');
      // Try manual initialization if needed
      if (typeof window.initializeWireDashboard === 'function') {
        window.initializeWireDashboard();
      }
    }, 100);
  };
  
  document.head.appendChild(jsScript);
}
